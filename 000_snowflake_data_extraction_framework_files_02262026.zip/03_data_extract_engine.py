"""
=============================================================================
DATA EXTRACT FRAMEWORK - Consolidated Python Module
=============================================================================
File: data_extract_engine.py

Single-file consolidation of:
  - data_extract_framework.py   (utilities, AuditManager, S3ExportManager)
  - sftp_transfer_manager.py    (SFTPConnection, SFTPTransferManager, helpers)
  - data_extract_engine_v2.py   (DataExtractEngine orchestrator + SP entry points)

Deploy to Snowflake CODE_STAGE:
  PUT file://data_extract_engine.py @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;

All stored procedures reference this single file:
  HANDLER = 'data_extract_engine.run_extract_by_name'
  IMPORTS = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine.py')
=============================================================================
"""

# ── Standard library ─────────────────────────────────────────────────────────
import io
import os
import re
import time
import uuid
import json
import shutil
import hashlib
import tempfile
import traceback
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any, Tuple

# ── Third-party ───────────────────────────────────────────────────────────────
import paramiko
from paramiko.ssh_exception import (
    AuthenticationException,
    BadHostKeyException,
    NoValidConnectionsError,
    SSHException,
)
from snowflake.snowpark import Session
from snowflake.snowpark.exceptions import SnowparkSQLException
import snowflake.snowpark.functions as F

# Optional PGP support
try:
    import gnupg
    _PGP_AVAILABLE = True
except ImportError:
    _PGP_AVAILABLE = False


# =============================================================================
# CONSTANTS
# =============================================================================
FRAMEWORK_DB      = "DATA_EXTRACT_DB"
CONFIG_TABLE      = "DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG"
AUDIT_TABLE       = "DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_LOG"
SUMMARY_TABLE     = "DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_SUMMARY"
SFTP_TRANSFER_LOG = "DATA_EXTRACT_DB.AUDIT.SFTP_TRANSFER_LOG"

STATUS_RUNNING = "RUNNING"
STATUS_SUCCESS = "SUCCESS"
STATUS_FAILED  = "FAILED"
STATUS_SKIPPED = "SKIPPED"


# =============================================================================
# SECTION 1 — SHARED UTILITIES
# =============================================================================

def resolve_file_name(pattern: str, run_dt: Optional[datetime] = None) -> str:
    """
    Resolve dynamic date/time tokens in file name patterns.

    Supported tokens:
        {YYYYMMDD_HH24MISS}  -> 20250120_063045
        {YYYYMMDD_HH24}      -> 20250120_06
        {YYYYMMDD}           -> 20250120
        {YYYY}               -> 2025
        {MM}                 -> 01
        {DD}                 -> 20
        {HH24}               -> 06
        {MI}                 -> 30
        {SS}                 -> 45
        {EPOCH}              -> Unix timestamp integer
    """
    dt = run_dt or datetime.now(timezone.utc)
    replacements = {
        "{YYYYMMDD_HH24MISS}": dt.strftime("%Y%m%d_%H%M%S"),
        "{YYYYMMDD_HH24}":     dt.strftime("%Y%m%d_%H"),
        "{YYYYMMDD}":          dt.strftime("%Y%m%d"),
        "{YYYY}":              dt.strftime("%Y"),
        "{MM}":                dt.strftime("%m"),
        "{DD}":                dt.strftime("%d"),
        "{HH24}":              dt.strftime("%H"),
        "{MI}":                dt.strftime("%M"),
        "{SS}":                dt.strftime("%S"),
        "{EPOCH}":             str(int(dt.timestamp())),
    }
    name = pattern
    for token, value in replacements.items():
        name = name.replace(token, value)
    return name


def build_source_query(config: Dict[str, Any]) -> str:
    """
    Build the effective SQL from config.

    Uses SOURCE_QUERY if provided; otherwise builds SELECT * FROM table.
    Appends FILTER_CONDITION and ORDER_BY_COLUMN when set.
    """
    if config.get("SOURCE_QUERY"):
        base = config["SOURCE_QUERY"].rstrip(";")
        if config.get("FILTER_CONDITION"):
            if re.search(r'\bWHERE\b', base, re.IGNORECASE):
                base += f" AND ({config['FILTER_CONDITION']})"
            else:
                base += f" WHERE {config['FILTER_CONDITION']}"
    else:
        src  = f"{config['SOURCE_DATABASE']}.{config['SOURCE_SCHEMA']}.{config['SOURCE_TABLE']}"
        base = f"SELECT * FROM {src}"
        if config.get("FILTER_CONDITION"):
            base += f" WHERE {config['FILTER_CONDITION']}"

    if config.get("ORDER_BY_COLUMN"):
        base += f" ORDER BY {config['ORDER_BY_COLUMN']}"

    return base


def get_snowflake_copy_format_options(config: Dict[str, Any]) -> str:
    """Generate the FILE_FORMAT clause for a COPY INTO <stage> statement."""
    fmt = config.get("FILE_FORMAT", "CSV").upper()

    if fmt == "CSV":
        options = [
            "TYPE = CSV",
            f"FIELD_DELIMITER = '{config.get('DELIMITER', ',')}'",
            f"NULL_IF = ('{config.get('NULL_VALUE', '')}')",
            f"DATE_FORMAT = '{config.get('DATE_FORMAT', 'YYYY-MM-DD')}'",
            f"TIMESTAMP_FORMAT = '{config.get('TIMESTAMP_FORMAT', 'YYYY-MM-DD HH24:MI:SS')}'",
            f"COMPRESSION = {config.get('COMPRESSION', 'NONE')}",
        ]
        if config.get("INCLUDE_HEADER", True):
            options.append("SKIP_HEADER = 0")
    elif fmt == "PARQUET":
        compression = config.get("COMPRESSION", "SNAPPY")
        options = [
            "TYPE = PARQUET",
            f"SNAPPY_COMPRESSION = {'TRUE' if compression == 'SNAPPY' else 'FALSE'}",
        ]
    elif fmt == "JSON":
        options = [
            "TYPE = JSON",
            f"COMPRESSION = {config.get('COMPRESSION', 'NONE')}",
        ]
    else:
        raise ValueError(f"Unsupported FILE_FORMAT: {fmt}")

    return "\n  FILE_FORMAT = (  " + ",\n    ".join(options) + "\n  )"


# =============================================================================
# SECTION 2 — AUDIT MANAGER
# =============================================================================

class AuditManager:
    """Handles all audit logging to EXTRACT_AUDIT_LOG and EXTRACT_AUDIT_SUMMARY."""

    def __init__(self, session: Session):
        self.session = session

    def start_run(self, config_id: int, config_name: str, effective_query: str) -> str:
        """Insert a RUNNING record and return the run_id UUID."""
        run_id    = str(uuid.uuid4())
        warehouse = self.session.sql("SELECT CURRENT_WAREHOUSE()").collect()[0][0]
        query_id  = self.session.sql("SELECT LAST_QUERY_ID()").collect()[0][0]

        self.session.sql(f"""
            INSERT INTO {AUDIT_TABLE} (
                CONFIG_ID, CONFIG_NAME, RUN_ID, STATUS,
                START_TIME, EXECUTED_BY, QUERY_ID, WAREHOUSE_NAME, EFFECTIVE_QUERY
            ) VALUES (
                {config_id}, '{config_name}', '{run_id}', '{STATUS_RUNNING}',
                CURRENT_TIMESTAMP(), CURRENT_USER(), '{query_id}',
                '{warehouse}', $${effective_query}$$
            )
        """).collect()
        print(f"[AUDIT] Run started | run_id={run_id} | config={config_name}")
        return run_id

    def end_run_success(
        self,
        run_id: str,
        rows_extracted: int,
        files_generated: int,
        bytes_written: int,
        s3_files: List[str],
        sftp_files: List[str],
    ):
        """Update the audit record with success metrics."""
        s3_json   = json.dumps(s3_files).replace("'", "''")
        sftp_json = json.dumps(sftp_files).replace("'", "''")

        self.session.sql(f"""
            UPDATE {AUDIT_TABLE}
            SET STATUS              = '{STATUS_SUCCESS}',
                END_TIME            = CURRENT_TIMESTAMP(),
                DURATION_SECONDS    = DATEDIFF('second', START_TIME, CURRENT_TIMESTAMP()),
                ROWS_EXTRACTED      = {rows_extracted},
                FILES_GENERATED     = {files_generated},
                BYTES_WRITTEN       = {bytes_written},
                S3_FILES_UPLOADED   = PARSE_JSON('{s3_json}'),
                SFTP_FILES_UPLOADED = PARSE_JSON('{sftp_json}')
            WHERE RUN_ID = '{run_id}'
        """).collect()
        print(f"[AUDIT] Run SUCCESS | run_id={run_id} | rows={rows_extracted} | files={files_generated}")

    def end_run_failed(self, run_id: str, error_code: str, error_message: str, stack_trace: str):
        """Update the audit record with failure details."""
        error_message = error_message.replace("'", "''")[:4000]
        stack_trace   = stack_trace.replace("'", "''")[:8000]

        self.session.sql(f"""
            UPDATE {AUDIT_TABLE}
            SET STATUS           = '{STATUS_FAILED}',
                END_TIME         = CURRENT_TIMESTAMP(),
                DURATION_SECONDS = DATEDIFF('second', START_TIME, CURRENT_TIMESTAMP()),
                ERROR_CODE       = '{error_code}',
                ERROR_MESSAGE    = $${error_message}$$,
                STACK_TRACE      = $${stack_trace}$$
            WHERE RUN_ID = '{run_id}'
        """).collect()
        print(f"[AUDIT] Run FAILED | run_id={run_id} | error={error_code}: {error_message[:200]}")

    def refresh_summary(self, config_id: int, config_name: str):
        """Upsert today's summary row for this config into EXTRACT_AUDIT_SUMMARY."""
        self.session.sql(f"""
            MERGE INTO {SUMMARY_TABLE} tgt
            USING (
                SELECT DATE(START_TIME) AS SUMMARY_DATE, CONFIG_ID,
                       MAX(CONFIG_NAME) AS CONFIG_NAME,
                       COUNT(*) AS TOTAL_RUNS,
                       SUM(CASE WHEN STATUS = 'SUCCESS' THEN 1 ELSE 0 END) AS SUCCESSFUL_RUNS,
                       SUM(CASE WHEN STATUS = 'FAILED'  THEN 1 ELSE 0 END) AS FAILED_RUNS,
                       AVG(DURATION_SECONDS) AS AVG_DURATION_SEC,
                       SUM(ROWS_EXTRACTED)   AS TOTAL_ROWS,
                       SUM(FILES_GENERATED)  AS TOTAL_FILES,
                       SUM(BYTES_WRITTEN)    AS TOTAL_BYTES,
                       MAX(STATUS)           AS LAST_RUN_STATUS,
                       MAX(START_TIME)       AS LAST_RUN_TIME
                FROM {AUDIT_TABLE}
                WHERE CONFIG_ID = {config_id} AND DATE(START_TIME) = CURRENT_DATE()
                GROUP BY DATE(START_TIME), CONFIG_ID
            ) src ON tgt.SUMMARY_DATE = src.SUMMARY_DATE AND tgt.CONFIG_ID = src.CONFIG_ID
            WHEN MATCHED THEN UPDATE SET
                TOTAL_RUNS      = src.TOTAL_RUNS,
                SUCCESSFUL_RUNS = src.SUCCESSFUL_RUNS,
                FAILED_RUNS     = src.FAILED_RUNS,
                AVG_DURATION_SEC= src.AVG_DURATION_SEC,
                TOTAL_ROWS      = src.TOTAL_ROWS,
                TOTAL_FILES     = src.TOTAL_FILES,
                TOTAL_BYTES     = src.TOTAL_BYTES,
                LAST_RUN_STATUS = src.LAST_RUN_STATUS,
                LAST_RUN_TIME   = src.LAST_RUN_TIME
            WHEN NOT MATCHED THEN INSERT (
                SUMMARY_DATE, CONFIG_ID, CONFIG_NAME,
                TOTAL_RUNS, SUCCESSFUL_RUNS, FAILED_RUNS,
                AVG_DURATION_SEC, TOTAL_ROWS, TOTAL_FILES, TOTAL_BYTES,
                LAST_RUN_STATUS, LAST_RUN_TIME
            ) VALUES (
                src.SUMMARY_DATE, src.CONFIG_ID, src.CONFIG_NAME,
                src.TOTAL_RUNS, src.SUCCESSFUL_RUNS, src.FAILED_RUNS,
                src.AVG_DURATION_SEC, src.TOTAL_ROWS, src.TOTAL_FILES, src.TOTAL_BYTES,
                src.LAST_RUN_STATUS, src.LAST_RUN_TIME
            )
        """).collect()


# =============================================================================
# SECTION 3 — S3 EXPORT MANAGER
# =============================================================================

class S3ExportManager:
    """Executes Snowflake COPY INTO <stage> for S3 exports."""

    def __init__(self, session: Session):
        self.session = session

    def export(self, config: Dict[str, Any], effective_query: str, run_dt: datetime) -> Dict[str, Any]:
        """
        Execute COPY INTO <stage> and return row/file/byte metrics.

        Returns:
            dict: rows_written, files_generated, bytes_written, file_paths
        """
        stage_name    = config["S3_STAGE_NAME"]
        path_prefix   = (config.get("S3_PATH_PREFIX") or "").strip("/")
        file_name     = resolve_file_name(config["FILE_NAME_PATTERN"], run_dt)
        format_clause = get_snowflake_copy_format_options(config)

        stage_path = f"@{stage_name}"
        if path_prefix:
            stage_path += f"/{path_prefix}"
        stage_path += f"/{file_name}"

        max_rows = config.get("SPLIT_BY_ROWS") or 0
        max_file_size_clause = f"MAX_FILE_SIZE = {max_rows * 500}" if max_rows > 0 else ""

        header_clause = ""
        if config.get("FILE_FORMAT", "CSV").upper() == "CSV" and config.get("INCLUDE_HEADER", True):
            header_clause = "HEADER = TRUE"

        copy_sql = f"""
            COPY INTO {stage_path}
            FROM ({effective_query})
            {format_clause}
            {header_clause}
            {max_file_size_clause}
            OVERWRITE = TRUE
            DETAILED_OUTPUT = TRUE
        """

        print(f"[S3] Executing COPY INTO: {stage_path}")
        results = self.session.sql(copy_sql).collect()

        rows_written = files_generated = bytes_written = 0
        file_paths = []
        for row in results:
            row_dict         = row.as_dict()
            rows_written    += int(row_dict.get("rows_unloaded", 0))
            files_generated += 1
            bytes_written   += int(row_dict.get("file_size", 0))
            fp = row_dict.get("file_name") or row_dict.get("FILE_NAME", "")
            if fp:
                file_paths.append(fp)

        print(f"[S3] Export complete: rows={rows_written}, files={files_generated}, bytes={bytes_written}")
        return {
            "rows_written":    rows_written,
            "files_generated": files_generated,
            "bytes_written":   bytes_written,
            "file_paths":      file_paths,
        }


# =============================================================================
# SECTION 4 — CHECKSUM & PGP HELPERS
# =============================================================================

def compute_checksum(file_path: str, algorithm: str = "MD5") -> str:
    """Return a lowercase hex checksum (MD5, SHA256, or SHA512) of a local file."""
    algo_map = {"MD5": hashlib.md5, "SHA256": hashlib.sha256, "SHA512": hashlib.sha512}
    if algorithm.upper() not in algo_map:
        raise ValueError(f"Unsupported checksum algorithm: {algorithm}")
    h = algo_map[algorithm.upper()]()
    with open(file_path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def write_checksum_file(file_path: str, checksum: str, algorithm: str) -> str:
    """Write an md5sum/sha256sum-compatible sidecar file. Returns its path."""
    suffix_map    = {"MD5": ".md5", "SHA256": ".sha256", "SHA512": ".sha512"}
    checksum_path = file_path + suffix_map.get(algorithm.upper(), ".checksum")
    with open(checksum_path, "w") as fh:
        fh.write(f"{checksum}  {os.path.basename(file_path)}\n")
    return checksum_path


def encrypt_file_pgp(
    input_path: str,
    pgp_public_key_armored: str,
    output_path: Optional[str] = None,
) -> str:
    """
    Encrypt a local file with a PGP public key using python-gnupg.
    Returns the path to the encrypted file (input_path + '.pgp' by default).
    """
    if not _PGP_AVAILABLE:
        raise RuntimeError(
            "gnupg Python package is not installed. "
            "Add 'python-gnupg' to your Snowpark PACKAGES list."
        )
    if output_path is None:
        output_path = input_path + ".pgp"

    gpg_home = tempfile.mkdtemp(prefix="gnupg_")
    try:
        gpg = gnupg.GPG(gnupghome=gpg_home)
        import_result = gpg.import_keys(pgp_public_key_armored)
        if not import_result.fingerprints:
            raise ValueError("Failed to import PGP public key — key may be malformed.")
        fingerprint = import_result.fingerprints[0]

        with open(input_path, "rb") as fh:
            result = gpg.encrypt_file(fh, recipients=[fingerprint], output=output_path, always_trust=True)
        if not result.ok:
            raise RuntimeError(f"PGP encryption failed: {result.status}")

        print(f"[PGP] Encrypted {input_path} -> {output_path}")
        return output_path
    finally:
        shutil.rmtree(gpg_home, ignore_errors=True)


# =============================================================================
# SECTION 5 — SFTP CONNECTION
# =============================================================================

class SFTPConnection:
    """
    Authenticated paramiko SFTP session with keep-alive, host-key verification,
    and a context-manager interface.

    Usage:
        with SFTPConnection(params, credential) as conn:
            conn.client.put(local_path, remote_path)
    """

    def __init__(self, params: Dict[str, Any], credential: str):
        self.params     = params
        self.credential = credential
        self._transport: Optional[paramiko.Transport]  = None
        self._sftp:      Optional[paramiko.SFTPClient] = None

    def __enter__(self) -> "SFTPConnection":
        self._connect()
        return self

    def __exit__(self, *_):
        self._disconnect()

    @property
    def client(self) -> paramiko.SFTPClient:
        if self._sftp is None:
            raise RuntimeError("SFTP connection is not open.")
        return self._sftp

    def _connect(self):
        p         = self.params
        host      = p["host"]
        port      = int(p.get("port", 22))
        username  = p["username"]
        auth_type = p.get("auth_type", "PASSWORD").upper()
        conn_to   = int(p.get("connect_timeout", 30))
        banner_to = int(p.get("banner_timeout", 15))
        ka_sec    = int(p.get("keep_alive_sec", 60))

        print(f"[SFTP] Connecting to {host}:{port} as '{username}' ({auth_type})")

        sock = paramiko.Transport((host, port))
        sock.set_keepalive(ka_sec)
        sock.banner_timeout = banner_to
        sock.start_client(timeout=conn_to)

        if not p.get("host_key_bypass", False):
            self._verify_host_key(sock, p.get("known_host_key"))

        if auth_type == "PASSWORD":
            sock.auth_password(username, self.credential)
        elif auth_type == "KEY":
            pkey = self._load_private_key(self.credential)
            sock.auth_publickey(username, pkey)
        else:
            raise ValueError(f"Unknown auth_type: {auth_type}")

        if not sock.is_authenticated():
            raise AuthenticationException(f"Authentication failed for {username}@{host}")

        self._transport = sock
        self._sftp      = paramiko.SFTPClient.from_transport(sock)
        print(f"[SFTP] Connected and authenticated: {host}:{port}")

    def _disconnect(self):
        for obj in (self._sftp, self._transport):
            try:
                if obj:
                    obj.close()
            except Exception:
                pass
        self._sftp = self._transport = None
        print("[SFTP] Connection closed.")

    @staticmethod
    def _load_private_key(pem_string: str) -> paramiko.PKey:
        """Try RSA, Ed25519, ECDSA, DSS key types in order."""
        buf = io.StringIO(pem_string)
        for klass in [paramiko.RSAKey, paramiko.Ed25519Key, paramiko.ECDSAKey, paramiko.DSSKey]:
            buf.seek(0)
            try:
                return klass.from_private_key(buf)
            except Exception:
                continue
        raise ValueError("Could not load private key — unsupported format or wrong PEM.")

    @staticmethod
    def _verify_host_key(transport: paramiko.Transport, expected_fingerprint: Optional[str]):
        """Compare server host key against a known SHA-256 fingerprint."""
        if not expected_fingerprint:
            print("[SFTP] WARNING: No known_host_key configured — skipping host verification.")
            return
        server_key    = transport.get_remote_server_key()
        actual_fp     = paramiko.util.hexify(server_key.get_fingerprint()).lower()
        expected_norm = expected_fingerprint.lower().replace(":", "").replace(" ", "")
        if actual_fp != expected_norm:
            raise BadHostKeyException(
                hostname=transport.getpeername()[0],
                got_key=server_key,
                expected_key=server_key,
            )
        print(f"[SFTP] Host key verified: {actual_fp}")


# =============================================================================
# SECTION 6 — REMOTE FILESYSTEM HELPERS
# =============================================================================

def sftp_makedirs(sftp: paramiko.SFTPClient, remote_path: str):
    """Recursively create remote directories (mkdir -p equivalent)."""
    parts   = [p for p in remote_path.replace("\\", "/").split("/") if p]
    current = "/" if remote_path.startswith("/") else ""
    for part in parts:
        current = current.rstrip("/") + "/" + part
        try:
            sftp.stat(current)
        except FileNotFoundError:
            print(f"[SFTP] Creating remote directory: {current}")
            sftp.mkdir(current)


def sftp_list_old_files(sftp: paramiko.SFTPClient, remote_path: str, older_than_days: int) -> List[str]:
    """Return paths of files in remote_path older than older_than_days days."""
    cutoff    = datetime.now(timezone.utc) - timedelta(days=older_than_days)
    old_files = []
    try:
        for attr in sftp.listdir_attr(remote_path):
            if attr.st_mtime:
                mod_time = datetime.fromtimestamp(attr.st_mtime, tz=timezone.utc)
                if mod_time < cutoff:
                    old_files.append(f"{remote_path.rstrip('/')}/{attr.filename}")
    except FileNotFoundError:
        pass
    return old_files


def sftp_archive_file(sftp: paramiko.SFTPClient, remote_file: str, archive_path: str):
    """Move remote_file into archive_path before overwriting."""
    sftp_makedirs(sftp, archive_path)
    archive_dest = f"{archive_path.rstrip('/')}/{remote_file.split('/')[-1]}"
    try:
        sftp.rename(remote_file, archive_dest)
        print(f"[SFTP] Archived {remote_file} -> {archive_dest}")
    except FileNotFoundError:
        pass


def sftp_put_chunked(
    sftp: paramiko.SFTPClient,
    local_path: str,
    remote_path: str,
    chunk_size: int = 32768 * 1024,
) -> Tuple[int, float]:
    """
    Upload a local file in chunks with throughput logging.

    Returns:
        (bytes_transferred, throughput_mbps)
    """
    file_size = os.path.getsize(local_path)
    start_ts  = time.monotonic()

    if file_size <= chunk_size:
        sftp.put(local_path, remote_path)
    else:
        with open(local_path, "rb") as local_fh, sftp.open(remote_path, "wb") as remote_fh:
            remote_fh.set_pipelined(True)
            transferred = 0
            while True:
                data = local_fh.read(chunk_size)
                if not data:
                    break
                remote_fh.write(data)
                transferred += len(data)
                print(f"[SFTP] Upload progress: {transferred}/{file_size} bytes ({transferred*100/file_size:.1f}%)")

    elapsed        = max(time.monotonic() - start_ts, 0.001)
    throughput_mbps = (file_size / elapsed) / (1024 * 1024)
    print(f"[SFTP] Upload done: {file_size:,} bytes in {elapsed:.2f}s ({throughput_mbps:.2f} MB/s)")
    return file_size, throughput_mbps


# =============================================================================
# SECTION 7 — SFTP TRANSFER MANAGER
# =============================================================================

class SFTPTransferManager:
    """
    Production-grade SFTP transfer layer supporting:
      - Password + SSH key authentication
      - Atomic upload (.tmp rename)
      - MD5/SHA256/SHA512 checksum sidecar files
      - .done / .trigger flag files
      - PGP encryption before upload
      - Configurable retry with exponential back-off
      - SSH keep-alive
      - Host key verification
      - Bandwidth-aware chunked transfers with throughput logging
      - Multi-destination fan-out (primary + secondary targets)
      - Remote retention cleanup
      - SFTP-only mode (no S3 intermediate stage)
      - Per-file audit rows in SFTP_TRANSFER_LOG
    """

    def __init__(self, session: Session):
        self.session = session

    # ------------------------------------------------------------------
    # PUBLIC: Transfer to all destinations
    # ------------------------------------------------------------------

    def transfer(
        self,
        config: Dict[str, Any],
        local_file_paths: List[str],
        run_id: str,
        audit_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Transfer all files to the primary SFTP destination, then fan out
        to any secondary targets defined in SFTP_SECONDARY_TARGETS.

        Returns:
            {"primary": [...], "secondary": {host: [...]}, "total_bytes": int, "all_success": bool}
        """
        sftp_start  = datetime.now(timezone.utc)
        config_name = config.get("CONFIG_NAME", "UNKNOWN")

        primary_params = self._build_conn_params_from_config(config)
        primary_cred   = self._get_secret(config["SFTP_SECRET_NAME"])
        all_targets    = [{"params": primary_params, "cred": primary_cred, "is_primary": True}]

        secondary_raw = config.get("SFTP_SECONDARY_TARGETS")
        if secondary_raw:
            targets_list = secondary_raw if isinstance(secondary_raw, list) else json.loads(str(secondary_raw))
            for tgt in targets_list:
                tgt_cred = self._get_secret(tgt["secret_name"])
                tgt_params = {
                    "host":            tgt["host"],
                    "port":            int(tgt.get("port", 22)),
                    "username":        tgt["username"],
                    "auth_type":       tgt.get("auth_type", "PASSWORD"),
                    "connect_timeout": int(config.get("SFTP_CONNECT_TIMEOUT") or 30),
                    "banner_timeout":  int(config.get("SFTP_BANNER_TIMEOUT")  or 15),
                    "keep_alive_sec":  int(config.get("SFTP_KEEP_ALIVE_SEC")  or 60),
                    "known_host_key":  None,
                    "host_key_bypass": bool(config.get("SFTP_HOST_KEY_BYPASS", False)),
                }
                all_targets.append({"params": tgt_params, "cred": tgt_cred, "is_primary": False, "raw": tgt})

        results = {"primary": [], "secondary": {}, "total_bytes": 0, "all_success": True}

        for target in all_targets:
            t_params   = target["params"]
            t_cred     = target["cred"]
            t_host     = t_params["host"]
            is_primary = target.get("is_primary", True)
            remote_base = config.get("SFTP_REMOTE_PATH", "/") if is_primary else target["raw"].get("remote_path", "/")

            print(f"\n[SFTP] {'Primary' if is_primary else 'Secondary'} target: {t_host}:{remote_base}")
            uploaded_paths, bytes_sent, success = self._transfer_to_target(
                config, local_file_paths, t_params, t_cred, remote_base, run_id, audit_id, config_name
            )

            results["total_bytes"] += bytes_sent
            if not success:
                results["all_success"] = False
            if is_primary:
                results["primary"] = uploaded_paths
            else:
                results["secondary"][t_host] = uploaded_paths

        sftp_end = datetime.now(timezone.utc)
        sftp_dur = int((sftp_end - sftp_start).total_seconds())
        self._update_audit_sftp_metrics(run_id, sftp_start, sftp_end, sftp_dur, results["total_bytes"])
        return results

    # ------------------------------------------------------------------
    # PUBLIC: Generate file locally for SFTP-only mode
    # ------------------------------------------------------------------

    def generate_file_locally(
        self,
        session: Session,
        config: Dict[str, Any],
        effective_query: str,
        run_dt: datetime,
    ) -> Tuple[List[str], int, int]:
        """
        For SFTP_ONLY=TRUE: write query results directly to /tmp.

        Returns:
            (local_file_paths, row_count, file_size_bytes)
        """
        file_name   = resolve_file_name(config["FILE_NAME_PATTERN"], run_dt)
        local_dir   = "/tmp/sftp_direct/"
        os.makedirs(local_dir, exist_ok=True)
        local_path  = os.path.join(local_dir, file_name)

        fmt         = config.get("FILE_FORMAT", "CSV").upper()
        delimiter   = config.get("DELIMITER", ",")
        compression = config.get("COMPRESSION", "NONE").upper()

        print(f"[SFTP-ONLY] Writing data to local file: {local_path}")
        df = session.sql(effective_query)

        if fmt == "CSV":
            pandas_df = df.to_pandas()
            pandas_df.to_csv(
                local_path,
                sep         = delimiter,
                index       = False,
                header      = bool(config.get("INCLUDE_HEADER", True)),
                na_rep      = config.get("NULL_VALUE", ""),
                compression = compression.lower() if compression != "NONE" else None,
            )
        elif fmt == "PARQUET":
            pandas_df = df.to_pandas()
            pandas_df.to_parquet(local_path, index=False)
        elif fmt == "JSON":
            pandas_df = df.to_pandas()
            pandas_df.to_json(local_path, orient="records", lines=True)
        else:
            raise ValueError(f"Unsupported FILE_FORMAT for SFTP-ONLY mode: {fmt}")

        row_count = len(pandas_df)
        file_size = os.path.getsize(local_path)
        print(f"[SFTP-ONLY] File written: {row_count} rows, {file_size:,} bytes -> {local_path}")
        return [local_path], row_count, file_size

    # ------------------------------------------------------------------
    # INTERNAL: Transfer all files to one target
    # ------------------------------------------------------------------

    def _transfer_to_target(
        self,
        config: Dict[str, Any],
        local_paths: List[str],
        conn_params: Dict[str, Any],
        credential: str,
        remote_base: str,
        run_id: str,
        audit_id: Optional[int],
        config_name: str,
    ) -> Tuple[List[str], int, bool]:
        retry_max      = int(config.get("SFTP_RETRY_ATTEMPTS")   or 3)
        retry_delay    = int(config.get("SFTP_RETRY_DELAY_SEC")  or 30)
        chunk_size     = int(config.get("SFTP_CHUNK_SIZE_KB")    or 32768) * 1024
        temp_suffix    = config.get("SFTP_TEMP_SUFFIX")          or ".tmp"
        rename_on_done = bool(config.get("SFTP_RENAME_ON_COMPLETE", True))
        overwrite      = bool(config.get("SFTP_OVERWRITE_REMOTE", True))
        archive_path   = config.get("SFTP_REMOTE_ARCHIVE_PATH")
        checksum_en    = bool(config.get("SFTP_CHECKSUM_ENABLED", True))
        checksum_alg   = (config.get("SFTP_CHECKSUM_TYPE")       or "MD5").upper()
        flag_en        = bool(config.get("SFTP_FLAG_FILE_ENABLED", False))
        flag_suffix    = config.get("SFTP_FLAG_FILE_SUFFIX")     or ".done"
        pgp_en         = bool(config.get("SFTP_PGP_ENABLED", False))
        pgp_secret     = config.get("SFTP_PGP_KEY_SECRET")
        del_local      = bool(config.get("SFTP_DELETE_LOCAL_AFTER", True))
        retention_days = int(config.get("SFTP_REMOTE_RETENTION_DAYS") or 0)

        uploaded_paths = []
        total_bytes    = 0
        all_ok         = True

        with SFTPConnection(conn_params, credential) as conn:
            sftp = conn.client
            sftp_makedirs(sftp, remote_base)

            if retention_days > 0:
                for old_f in sftp_list_old_files(sftp, remote_base, retention_days):
                    print(f"[SFTP] Purging old remote file: {old_f}")
                    try:
                        sftp.remove(old_f)
                    except Exception as e:
                        print(f"[SFTP] WARNING: Could not purge {old_f}: {e}")

            for local_path in local_paths:
                file_name    = os.path.basename(local_path)
                remote_final = f"{remote_base.rstrip('/')}/{file_name}"

                ok, bytes_sent = self._upload_one_file(
                    sftp, local_path, remote_final,
                    temp_suffix, rename_on_done, overwrite, archive_path, chunk_size,
                    checksum_en, checksum_alg, flag_en, flag_suffix,
                    pgp_en, pgp_secret, retry_max, retry_delay,
                    run_id, audit_id, config_name, conn_params,
                )

                if ok:
                    uploaded_paths.append(remote_final)
                    total_bytes += bytes_sent
                else:
                    all_ok = False

                if del_local and os.path.exists(local_path):
                    os.remove(local_path)
                    print(f"[SFTP] Deleted local temp file: {local_path}")

        return uploaded_paths, total_bytes, all_ok

    # ------------------------------------------------------------------
    # INTERNAL: Upload one file with retry, checksum, PGP, flag
    # ------------------------------------------------------------------

    def _upload_one_file(
        self,
        sftp: paramiko.SFTPClient,
        local_path: str,
        remote_final: str,
        temp_suffix: str,
        rename_on_done: bool,
        overwrite: bool,
        archive_path: Optional[str],
        chunk_size: int,
        checksum_en: bool,
        checksum_alg: str,
        flag_en: bool,
        flag_suffix: str,
        pgp_en: bool,
        pgp_secret: Optional[str],
        retry_max: int,
        retry_delay: int,
        run_id: str,
        audit_id: Optional[int],
        config_name: str,
        conn_params: Dict[str, Any],
    ) -> Tuple[bool, int]:
        file_size   = os.path.getsize(local_path)
        remote_temp = remote_final + temp_suffix if rename_on_done else remote_final

        # PGP encrypt before upload
        actual_local_path  = local_path
        pgp_encrypted_flag = False
        if pgp_en and pgp_secret:
            pgp_key = self._get_secret(pgp_secret)
            actual_local_path  = encrypt_file_pgp(local_path, pgp_key, local_path + ".pgp")
            remote_final = remote_final + ".pgp"
            remote_temp  = remote_temp  + ".pgp"
            file_size    = os.path.getsize(actual_local_path)
            pgp_encrypted_flag = True

        # Pre-compute checksum
        checksum_value      = None
        local_checksum_path = None
        if checksum_en:
            print(f"[SFTP] Computing {checksum_alg} checksum for {actual_local_path}")
            checksum_value      = compute_checksum(actual_local_path, checksum_alg)
            local_checksum_path = write_checksum_file(actual_local_path, checksum_value, checksum_alg)
            print(f"[SFTP] Checksum ({checksum_alg}): {checksum_value}")

        attempt = 0
        last_error = None
        bytes_sent = 0
        throughput = 0.0
        transfer_ok = False

        while attempt < retry_max:
            attempt       += 1
            transfer_start = datetime.now(timezone.utc)
            transfer_end   = None
            duration_ms    = None
            status         = "FAILED"

            print(f"[SFTP] Attempt {attempt}/{retry_max}: {actual_local_path} -> {remote_temp}")
            try:
                if archive_path and overwrite:
                    sftp_archive_file(sftp, remote_final, archive_path)
                elif overwrite:
                    try:
                        sftp.remove(remote_final)
                    except FileNotFoundError:
                        pass

                bytes_sent, throughput = sftp_put_chunked(sftp, actual_local_path, remote_temp, chunk_size)

                # Upload checksum sidecar
                remote_checksum_path = None
                if checksum_en and local_checksum_path:
                    suffix_map = {"MD5": ".md5", "SHA256": ".sha256", "SHA512": ".sha512"}
                    remote_checksum_path = remote_final + suffix_map.get(checksum_alg, ".checksum")
                    remote_checksum_temp = remote_checksum_path + temp_suffix if rename_on_done else remote_checksum_path
                    sftp.put(local_checksum_path, remote_checksum_temp)
                    if rename_on_done:
                        try:
                            sftp.remove(remote_checksum_path)
                        except FileNotFoundError:
                            pass
                        sftp.rename(remote_checksum_temp, remote_checksum_path)

                # Atomic rename
                if rename_on_done:
                    print(f"[SFTP] Renaming {remote_temp} -> {remote_final}")
                    try:
                        sftp.remove(remote_final)
                    except FileNotFoundError:
                        pass
                    sftp.rename(remote_temp, remote_final)

                # Write flag file
                remote_flag_path = None
                if flag_en:
                    remote_flag_path = remote_final + flag_suffix
                    with tempfile.NamedTemporaryFile(delete=False, suffix=flag_suffix) as tmp_flag:
                        tmp_flag_path = tmp_flag.name
                    try:
                        sftp.put(tmp_flag_path, remote_flag_path)
                        print(f"[SFTP] Flag file written: {remote_flag_path}")
                    finally:
                        os.unlink(tmp_flag_path)

                transfer_end = datetime.now(timezone.utc)
                duration_ms  = int((transfer_end - transfer_start).total_seconds() * 1000)
                status       = "SUCCESS"
                transfer_ok  = True

                self._log_transfer(
                    run_id, audit_id, config_name, local_path, file_size,
                    checksum_alg if checksum_en else None, checksum_value,
                    conn_params, remote_final,
                    remote_temp if rename_on_done else None,
                    status, attempt, transfer_start, transfer_end, duration_ms,
                    throughput, remote_flag_path, remote_checksum_path,
                    pgp_encrypted_flag, None, None,
                )
                break

            except Exception as exc:
                last_error   = exc
                transfer_end = datetime.now(timezone.utc)
                duration_ms  = int((transfer_end - transfer_start).total_seconds() * 1000)
                error_code   = type(exc).__name__
                error_msg    = str(exc)

                print(f"[SFTP] Attempt {attempt} FAILED: {error_code}: {error_msg}")
                self._log_transfer(
                    run_id, audit_id, config_name, local_path, file_size,
                    checksum_alg if checksum_en else None, None,
                    conn_params, remote_final, remote_temp,
                    "RETRY" if attempt < retry_max else "FAILED",
                    attempt, transfer_start, transfer_end, duration_ms,
                    0.0, None, None, pgp_encrypted_flag,
                    error_code, error_msg[:2000],
                )

                if attempt < retry_max:
                    sleep_time = retry_delay * (2 ** (attempt - 1))
                    print(f"[SFTP] Retrying in {sleep_time}s...")
                    time.sleep(sleep_time)

        # Cleanup encrypted temp
        if pgp_en and actual_local_path != local_path and os.path.exists(actual_local_path):
            os.remove(actual_local_path)
        if local_checksum_path and os.path.exists(local_checksum_path):
            os.remove(local_checksum_path)

        if not transfer_ok and last_error:
            raise last_error

        return transfer_ok, bytes_sent

    # ------------------------------------------------------------------
    # INTERNAL: Credential, conn params, audit helpers
    # ------------------------------------------------------------------

    def _get_secret(self, secret_name: str) -> str:
        """Retrieve a credential from a Snowflake Secret object."""
        result = self.session.sql(
            f"SELECT SYSTEM$GET_SECRET_STRING('{secret_name}') AS S"
        ).collect()
        val = result[0]["S"]
        if val is None:
            raise ValueError(f"Secret '{secret_name}' returned NULL. Check name and permissions.")
        return val

    @staticmethod
    def _build_conn_params_from_config(config: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "host":            config["SFTP_HOST"],
            "port":            int(config.get("SFTP_PORT") or 22),
            "username":        config["SFTP_USERNAME"],
            "auth_type":       (config.get("SFTP_AUTH_TYPE") or "PASSWORD").upper(),
            "connect_timeout": int(config.get("SFTP_CONNECT_TIMEOUT") or 30),
            "banner_timeout":  int(config.get("SFTP_BANNER_TIMEOUT")  or 15),
            "keep_alive_sec":  int(config.get("SFTP_KEEP_ALIVE_SEC")  or 60),
            "known_host_key":  config.get("SFTP_KNOWN_HOST_KEY"),
            "host_key_bypass": bool(config.get("SFTP_HOST_KEY_BYPASS", False)),
        }

    def _log_transfer(
        self,
        run_id, audit_id, config_name, local_file_path, local_file_size,
        checksum_type, checksum_value, conn_params, remote_path, remote_temp_path,
        status, attempt, transfer_start, transfer_end, duration_ms, throughput_mbps,
        flag_file_path, checksum_file_path, pgp_encrypted, error_code, error_message,
    ):
        def q(v):
            return "NULL" if v is None else "'" + str(v).replace("'", "''") + "'"

        def ts(v):
            return "NULL" if v is None else f"'{v.strftime('%Y-%m-%d %H:%M:%S.%f')}'"

        sql = f"""
            INSERT INTO {SFTP_TRANSFER_LOG} (
                AUDIT_ID, RUN_ID, CONFIG_NAME,
                LOCAL_FILE_PATH, LOCAL_FILE_SIZE_BYTES, CHECKSUM_TYPE, CHECKSUM_VALUE,
                SFTP_HOST, SFTP_PORT, SFTP_USERNAME,
                SFTP_REMOTE_PATH, SFTP_TEMP_PATH,
                STATUS, ATTEMPT_NUMBER,
                TRANSFER_START, TRANSFER_END, DURATION_MS, THROUGHPUT_MBPS,
                FLAG_FILE_PATH, CHECKSUM_FILE_PATH, PGP_ENCRYPTED,
                ERROR_CODE, ERROR_MESSAGE
            ) VALUES (
                {audit_id if audit_id else 'NULL'}, {q(run_id)}, {q(config_name)},
                {q(local_file_path)}, {local_file_size}, {q(checksum_type)}, {q(checksum_value)},
                {q(conn_params['host'])}, {conn_params.get('port', 22)}, {q(conn_params.get('username'))},
                {q(remote_path)}, {q(remote_temp_path)},
                {q(status)}, {attempt},
                {ts(transfer_start)}, {ts(transfer_end)},
                {duration_ms if duration_ms is not None else 'NULL'},
                {throughput_mbps:.4f},
                {q(flag_file_path)}, {q(checksum_file_path)},
                {'TRUE' if pgp_encrypted else 'FALSE'},
                {q(error_code)}, {q(error_message)}
            )
        """
        try:
            self.session.sql(sql).collect()
        except Exception as e:
            print(f"[AUDIT-SFTP] WARNING: Failed to log transfer row: {e}")

    def _update_audit_sftp_metrics(
        self, run_id: str, sftp_start: datetime, sftp_end: datetime,
        duration_sec: int, bytes_xferred: int
    ):
        sql = f"""
            UPDATE {AUDIT_TABLE}
            SET SFTP_TRANSFER_START_TIME   = '{sftp_start.strftime('%Y-%m-%d %H:%M:%S.%f')}',
                SFTP_TRANSFER_END_TIME     = '{sftp_end.strftime('%Y-%m-%d %H:%M:%S.%f')}',
                SFTP_TRANSFER_DURATION_SEC = {duration_sec},
                SFTP_BYTES_TRANSFERRED     = {bytes_xferred}
            WHERE RUN_ID = '{run_id}'
        """
        try:
            self.session.sql(sql).collect()
        except Exception as e:
            print(f"[AUDIT-SFTP] WARNING: Could not update SFTP metrics: {e}")


# =============================================================================
# SECTION 8 — ORCHESTRATION ENGINE
# =============================================================================

class DataExtractEngine:
    """
    Orchestrates the full extract pipeline:
        EXTRACT_CONFIG -> SQL query -> [S3 COPY INTO] -> [SFTP transfer] -> Audit
    """

    def __init__(self, session: Session):
        self.session      = session
        self.audit        = AuditManager(session)
        self.s3_manager   = S3ExportManager(session)
        self.sftp_manager = SFTPTransferManager(session)

    def run(
        self,
        config_name: Optional[str] = None,
        config_id:   Optional[int] = None,
        run_all:     bool          = False,
        dry_run:     bool          = False,
    ) -> List[Dict[str, Any]]:
        """
        Execute one or all extract jobs.

        Args:
            config_name: Run a specific job by name.
            config_id:   Run a specific job by numeric ID.
            run_all:     Run ALL active extract jobs.
            dry_run:     Preview SQL only; no transfers executed.

        Returns:
            List of result dicts, one per job.
        """
        if not (config_name or config_id or run_all):
            raise ValueError("Specify config_name, config_id, or set run_all=True")

        configs = self._load_config(config_name, config_id)
        return [self._run_single(c, dry_run=dry_run) for c in configs]

    def _load_config(self, config_name=None, config_id=None) -> List[Dict]:
        where = "IS_ACTIVE = TRUE"
        if config_name:
            where += f" AND CONFIG_NAME = '{config_name}'"
        if config_id:
            where += f" AND CONFIG_ID = {config_id}"
        rows = self.session.sql(
            f"SELECT * FROM {CONFIG_TABLE} WHERE {where} ORDER BY CONFIG_ID"
        ).collect()
        if not rows:
            raise ValueError(f"No active config found: name={config_name}, id={config_id}")
        return [r.as_dict() for r in rows]

    def _run_single(self, config: Dict[str, Any], dry_run: bool = False) -> Dict[str, Any]:
        config_id   = config["CONFIG_ID"]
        config_name = config["CONFIG_NAME"]
        run_dt      = datetime.now(timezone.utc)
        sftp_only   = bool(config.get("SFTP_ONLY", False))

        print(f"\n{'='*60}")
        print(f"[EXTRACT] Starting : {config_name} (ID={config_id})")
        print(f"[EXTRACT] SFTP Only: {sftp_only}")

        effective_query = build_source_query(config)

        if dry_run:
            print(f"[DRY RUN] Query:\n{effective_query}")
            return {"config_name": config_name, "status": "DRY_RUN", "query": effective_query}

        run_id = self.audit.start_run(config_id, config_name, effective_query)

        audit_id_rows = self.session.sql(
            f"SELECT AUDIT_ID FROM {AUDIT_TABLE} WHERE RUN_ID = '{run_id}'"
        ).collect()
        audit_id = audit_id_rows[0]["AUDIT_ID"] if audit_id_rows else None

        s3_files = []
        sftp_result = {"primary": [], "secondary": {}, "total_bytes": 0, "all_success": True}
        rows_extracted = files_generated = bytes_written = 0
        local_files = []

        try:
            # PATH A: SFTP-only — write directly to /tmp, skip S3
            if sftp_only:
                print("[ENGINE] SFTP_ONLY mode: writing data to local temp file")
                local_files, rows_extracted, bytes_written = (
                    self.sftp_manager.generate_file_locally(
                        self.session, config, effective_query, run_dt
                    )
                )
                files_generated = len(local_files)
                if config.get("SFTP_ENABLED", True):
                    sftp_result = self.sftp_manager.transfer(
                        config, local_files, run_id, audit_id
                    )
                else:
                    print("[ENGINE] SFTP_ONLY=TRUE but SFTP_ENABLED=FALSE — files left in /tmp")

            # PATH B: S3 first, then optional SFTP
            else:
                if config.get("S3_ENABLED", True):
                    s3_result       = self.s3_manager.export(config, effective_query, run_dt)
                    rows_extracted  = s3_result["rows_written"]
                    files_generated = s3_result["files_generated"]
                    bytes_written   = s3_result["bytes_written"]
                    s3_files        = s3_result["file_paths"]
                else:
                    print("[S3] Skipped (S3_ENABLED=FALSE)")

                if config.get("SFTP_ENABLED", False):
                    if s3_files:
                        local_files = self._stage_files_to_local(config, s3_files)
                        sftp_result = self.sftp_manager.transfer(
                            config, local_files, run_id, audit_id
                        )
                    else:
                        print("[SFTP] No S3 files to transfer")
                else:
                    print("[SFTP] Skipped (SFTP_ENABLED=FALSE)")

            self._update_retry_count(run_id)

            all_sftp_paths = list(sftp_result.get("primary", []))
            for paths in sftp_result.get("secondary", {}).values():
                all_sftp_paths.extend(paths)

            self.audit.end_run_success(
                run_id, rows_extracted, files_generated,
                bytes_written, s3_files, all_sftp_paths
            )
            self.audit.refresh_summary(config_id, config_name)

            return {
                "config_name":      config_name,
                "run_id":           run_id,
                "status":           STATUS_SUCCESS,
                "sftp_only":        sftp_only,
                "rows_extracted":   rows_extracted,
                "files_generated":  files_generated,
                "bytes_written":    bytes_written,
                "s3_files":         s3_files,
                "sftp_primary":     sftp_result.get("primary", []),
                "sftp_secondary":   sftp_result.get("secondary", {}),
                "sftp_all_success": sftp_result.get("all_success", True),
            }

        except Exception as exc:
            self.audit.end_run_failed(
                run_id, type(exc).__name__, str(exc), traceback.format_exc()
            )
            self.audit.refresh_summary(config_id, config_name)
            raise

    def _stage_files_to_local(self, config: Dict[str, Any], s3_file_paths: List[str]) -> List[str]:
        """Download files from Snowflake stage to /tmp for SFTP upload."""
        stage_name  = config["S3_STAGE_NAME"]
        local_dir   = "/tmp/extract_sftp/"
        os.makedirs(local_dir, exist_ok=True)
        local_paths = []

        for s3_path in s3_file_paths:
            file_name  = s3_path.split("/")[-1]
            stage_rel  = s3_path.lstrip("@").split("/", 1)[-1] if "/" in s3_path else s3_path
            stage_file = f"@{stage_name}/{stage_rel}"
            self.session.sql(f"GET {stage_file} file://{local_dir}").collect()
            local_paths.append(os.path.join(local_dir, file_name))

        return local_paths

    def _update_retry_count(self, run_id: str):
        try:
            rows = self.session.sql(f"""
                SELECT COUNT(*) AS CNT
                FROM {SFTP_TRANSFER_LOG}
                WHERE RUN_ID = '{run_id}' AND STATUS = 'RETRY'
            """).collect()
            retry_count = rows[0]["CNT"] if rows else 0
            self.session.sql(f"""
                UPDATE {AUDIT_TABLE}
                SET SFTP_RETRY_COUNT = {retry_count}
                WHERE RUN_ID = '{run_id}'
            """).collect()
        except Exception as e:
            print(f"[AUDIT] WARNING: Could not update retry count: {e}")


# =============================================================================
# SECTION 9 — SFTP CONNECTION TEST UTILITY
# =============================================================================

def test_sftp_connection(session: Session, config_name: str) -> str:
    """
    Stored procedure entry point: verify SFTP connectivity without transferring files.

    Usage: CALL FRAMEWORK.TEST_SFTP_CONNECTION('MY_CONFIG_NAME')
    """
    mgr  = SFTPTransferManager(session)
    rows = session.sql(
        f"SELECT * FROM {CONFIG_TABLE} WHERE CONFIG_NAME = '{config_name}' AND IS_ACTIVE = TRUE"
    ).collect()

    if not rows:
        return json.dumps({"status": "ERROR", "message": f"Config '{config_name}' not found or inactive"})

    config = rows[0].as_dict()
    if not config.get("SFTP_ENABLED"):
        return json.dumps({"status": "SKIPPED", "message": "SFTP_ENABLED=FALSE for this config"})

    host   = config["SFTP_HOST"]
    port   = int(config.get("SFTP_PORT") or 22)
    result = {"config_name": config_name, "host": host, "port": port}

    try:
        params = SFTPTransferManager._build_conn_params_from_config(config)
        cred   = mgr._get_secret(config["SFTP_SECRET_NAME"])

        with SFTPConnection(params, cred) as conn:
            remote_path = config.get("SFTP_REMOTE_PATH", "/")
            try:
                listing = conn.client.listdir(remote_path)
                result["remote_listing_count"] = len(listing)
                result["remote_path"]          = remote_path
            except Exception as list_err:
                result["remote_listing_error"] = str(list_err)

        result["status"]  = "SUCCESS"
        result["message"] = f"Connected to {host}:{port} successfully"
    except Exception as exc:
        result["status"]  = "FAILED"
        result["message"] = f"{type(exc).__name__}: {exc}"

    print(f"[SFTP-TEST] {result}")
    return json.dumps(result, default=str)


# =============================================================================
# SECTION 10 — SNOWPARK STORED PROCEDURE ENTRY POINTS
# =============================================================================

def run_extract_by_name(session: Session, config_name: str) -> str:
    """Entry point: CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('MY_EXTRACT')"""
    return json.dumps(DataExtractEngine(session).run(config_name=config_name), default=str)


def run_extract_by_id(session: Session, config_id: int) -> str:
    """Entry point: CALL FRAMEWORK.RUN_EXTRACT_BY_ID(1)"""
    return json.dumps(DataExtractEngine(session).run(config_id=config_id), default=str)


def run_all_extracts(session: Session) -> str:
    """Entry point: CALL FRAMEWORK.RUN_ALL_EXTRACTS()"""
    return json.dumps(DataExtractEngine(session).run(run_all=True), default=str)


def dry_run_extract(session: Session, config_name: str) -> str:
    """Entry point: CALL FRAMEWORK.DRY_RUN_EXTRACT('MY_EXTRACT')"""
    return json.dumps(DataExtractEngine(session).run(config_name=config_name, dry_run=True), default=str)
