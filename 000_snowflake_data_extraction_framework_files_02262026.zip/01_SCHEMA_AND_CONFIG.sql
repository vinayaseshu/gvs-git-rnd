-- =============================================================================
-- DATA EXTRACT FRAMEWORK - PART 1: SCHEMA, TABLES & SAMPLE CONFIGURATION
-- =============================================================================
-- Consolidates: 01_setup_config_tables.sql + 04_deployment.sql +
--               05_sftp_extension_schema.sql
--
-- NOTE: CHECK constraints are intentionally omitted — Snowflake parses but
--       does NOT enforce them at runtime. Validation is handled instead by:
--         • FRAMEWORK.UPSERT_EXTRACT_CONFIG stored procedure  (write-time)
--         • FRAMEWORK.V_CONFIG_VIOLATIONS view                (audit/detect)
--         • FRAMEWORK.VALIDATE_CONFIG_TASK Snowflake task     (auto-flag)
--
-- EXECUTION ORDER: Run this file FIRST, then 02_PROCEDURES_TASKS_VIEWS.sql
-- =============================================================================

USE ROLE SYSADMIN;
USE WAREHOUSE COMPUTE_WH;

-- =============================================================================
-- SECTION 1: DATABASE, SCHEMAS & INTERNAL STAGE
-- =============================================================================

CREATE DATABASE IF NOT EXISTS DATA_EXTRACT_DB;
USE DATABASE DATA_EXTRACT_DB;
CREATE SCHEMA IF NOT EXISTS FRAMEWORK;
CREATE SCHEMA IF NOT EXISTS AUDIT;

-- Internal stage for Python stored-procedure source files
CREATE STAGE IF NOT EXISTS FRAMEWORK.CODE_STAGE
    COMMENT = 'Stores Python source code for Snowpark stored procedures';

-- Upload the consolidated Python module (SnowSQL CLI or Python connector):
--   PUT file://03_data_extract_engine.py @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
--
-- Verify upload:
--   LIST @FRAMEWORK.CODE_STAGE;

-- =============================================================================
-- SECTION 2: S3 EXTERNAL STAGE  (customize with your AWS details)
-- =============================================================================

-- Option A: Storage Integration (recommended for production)
CREATE STORAGE INTEGRATION IF NOT EXISTS S3_EXTRACT_INTEGRATION
    TYPE                      = EXTERNAL_STAGE
    STORAGE_PROVIDER          = 'S3'
    ENABLED                   = TRUE
    STORAGE_AWS_ROLE_ARN      = 'arn:aws:iam::YOUR_ACCOUNT_ID:role/YOUR_SNOWFLAKE_ROLE'
    STORAGE_ALLOWED_LOCATIONS = ('s3://your-bucket/extracts/');

CREATE STAGE IF NOT EXISTS FRAMEWORK.MY_S3_STAGE
    URL                 = 's3://your-bucket/extracts/'
    STORAGE_INTEGRATION = S3_EXTRACT_INTEGRATION
    COMMENT             = 'S3 external stage for data extracts';

-- Option B: Access key credentials (dev/test only — less secure)
-- CREATE STAGE IF NOT EXISTS FRAMEWORK.MY_S3_STAGE
--     URL         = 's3://your-bucket/extracts/'
--     CREDENTIALS = (AWS_KEY_ID = 'XXXX' AWS_SECRET_KEY = 'YYYY')
--     COMMENT     = 'S3 external stage for data extracts';

-- =============================================================================
-- SECTION 3: SNOWFLAKE SECRETS FOR SFTP CREDENTIALS
-- =============================================================================

CREATE SECRET IF NOT EXISTS FRAMEWORK.SFTP_PARTNER_SECRET
    TYPE          = GENERIC_STRING
    SECRET_STRING = 'your_sftp_password_here'
    COMMENT       = 'SFTP password for partner file delivery';

-- SSH private key authentication example:
-- CREATE SECRET IF NOT EXISTS FRAMEWORK.SFTP_PARTNER_KEY
--     TYPE          = GENERIC_STRING
--     SECRET_STRING = '-----BEGIN RSA PRIVATE KEY-----\n...\n-----END RSA PRIVATE KEY-----';

-- =============================================================================
-- SECTION 4: ROLES & PERMISSIONS
-- =============================================================================

CREATE ROLE IF NOT EXISTS EXTRACT_FRAMEWORK_ROLE;

GRANT USAGE            ON DATABASE DATA_EXTRACT_DB                          TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE            ON SCHEMA DATA_EXTRACT_DB.FRAMEWORK                  TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE            ON SCHEMA DATA_EXTRACT_DB.AUDIT                      TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT SELECT           ON TABLE DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG    TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT INSERT, UPDATE   ON TABLE DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_LOG     TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT INSERT, UPDATE   ON TABLE DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_SUMMARY TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE            ON STAGE DATA_EXTRACT_DB.FRAMEWORK.MY_S3_STAGE       TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE            ON STAGE DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE        TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE            ON SECRET DATA_EXTRACT_DB.FRAMEWORK.SFTP_PARTNER_SECRET TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE            ON WAREHOUSE COMPUTE_WH                              TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT EXECUTE TASK     ON ACCOUNT                                           TO ROLE EXTRACT_FRAMEWORK_ROLE;

-- Assign role to your user:
GRANT ROLE EXTRACT_FRAMEWORK_ROLE TO USER YOUR_USER;

-- =============================================================================
-- SECTION 5: CORE CONFIGURATION TABLE
-- =============================================================================
-- Allowed column values (enforced by UPSERT_EXTRACT_CONFIG + V_CONFIG_VIOLATIONS,
-- not by CHECK constraints):
--   FILE_FORMAT        : CSV | PARQUET | JSON
--   COMPRESSION        : NONE | GZIP | BZ2 | ZSTD | AUTO
--   SFTP_AUTH_TYPE     : PASSWORD | KEY
--   SFTP_CHECKSUM_TYPE : MD5 | SHA256 | SHA512
-- =============================================================================

USE SCHEMA FRAMEWORK;

CREATE OR REPLACE TABLE FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_ID           NUMBER AUTOINCREMENT PRIMARY KEY,
    CONFIG_NAME         VARCHAR(200)    NOT NULL UNIQUE,
    IS_ACTIVE           BOOLEAN         DEFAULT TRUE,

    -- Source
    SOURCE_DATABASE     VARCHAR(200)    NOT NULL,
    SOURCE_SCHEMA       VARCHAR(200)    NOT NULL,
    SOURCE_TABLE        VARCHAR(200),
    SOURCE_QUERY        TEXT,
    FILTER_CONDITION    TEXT,
    ORDER_BY_COLUMN     VARCHAR(500),

    -- File output  [CSV | PARQUET | JSON]  /  [NONE | GZIP | BZ2 | ZSTD | AUTO]
    FILE_FORMAT         VARCHAR(20)     DEFAULT 'CSV',
    DELIMITER           VARCHAR(5)      DEFAULT ',',
    INCLUDE_HEADER      BOOLEAN         DEFAULT TRUE,
    NULL_VALUE          VARCHAR(20)     DEFAULT '',
    COMPRESSION         VARCHAR(20)     DEFAULT 'NONE',
    DATE_FORMAT         VARCHAR(50)     DEFAULT 'YYYY-MM-DD',
    TIMESTAMP_FORMAT    VARCHAR(50)     DEFAULT 'YYYY-MM-DD HH24:MI:SS',
    FILE_NAME_PATTERN   VARCHAR(500)    NOT NULL,
    SPLIT_BY_ROWS       NUMBER          DEFAULT 0,

    -- S3
    S3_ENABLED          BOOLEAN         DEFAULT TRUE,
    S3_STAGE_NAME       VARCHAR(200),
    S3_PATH_PREFIX      VARCHAR(500),

    -- SFTP core  [SFTP_AUTH_TYPE: PASSWORD | KEY]
    SFTP_ENABLED        BOOLEAN         DEFAULT FALSE,
    SFTP_HOST           VARCHAR(500),
    SFTP_PORT           NUMBER          DEFAULT 22,
    SFTP_USERNAME       VARCHAR(200),
    SFTP_SECRET_NAME    VARCHAR(200),
    SFTP_REMOTE_PATH    VARCHAR(500)    DEFAULT '/',
    SFTP_AUTH_TYPE      VARCHAR(20)     DEFAULT 'PASSWORD',

    -- SFTP transfer behavior
    SFTP_ONLY               BOOLEAN     DEFAULT FALSE,
    SFTP_TEMP_SUFFIX        VARCHAR(10) DEFAULT '.tmp',
    SFTP_RENAME_ON_COMPLETE BOOLEAN     DEFAULT TRUE,

    -- SFTP resilience
    SFTP_RETRY_ATTEMPTS     NUMBER      DEFAULT 3,
    SFTP_RETRY_DELAY_SEC    NUMBER      DEFAULT 30,
    SFTP_CONNECT_TIMEOUT    NUMBER      DEFAULT 30,
    SFTP_BANNER_TIMEOUT     NUMBER      DEFAULT 15,

    -- SFTP integrity  [SFTP_CHECKSUM_TYPE: MD5 | SHA256 | SHA512]
    SFTP_CHECKSUM_ENABLED   BOOLEAN     DEFAULT TRUE,
    SFTP_CHECKSUM_TYPE      VARCHAR(10) DEFAULT 'MD5',

    -- SFTP flag files
    SFTP_FLAG_FILE_ENABLED  BOOLEAN     DEFAULT FALSE,
    SFTP_FLAG_FILE_SUFFIX   VARCHAR(20) DEFAULT '.done',

    -- SFTP PGP encryption
    SFTP_PGP_ENABLED        BOOLEAN     DEFAULT FALSE,
    SFTP_PGP_KEY_SECRET     VARCHAR(200),

    -- SFTP remote lifecycle
    SFTP_REMOTE_ARCHIVE_PATH  VARCHAR(500),
    SFTP_OVERWRITE_REMOTE     BOOLEAN   DEFAULT TRUE,
    SFTP_REMOTE_RETENTION_DAYS NUMBER   DEFAULT 0,

    -- SFTP performance
    SFTP_CHUNK_SIZE_KB      NUMBER      DEFAULT 32768,
    SFTP_KEEP_ALIVE_SEC     NUMBER      DEFAULT 60,

    -- SFTP host key security
    SFTP_KNOWN_HOST_KEY     VARCHAR(2000),
    SFTP_HOST_KEY_BYPASS    BOOLEAN     DEFAULT FALSE,

    -- SFTP post-transfer
    SFTP_POST_CMD           TEXT,
    SFTP_DELETE_LOCAL_AFTER BOOLEAN     DEFAULT TRUE,

    -- SFTP multi-destination fan-out
    -- JSON array: [{host, port, username, secret_name, remote_path, auth_type}]
    SFTP_SECONDARY_TARGETS  VARIANT,

    -- Schedule
    SCHEDULE_ENABLED    BOOLEAN         DEFAULT FALSE,
    SCHEDULE_CRON       VARCHAR(100),
    SCHEDULE_MINUTES    NUMBER,
    SCHEDULE_WAREHOUSE  VARCHAR(200),

    -- Notification
    NOTIFY_ON_SUCCESS   BOOLEAN         DEFAULT FALSE,
    NOTIFY_ON_FAILURE   BOOLEAN         DEFAULT TRUE,
    NOTIFICATION_EMAIL  VARCHAR(500),

    -- Metadata
    CREATED_BY          VARCHAR(200)    DEFAULT CURRENT_USER(),
    CREATED_AT          TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_BY          VARCHAR(200),
    UPDATED_AT          TIMESTAMP_NTZ,
    NOTES               TEXT
);

COMMENT ON TABLE  FRAMEWORK.EXTRACT_CONFIG IS 'Master configuration for all data extract jobs';
COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.FILE_FORMAT
    IS 'Output format. Allowed values: CSV | PARQUET | JSON';
COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.COMPRESSION
    IS 'Output compression. Allowed values: NONE | GZIP | BZ2 | ZSTD | AUTO';
COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.SFTP_AUTH_TYPE
    IS 'SFTP authentication method. Allowed values: PASSWORD | KEY';
COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.SFTP_CHECKSUM_TYPE
    IS 'Checksum algorithm for sidecar files. Allowed values: MD5 | SHA256 | SHA512';
COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.SFTP_ONLY
    IS 'When TRUE, bypass S3 stage; write data directly to /tmp then push via SFTP';
COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.SFTP_SECONDARY_TARGETS
    IS 'JSON array of additional SFTP destinations: [{host, port, username, secret_name, remote_path, auth_type}]';

-- =============================================================================
-- SECTION 6: AUDIT TABLES
-- =============================================================================
-- Allowed STATUS values (enforced by Python engine, not DB constraints):
--   EXTRACT_AUDIT_LOG.STATUS  : RUNNING | SUCCESS | FAILED | SKIPPED
--   SFTP_TRANSFER_LOG.STATUS  : SUCCESS | FAILED | SKIPPED | RETRY
-- =============================================================================

CREATE OR REPLACE TABLE AUDIT.EXTRACT_AUDIT_LOG (
    AUDIT_ID            NUMBER AUTOINCREMENT PRIMARY KEY,
    CONFIG_ID           NUMBER          NOT NULL,
    CONFIG_NAME         VARCHAR(200)    NOT NULL,
    RUN_ID              VARCHAR(100)    NOT NULL,

    -- Execution  [STATUS: RUNNING | SUCCESS | FAILED | SKIPPED]
    STATUS              VARCHAR(20)     NOT NULL,
    START_TIME          TIMESTAMP_NTZ   NOT NULL,
    END_TIME            TIMESTAMP_NTZ,
    DURATION_SECONDS    NUMBER,

    -- Data metrics
    ROWS_EXTRACTED      NUMBER          DEFAULT 0,
    FILES_GENERATED     NUMBER          DEFAULT 0,
    BYTES_WRITTEN       NUMBER          DEFAULT 0,

    -- Output paths
    S3_FILES_UPLOADED   VARIANT,
    SFTP_FILES_UPLOADED VARIANT,

    -- SFTP-specific metrics
    SFTP_TRANSFER_START_TIME   TIMESTAMP_NTZ,
    SFTP_TRANSFER_END_TIME     TIMESTAMP_NTZ,
    SFTP_TRANSFER_DURATION_SEC NUMBER,
    SFTP_BYTES_TRANSFERRED     NUMBER      DEFAULT 0,
    SFTP_RETRY_COUNT           NUMBER      DEFAULT 0,
    SFTP_CHECKSUM_VALUES       VARIANT,
    SFTP_ERROR_DETAIL          TEXT,

    -- Error
    ERROR_CODE          VARCHAR(50),
    ERROR_MESSAGE       TEXT,
    STACK_TRACE         TEXT,

    -- Context
    EXECUTED_BY         VARCHAR(200)    DEFAULT CURRENT_USER(),
    QUERY_ID            VARCHAR(200),
    WAREHOUSE_NAME      VARCHAR(200),
    EFFECTIVE_QUERY     TEXT
);

COMMENT ON TABLE  AUDIT.EXTRACT_AUDIT_LOG IS 'Audit trail for all extract job executions';
COMMENT ON COLUMN AUDIT.EXTRACT_AUDIT_LOG.STATUS
    IS 'Run status. Allowed values: RUNNING | SUCCESS | FAILED | SKIPPED';

CREATE OR REPLACE INDEX IDX_AUDIT_CONFIG_ID  ON AUDIT.EXTRACT_AUDIT_LOG (CONFIG_ID);
CREATE OR REPLACE INDEX IDX_AUDIT_STATUS     ON AUDIT.EXTRACT_AUDIT_LOG (STATUS);
CREATE OR REPLACE INDEX IDX_AUDIT_START_TIME ON AUDIT.EXTRACT_AUDIT_LOG (START_TIME);

-- Daily rollup for dashboards
CREATE OR REPLACE TABLE AUDIT.EXTRACT_AUDIT_SUMMARY (
    SUMMARY_DATE        DATE            NOT NULL,
    CONFIG_ID           NUMBER          NOT NULL,
    CONFIG_NAME         VARCHAR(200)    NOT NULL,
    TOTAL_RUNS          NUMBER          DEFAULT 0,
    SUCCESSFUL_RUNS     NUMBER          DEFAULT 0,
    FAILED_RUNS         NUMBER          DEFAULT 0,
    AVG_DURATION_SEC    NUMBER,
    TOTAL_ROWS          NUMBER          DEFAULT 0,
    TOTAL_FILES         NUMBER          DEFAULT 0,
    TOTAL_BYTES         NUMBER          DEFAULT 0,
    LAST_RUN_STATUS     VARCHAR(20),
    LAST_RUN_TIME       TIMESTAMP_NTZ,
    PRIMARY KEY (SUMMARY_DATE, CONFIG_ID)
);

-- Per-file SFTP transfer detail: one row per file per destination per attempt
CREATE OR REPLACE TABLE AUDIT.SFTP_TRANSFER_LOG (
    TRANSFER_ID           NUMBER AUTOINCREMENT PRIMARY KEY,
    AUDIT_ID              NUMBER        NOT NULL,
    RUN_ID                VARCHAR(100)  NOT NULL,
    CONFIG_NAME           VARCHAR(200)  NOT NULL,

    -- File
    LOCAL_FILE_PATH       VARCHAR(1000),
    LOCAL_FILE_SIZE_BYTES NUMBER,
    CHECKSUM_TYPE         VARCHAR(10),
    CHECKSUM_VALUE        VARCHAR(128),

    -- Destination
    SFTP_HOST             VARCHAR(500)  NOT NULL,
    SFTP_PORT             NUMBER,
    SFTP_USERNAME         VARCHAR(200),
    SFTP_REMOTE_PATH      VARCHAR(1000) NOT NULL,
    SFTP_TEMP_PATH        VARCHAR(1000),

    -- Result  [STATUS: SUCCESS | FAILED | SKIPPED | RETRY]
    STATUS                VARCHAR(20)   NOT NULL,
    ATTEMPT_NUMBER        NUMBER        DEFAULT 1,
    TRANSFER_START        TIMESTAMP_NTZ NOT NULL,
    TRANSFER_END          TIMESTAMP_NTZ,
    DURATION_MS           NUMBER,
    THROUGHPUT_MBPS       FLOAT,

    -- Extras
    FLAG_FILE_PATH        VARCHAR(1000),
    CHECKSUM_FILE_PATH    VARCHAR(1000),
    PGP_ENCRYPTED         BOOLEAN       DEFAULT FALSE,

    -- Error
    ERROR_CODE            VARCHAR(100),
    ERROR_MESSAGE         TEXT,

    CREATED_AT            TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

COMMENT ON TABLE  AUDIT.SFTP_TRANSFER_LOG IS 'Per-file SFTP transfer detail log with retry tracking';
COMMENT ON COLUMN AUDIT.SFTP_TRANSFER_LOG.STATUS
    IS 'Transfer result. Allowed values: SUCCESS | FAILED | SKIPPED | RETRY';

CREATE OR REPLACE INDEX IDX_SFTP_LOG_RUN_ID  ON AUDIT.SFTP_TRANSFER_LOG (RUN_ID);
CREATE OR REPLACE INDEX IDX_SFTP_LOG_STATUS  ON AUDIT.SFTP_TRANSFER_LOG (STATUS);
CREATE OR REPLACE INDEX IDX_SFTP_LOG_CREATED ON AUDIT.SFTP_TRANSFER_LOG (CREATED_AT);

-- Reusable SFTP server connection profiles
-- [SFTP_AUTH_TYPE: PASSWORD | KEY]
CREATE OR REPLACE TABLE FRAMEWORK.SFTP_CONNECTION_REGISTRY (
    CONNECTION_ID        NUMBER AUTOINCREMENT PRIMARY KEY,
    CONNECTION_NAME      VARCHAR(200)   NOT NULL UNIQUE,
    IS_ACTIVE            BOOLEAN        DEFAULT TRUE,
    SFTP_HOST            VARCHAR(500)   NOT NULL,
    SFTP_PORT            NUMBER         DEFAULT 22,
    SFTP_USERNAME        VARCHAR(200)   NOT NULL,
    SFTP_SECRET_NAME     VARCHAR(200)   NOT NULL,
    SFTP_AUTH_TYPE       VARCHAR(20)    DEFAULT 'PASSWORD',
    SFTP_KNOWN_HOST_KEY  VARCHAR(2000),
    SFTP_HOST_KEY_BYPASS BOOLEAN        DEFAULT FALSE,
    CONNECT_TIMEOUT      NUMBER         DEFAULT 30,
    BANNER_TIMEOUT       NUMBER         DEFAULT 15,
    KEEP_ALIVE_SEC       NUMBER         DEFAULT 60,
    NOTES                TEXT,
    CREATED_BY           VARCHAR(200)   DEFAULT CURRENT_USER(),
    CREATED_AT           TIMESTAMP_NTZ  DEFAULT CURRENT_TIMESTAMP()
);

COMMENT ON TABLE  FRAMEWORK.SFTP_CONNECTION_REGISTRY
    IS 'Reusable SFTP server connection profiles referenced by extract configs';
COMMENT ON COLUMN FRAMEWORK.SFTP_CONNECTION_REGISTRY.SFTP_AUTH_TYPE
    IS 'Authentication method. Allowed values: PASSWORD | KEY';

-- =============================================================================
-- SECTION 7: SAMPLE CONFIGURATION INSERTS
-- =============================================================================

-- 1. Daily CSV extract to S3
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, DELIMITER, INCLUDE_HEADER, COMPRESSION,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE, NOTES
) VALUES (
    'DAILY_SALES_EXTRACT',
    'SALES_DB', 'PUBLIC', 'DAILY_SALES_VW',
    'CSV', 'DAILY_SALES_{YYYYMMDD}.csv', ',', TRUE, 'GZIP',
    TRUE, 'MY_S3_STAGE', 'extracts/sales/daily/',
    TRUE, '0 6 * * *', 'COMPUTE_WH',
    'Daily sales extract — runs at 6 AM UTC'
);

-- 2. Custom query with S3 + SFTP delivery
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA,
    SOURCE_QUERY, FILTER_CONDITION,
    FILE_FORMAT, FILE_NAME_PATTERN, DELIMITER, INCLUDE_HEADER,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SFTP_ENABLED, SFTP_HOST, SFTP_PORT, SFTP_USERNAME,
    SFTP_SECRET_NAME, SFTP_REMOTE_PATH, SFTP_AUTH_TYPE,
    SFTP_RETRY_ATTEMPTS, SFTP_CHECKSUM_ENABLED,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE, NOTES
) VALUES (
    'CUSTOMER_SFTP_EXPORT',
    'CRM_DB', 'PUBLIC',
    'SELECT c.CUSTOMER_ID, c.FIRST_NAME, c.LAST_NAME, c.EMAIL, o.ORDER_COUNT, o.TOTAL_SPEND
       FROM CUSTOMERS c JOIN ORDER_SUMMARY o ON c.CUSTOMER_ID = o.CUSTOMER_ID',
    'c.IS_ACTIVE = TRUE',
    'CSV', 'CUSTOMERS_{YYYYMMDD_HH24MISS}.csv.gz', '|', TRUE,
    TRUE, 'MY_S3_STAGE', 'extracts/customers/',
    TRUE, 'sftp.partner.com', 22, 'data_transfer',
    'SFTP_PARTNER_SECRET', '/inbound/customers/', 'PASSWORD',
    3, TRUE,
    TRUE, '0 8 * * 1', 'COMPUTE_WH',
    'Weekly customer file to partner SFTP — every Monday 8 AM'
);

-- 3. Parquet hourly export
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, COMPRESSION,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SCHEDULE_ENABLED, SCHEDULE_MINUTES, SCHEDULE_WAREHOUSE, NOTES
) VALUES (
    'EVENTS_PARQUET_HOURLY',
    'ANALYTICS_DB', 'RAW', 'EVENTS',
    'PARQUET', 'events_{YYYYMMDD_HH24}.parquet', 'SNAPPY',
    TRUE, 'MY_S3_STAGE', 'extracts/events/parquet/',
    TRUE, 60, 'COMPUTE_WH',
    'Hourly events export in Parquet format'
);

-- 4. SFTP-ONLY (no S3 intermediate stage)
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, DELIMITER, COMPRESSION,
    S3_ENABLED,
    SFTP_ENABLED, SFTP_ONLY,
    SFTP_HOST, SFTP_PORT, SFTP_USERNAME, SFTP_SECRET_NAME,
    SFTP_REMOTE_PATH, SFTP_AUTH_TYPE,
    SFTP_RETRY_ATTEMPTS, SFTP_RETRY_DELAY_SEC,
    SFTP_CHECKSUM_ENABLED, SFTP_CHECKSUM_TYPE,
    SFTP_FLAG_FILE_ENABLED, SFTP_FLAG_FILE_SUFFIX,
    SFTP_TEMP_SUFFIX, SFTP_RENAME_ON_COMPLETE,
    SFTP_REMOTE_RETENTION_DAYS,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE, NOTES
) VALUES (
    'PARTNER_DAILY_REPORT_SFTP_ONLY',
    'REPORTING_DB', 'PUBLIC', 'DAILY_PARTNER_REPORT_VW',
    'CSV', 'PARTNER_RPT_{YYYYMMDD}.csv', '|', 'GZIP',
    FALSE,
    TRUE, TRUE,
    'sftp.partner.com', 22, 'transfer_user', 'PARTNER_SFTP_SECRET',
    '/inbound/reports/', 'PASSWORD',
    3, 30,
    TRUE, 'MD5',
    TRUE, '.done',
    '.tmp', TRUE,
    7,
    TRUE, '0 7 * * *', 'COMPUTE_WH',
    'Daily report direct to partner SFTP, no S3 intermediate'
);

-- 5. S3 + SFTP with PGP encryption
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, COMPRESSION,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SFTP_ENABLED, SFTP_HOST, SFTP_PORT, SFTP_USERNAME,
    SFTP_SECRET_NAME, SFTP_REMOTE_PATH,
    SFTP_RETRY_ATTEMPTS, SFTP_CHECKSUM_ENABLED,
    SFTP_PGP_ENABLED, SFTP_PGP_KEY_SECRET,
    SFTP_RENAME_ON_COMPLETE,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE
) VALUES (
    'SECURE_FINANCE_EXPORT',
    'FINANCE_DB', 'PUBLIC', 'FINANCIAL_SUMMARY',
    'CSV', 'FINANCE_{YYYYMMDD}.csv', 'NONE',
    TRUE, 'MY_S3_STAGE', 'extracts/finance/',
    TRUE, 'sftp.bank-partner.com', 22, 'bank_user',
    'BANK_SFTP_SECRET', '/secure/inbound/',
    5, TRUE,
    TRUE, 'FINANCE_PGP_PUBKEY_SECRET',
    TRUE,
    TRUE, '0 5 * * 1-5', 'COMPUTE_WH'
);

-- 6. Multi-destination broadcast (primary + secondary SFTP targets)
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SFTP_ENABLED, SFTP_HOST, SFTP_USERNAME, SFTP_SECRET_NAME,
    SFTP_REMOTE_PATH, SFTP_SECONDARY_TARGETS,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE
) VALUES (
    'MULTI_DEST_BROADCAST',
    'SALES_DB', 'PUBLIC', 'SALES_SUMMARY',
    'CSV', 'SALES_{YYYYMMDD}.csv',
    TRUE, 'MY_S3_STAGE', 'extracts/sales/',
    TRUE, 'sftp.primary-partner.com', 'user_a', 'PARTNER_A_SECRET',
    '/data/inbound/',
    PARSE_JSON('[
        {"host":"sftp.partner-b.com","port":22,"username":"user_b","secret_name":"PARTNER_B_SECRET","remote_path":"/uploads/","auth_type":"PASSWORD"},
        {"host":"sftp.partner-c.com","port":2222,"username":"user_c","secret_name":"PARTNER_C_KEY_SECRET","remote_path":"/receive/","auth_type":"KEY"}
    ]'),
    TRUE, '0 8 * * *', 'COMPUTE_WH'
);

-- =============================================================================
-- SECTION 8: VERIFY DEPLOYMENT
-- =============================================================================
-- Run after this file to confirm everything was created:
--
-- SHOW STAGES  IN SCHEMA DATA_EXTRACT_DB.FRAMEWORK;
-- SELECT CONFIG_ID, CONFIG_NAME, IS_ACTIVE, FILE_FORMAT, COMPRESSION
-- FROM DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG;
