-- =============================================================================
-- DATA EXTRACT FRAMEWORK - PART 2: STORED PROCEDURES, TASKS & VIEWS
-- =============================================================================
-- Consolidates: 03_stored_procedures_and_tasks.sql + 08_sftp_stored_procedures.sql
--
-- EXECUTION ORDER: Run AFTER 01_SCHEMA_AND_CONFIG.sql and after uploading
--                  03_data_extract_engine.py to CODE_STAGE.
--
-- Required file in @FRAMEWORK.CODE_STAGE:
--   03_data_extract_engine.py   (consolidated: utilities + audit + S3 + SFTP + engine)
-- =============================================================================

USE ROLE SYSADMIN;
USE DATABASE DATA_EXTRACT_DB;
USE WAREHOUSE COMPUTE_WH;

-- =============================================================================
-- SECTION 1: EXTRACT STORED PROCEDURES  (v2 engine — full S3 + SFTP support)
-- =============================================================================

-- Run a single extract job by name
CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_EXTRACT_BY_NAME(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION  = '3.10'
PACKAGES         = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER          = 'data_extract_engine.run_extract_by_name'
IMPORTS          = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine.py')
COMMENT          = 'Run a named extract job (v2: full S3 + SFTP support)';

-- Run a single extract job by numeric config ID
CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_EXTRACT_BY_ID(CONFIG_ID NUMBER)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION  = '3.10'
PACKAGES         = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER          = 'data_extract_engine.run_extract_by_id'
IMPORTS          = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine.py')
COMMENT          = 'Run an extract job by config ID (v2: full S3 + SFTP support)';

-- Run ALL active extract configurations
CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_ALL_EXTRACTS()
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION  = '3.10'
PACKAGES         = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER          = 'data_extract_engine.run_all_extracts'
IMPORTS          = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine.py')
COMMENT          = 'Run all active extract jobs (v2: full S3 + SFTP support)';

-- Preview the effective SQL for an extract without executing any transfers
CREATE OR REPLACE PROCEDURE FRAMEWORK.DRY_RUN_EXTRACT(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION  = '3.10'
PACKAGES         = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER          = 'data_extract_engine.dry_run_extract'
IMPORTS          = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine.py')
COMMENT          = 'Preview extract SQL without running any transfers';

-- Test SFTP connectivity for a config (no file transfer)
CREATE OR REPLACE PROCEDURE FRAMEWORK.TEST_SFTP_CONNECTION(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION  = '3.10'
PACKAGES         = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER          = 'data_extract_engine.test_sftp_connection'
IMPORTS          = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine.py')
COMMENT          = 'Test SFTP connectivity for a config without transferring files';

-- =============================================================================
-- SECTION 2: VALIDATION STORED PROCEDURE
-- Replaces CHECK constraints with explicit runtime validation.
-- Use this procedure for all inserts and updates to EXTRACT_CONFIG.
-- Returns 'OK' on success or raises an exception with a descriptive message.
-- =============================================================================

CREATE OR REPLACE PROCEDURE FRAMEWORK.UPSERT_EXTRACT_CONFIG(
    p_config_name       VARCHAR,
    p_source_database   VARCHAR,
    p_source_schema     VARCHAR,
    p_source_table      VARCHAR,          -- NULL if SOURCE_QUERY is used
    p_source_query      VARCHAR,          -- NULL if SOURCE_TABLE is used
    p_filter_condition  VARCHAR,
    p_file_format       VARCHAR,          -- CSV | PARQUET | JSON
    p_file_name_pattern VARCHAR,
    p_delimiter         VARCHAR,
    p_compression       VARCHAR,          -- NONE | GZIP | BZ2 | ZSTD | AUTO
    p_include_header    BOOLEAN,
    p_s3_enabled        BOOLEAN,
    p_s3_stage_name     VARCHAR,
    p_s3_path_prefix    VARCHAR,
    p_sftp_enabled      BOOLEAN,
    p_sftp_only         BOOLEAN,
    p_sftp_host         VARCHAR,
    p_sftp_username     VARCHAR,
    p_sftp_secret_name  VARCHAR,
    p_sftp_auth_type    VARCHAR,          -- PASSWORD | KEY
    p_sftp_checksum_type VARCHAR,         -- MD5 | SHA256 | SHA512
    p_schedule_enabled  BOOLEAN,
    p_schedule_cron     VARCHAR,
    p_schedule_minutes  NUMBER,
    p_schedule_warehouse VARCHAR,
    p_notes             VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Validated insert/update for EXTRACT_CONFIG. Enforces allowed values in place of CHECK constraints.'
AS
$$
DECLARE
    v_existing_id NUMBER;
BEGIN
    -- -------------------------------------------------------------------------
    -- VALIDATION BLOCK  (replaces CHECK constraints)
    -- -------------------------------------------------------------------------

    IF p_file_format NOT IN ('CSV', 'PARQUET', 'JSON') THEN
        RAISE EXCEPTION
            'Invalid FILE_FORMAT: ''%''. Allowed values: CSV | PARQUET | JSON',
            p_file_format;
    END IF;

    IF p_compression NOT IN ('NONE', 'GZIP', 'BZ2', 'ZSTD', 'AUTO') THEN
        RAISE EXCEPTION
            'Invalid COMPRESSION: ''%''. Allowed values: NONE | GZIP | BZ2 | ZSTD | AUTO',
            p_compression;
    END IF;

    IF p_sftp_auth_type IS NOT NULL
       AND p_sftp_auth_type NOT IN ('PASSWORD', 'KEY') THEN
        RAISE EXCEPTION
            'Invalid SFTP_AUTH_TYPE: ''%''. Allowed values: PASSWORD | KEY',
            p_sftp_auth_type;
    END IF;

    IF p_sftp_checksum_type IS NOT NULL
       AND p_sftp_checksum_type NOT IN ('MD5', 'SHA256', 'SHA512') THEN
        RAISE EXCEPTION
            'Invalid SFTP_CHECKSUM_TYPE: ''%''. Allowed values: MD5 | SHA256 | SHA512',
            p_sftp_checksum_type;
    END IF;

    IF p_source_table IS NULL AND p_source_query IS NULL THEN
        RAISE EXCEPTION
            'Config ''%'': SOURCE_TABLE and SOURCE_QUERY cannot both be NULL.',
            p_config_name;
    END IF;

    IF p_sftp_enabled AND (p_sftp_host IS NULL OR p_sftp_secret_name IS NULL) THEN
        RAISE EXCEPTION
            'Config ''%'': SFTP_ENABLED=TRUE requires SFTP_HOST and SFTP_SECRET_NAME.',
            p_config_name;
    END IF;

    IF p_s3_enabled AND p_s3_stage_name IS NULL THEN
        RAISE EXCEPTION
            'Config ''%'': S3_ENABLED=TRUE requires S3_STAGE_NAME.',
            p_config_name;
    END IF;

    IF p_schedule_enabled
       AND p_schedule_cron IS NULL
       AND p_schedule_minutes IS NULL THEN
        RAISE EXCEPTION
            'Config ''%'': SCHEDULE_ENABLED=TRUE requires SCHEDULE_CRON or SCHEDULE_MINUTES.',
            p_config_name;
    END IF;

    -- -------------------------------------------------------------------------
    -- UPSERT
    -- -------------------------------------------------------------------------

    SELECT CONFIG_ID INTO v_existing_id
    FROM FRAMEWORK.EXTRACT_CONFIG
    WHERE CONFIG_NAME = p_config_name;

    IF (v_existing_id IS NOT NULL) THEN
        UPDATE FRAMEWORK.EXTRACT_CONFIG
        SET
            SOURCE_DATABASE    = p_source_database,
            SOURCE_SCHEMA      = p_source_schema,
            SOURCE_TABLE       = p_source_table,
            SOURCE_QUERY       = p_source_query,
            FILTER_CONDITION   = p_filter_condition,
            FILE_FORMAT        = p_file_format,
            FILE_NAME_PATTERN  = p_file_name_pattern,
            DELIMITER          = p_delimiter,
            COMPRESSION        = p_compression,
            INCLUDE_HEADER     = p_include_header,
            S3_ENABLED         = p_s3_enabled,
            S3_STAGE_NAME      = p_s3_stage_name,
            S3_PATH_PREFIX     = p_s3_path_prefix,
            SFTP_ENABLED       = p_sftp_enabled,
            SFTP_ONLY          = p_sftp_only,
            SFTP_HOST          = p_sftp_host,
            SFTP_USERNAME      = p_sftp_username,
            SFTP_SECRET_NAME   = p_sftp_secret_name,
            SFTP_AUTH_TYPE     = p_sftp_auth_type,
            SFTP_CHECKSUM_TYPE = p_sftp_checksum_type,
            SCHEDULE_ENABLED   = p_schedule_enabled,
            SCHEDULE_CRON      = p_schedule_cron,
            SCHEDULE_MINUTES   = p_schedule_minutes,
            SCHEDULE_WAREHOUSE = p_schedule_warehouse,
            NOTES              = p_notes,
            UPDATED_BY         = CURRENT_USER(),
            UPDATED_AT         = CURRENT_TIMESTAMP()
        WHERE CONFIG_NAME = p_config_name;

        RETURN 'UPDATED: ' || p_config_name;
    ELSE
        INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
            CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA,
            SOURCE_TABLE, SOURCE_QUERY, FILTER_CONDITION,
            FILE_FORMAT, FILE_NAME_PATTERN, DELIMITER, COMPRESSION, INCLUDE_HEADER,
            S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
            SFTP_ENABLED, SFTP_ONLY, SFTP_HOST, SFTP_USERNAME,
            SFTP_SECRET_NAME, SFTP_AUTH_TYPE, SFTP_CHECKSUM_TYPE,
            SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_MINUTES,
            SCHEDULE_WAREHOUSE, NOTES
        ) VALUES (
            p_config_name, p_source_database, p_source_schema,
            p_source_table, p_source_query, p_filter_condition,
            p_file_format, p_file_name_pattern, p_delimiter, p_compression, p_include_header,
            p_s3_enabled, p_s3_stage_name, p_s3_path_prefix,
            p_sftp_enabled, p_sftp_only, p_sftp_host, p_sftp_username,
            p_sftp_secret_name, p_sftp_auth_type, p_sftp_checksum_type,
            p_schedule_enabled, p_schedule_cron, p_schedule_minutes,
            p_schedule_warehouse, p_notes
        );

        RETURN 'INSERTED: ' || p_config_name;
    END IF;
END;
$$;

-- =============================================================================
-- SECTION 3: STATIC SNOWFLAKE TASKS (per-config schedules)
-- =============================================================================

CREATE OR REPLACE TASK FRAMEWORK.TASK_DAILY_SALES_EXTRACT
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 0 6 * * * UTC'
    COMMENT   = 'Automated: Daily sales data extract to S3'
AS
    CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('DAILY_SALES_EXTRACT');

CREATE OR REPLACE TASK FRAMEWORK.TASK_CUSTOMER_SFTP_EXPORT
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 0 8 * * 1 UTC'
    COMMENT   = 'Automated: Weekly customer file to partner SFTP'
AS
    CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('CUSTOMER_SFTP_EXPORT');

CREATE OR REPLACE TASK FRAMEWORK.TASK_EVENTS_PARQUET_HOURLY
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = '60 MINUTE'
    COMMENT   = 'Automated: Hourly events data in Parquet format'
AS
    CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('EVENTS_PARQUET_HOURLY');

-- Master task: runs ALL active extracts every hour on the hour.
-- Uncomment ALTER TASK ... RESUME below to activate.
CREATE OR REPLACE TASK FRAMEWORK.TASK_RUN_ALL_EXTRACTS
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 0 * * * * UTC'
    COMMENT   = 'Master task: runs all active extract configurations'
AS
    CALL FRAMEWORK.RUN_ALL_EXTRACTS();

-- Activate static tasks
ALTER TASK FRAMEWORK.TASK_DAILY_SALES_EXTRACT   RESUME;
ALTER TASK FRAMEWORK.TASK_CUSTOMER_SFTP_EXPORT  RESUME;
ALTER TASK FRAMEWORK.TASK_EVENTS_PARQUET_HOURLY RESUME;
-- ALTER TASK FRAMEWORK.TASK_RUN_ALL_EXTRACTS   RESUME;  -- Uncomment to use master task

-- To pause a task:
-- ALTER TASK FRAMEWORK.TASK_DAILY_SALES_EXTRACT SUSPEND;

-- =============================================================================
-- SECTION 4: DYNAMIC TASK GENERATOR
-- Auto-creates or drops tasks based on EXTRACT_CONFIG schedule settings.
-- Usage: CALL FRAMEWORK.SYNC_EXTRACT_TASKS();
-- =============================================================================

CREATE OR REPLACE PROCEDURE FRAMEWORK.SYNC_EXTRACT_TASKS()
RETURNS TABLE (CONFIG_NAME VARCHAR, ACTION VARCHAR, STATUS VARCHAR, MESSAGE VARCHAR)
LANGUAGE SQL
COMMENT = 'Auto-creates or drops Snowflake tasks based on EXTRACT_CONFIG schedule settings'
AS
$$
DECLARE
    result_table RESULTSET;
    cur CURSOR FOR
        SELECT CONFIG_ID, CONFIG_NAME, SCHEDULE_CRON, SCHEDULE_MINUTES,
               SCHEDULE_WAREHOUSE, IS_ACTIVE, SCHEDULE_ENABLED
        FROM DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG;

    task_name   VARCHAR;
    schedule    VARCHAR;
    warehouse   VARCHAR;
    action_desc VARCHAR;
    status_msg  VARCHAR;
    msg         VARCHAR;
BEGIN
    CREATE OR REPLACE TEMPORARY TABLE TASK_SYNC_RESULTS (
        CONFIG_NAME VARCHAR, ACTION VARCHAR, STATUS VARCHAR, MESSAGE VARCHAR
    );

    FOR cfg IN cur DO
        task_name   := 'FRAMEWORK.TASK_AUTO_' || REPLACE(cfg.CONFIG_NAME, ' ', '_');
        warehouse   := COALESCE(cfg.SCHEDULE_WAREHOUSE, 'COMPUTE_WH');
        action_desc := 'NONE';
        status_msg  := 'OK';
        msg         := '';

        IF (cfg.IS_ACTIVE AND cfg.SCHEDULE_ENABLED) THEN
            IF (cfg.SCHEDULE_CRON IS NOT NULL) THEN
                schedule := 'USING CRON ' || cfg.SCHEDULE_CRON || ' UTC';
            ELSEIF (cfg.SCHEDULE_MINUTES IS NOT NULL) THEN
                schedule := cfg.SCHEDULE_MINUTES || ' MINUTE';
            ELSE
                INSERT INTO TASK_SYNC_RESULTS VALUES (
                    cfg.CONFIG_NAME, 'SKIP', 'WARNING',
                    'SCHEDULE_ENABLED=TRUE but no SCHEDULE_CRON or SCHEDULE_MINUTES set'
                );
                CONTINUE;
            END IF;

            LET create_sql VARCHAR :=
                'CREATE OR REPLACE TASK ' || task_name ||
                ' WAREHOUSE = ' || warehouse ||
                ' SCHEDULE = ''' || schedule || '''' ||
                ' COMMENT = ''Auto-generated task for config: ' || cfg.CONFIG_NAME || '''' ||
                ' AS CALL FRAMEWORK.RUN_EXTRACT_BY_ID(' || cfg.CONFIG_ID || ')';

            EXECUTE IMMEDIATE create_sql;
            EXECUTE IMMEDIATE 'ALTER TASK ' || task_name || ' RESUME';
            action_desc := 'CREATED_AND_RESUMED';
            msg := 'Task created with schedule: ' || schedule;

        ELSE
            EXECUTE IMMEDIATE 'DROP TASK IF EXISTS ' || task_name;
            action_desc := 'DROPPED';
            msg := 'Dropped because IS_ACTIVE=FALSE or SCHEDULE_ENABLED=FALSE';
        END IF;

        INSERT INTO TASK_SYNC_RESULTS VALUES (cfg.CONFIG_NAME, action_desc, status_msg, msg);
    END FOR;

    result_table := (SELECT * FROM TASK_SYNC_RESULTS ORDER BY CONFIG_NAME);
    RETURN TABLE(result_table);
END;
$$;

-- =============================================================================
-- SECTION 5: CONFIG VALIDATION — STREAM + TASK + VIEW
-- Detects rows with invalid column values and auto-flags them IS_ACTIVE=FALSE.
-- This catches any rows inserted directly (bypassing UPSERT_EXTRACT_CONFIG).
-- =============================================================================

-- Stream watches EXTRACT_CONFIG for inserts and updates
CREATE OR REPLACE STREAM FRAMEWORK.EXTRACT_CONFIG_STREAM
    ON TABLE FRAMEWORK.EXTRACT_CONFIG
    COMMENT = 'Watches EXTRACT_CONFIG for new and changed rows to validate';

-- Task fires whenever new stream data exists; flags invalid rows
CREATE OR REPLACE TASK FRAMEWORK.VALIDATE_CONFIG_TASK
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = '1 MINUTE'
    COMMENT   = 'Auto-flags EXTRACT_CONFIG rows with invalid column values'
WHEN
    SYSTEM$STREAM_HAS_DATA('FRAMEWORK.EXTRACT_CONFIG_STREAM')
AS
    UPDATE FRAMEWORK.EXTRACT_CONFIG
    SET
        IS_ACTIVE = FALSE,
        NOTES     = COALESCE(NOTES || ' | ', '') ||
                    'AUTO-FLAGGED INVALID at ' || TO_VARCHAR(CURRENT_TIMESTAMP()) || ': ' ||
                    CASE
                        WHEN FILE_FORMAT NOT IN ('CSV','PARQUET','JSON')
                            THEN 'Bad FILE_FORMAT=' || FILE_FORMAT
                        WHEN COMPRESSION NOT IN ('NONE','GZIP','BZ2','ZSTD','AUTO')
                            THEN 'Bad COMPRESSION=' || COMPRESSION
                        WHEN SFTP_AUTH_TYPE IS NOT NULL
                             AND SFTP_AUTH_TYPE NOT IN ('PASSWORD','KEY')
                            THEN 'Bad SFTP_AUTH_TYPE=' || SFTP_AUTH_TYPE
                        WHEN SFTP_CHECKSUM_TYPE IS NOT NULL
                             AND SFTP_CHECKSUM_TYPE NOT IN ('MD5','SHA256','SHA512')
                            THEN 'Bad SFTP_CHECKSUM_TYPE=' || SFTP_CHECKSUM_TYPE
                        ELSE 'Unknown violation'
                    END
    WHERE CONFIG_ID IN (
        SELECT CONFIG_ID
        FROM FRAMEWORK.EXTRACT_CONFIG_STREAM
        WHERE METADATA$ACTION = 'INSERT'
    )
    AND (
        FILE_FORMAT     NOT IN ('CSV','PARQUET','JSON')
        OR COMPRESSION  NOT IN ('NONE','GZIP','BZ2','ZSTD','AUTO')
        OR (SFTP_AUTH_TYPE    IS NOT NULL AND SFTP_AUTH_TYPE    NOT IN ('PASSWORD','KEY'))
        OR (SFTP_CHECKSUM_TYPE IS NOT NULL AND SFTP_CHECKSUM_TYPE NOT IN ('MD5','SHA256','SHA512'))
    );

ALTER TASK FRAMEWORK.VALIDATE_CONFIG_TASK RESUME;

-- =============================================================================
-- SECTION 6: AUDIT & MONITORING VIEWS
-- =============================================================================

-- Full run history with config metadata
CREATE OR REPLACE VIEW AUDIT.V_EXTRACT_RUN_HISTORY AS
SELECT
    al.AUDIT_ID,
    al.RUN_ID,
    al.CONFIG_NAME,
    al.STATUS,
    al.START_TIME,
    al.END_TIME,
    al.DURATION_SECONDS,
    al.ROWS_EXTRACTED,
    al.FILES_GENERATED,
    al.BYTES_WRITTEN,
    ROUND(al.BYTES_WRITTEN / NULLIF(al.ROWS_EXTRACTED, 0), 0) AS BYTES_PER_ROW,
    al.S3_FILES_UPLOADED,
    al.SFTP_FILES_UPLOADED,
    al.ERROR_CODE,
    al.ERROR_MESSAGE,
    al.EXECUTED_BY,
    al.WAREHOUSE_NAME,
    ec.FILE_FORMAT,
    ec.S3_STAGE_NAME,
    ec.SFTP_HOST
FROM AUDIT.EXTRACT_AUDIT_LOG     al
LEFT JOIN FRAMEWORK.EXTRACT_CONFIG ec ON al.CONFIG_ID = ec.CONFIG_ID
ORDER BY al.START_TIME DESC;

-- Latest run status per extract job with cumulative stats
CREATE OR REPLACE VIEW AUDIT.V_EXTRACT_LAST_RUN AS
SELECT
    ec.CONFIG_ID,
    ec.CONFIG_NAME,
    ec.IS_ACTIVE,
    ec.SCHEDULE_ENABLED,
    ec.SCHEDULE_CRON,
    latest.STATUS           AS LAST_STATUS,
    latest.START_TIME       AS LAST_RUN_TIME,
    latest.DURATION_SECONDS AS LAST_DURATION_SEC,
    latest.ROWS_EXTRACTED   AS LAST_ROWS,
    latest.FILES_GENERATED  AS LAST_FILES,
    latest.ERROR_MESSAGE    AS LAST_ERROR,
    summary.TOTAL_RUNS,
    summary.SUCCESSFUL_RUNS,
    summary.FAILED_RUNS,
    ROUND(summary.SUCCESSFUL_RUNS * 100.0 / NULLIF(summary.TOTAL_RUNS, 0), 1) AS SUCCESS_RATE_PCT
FROM FRAMEWORK.EXTRACT_CONFIG ec
LEFT JOIN LATERAL (
    SELECT STATUS, START_TIME, DURATION_SECONDS, ROWS_EXTRACTED, FILES_GENERATED, ERROR_MESSAGE
    FROM AUDIT.EXTRACT_AUDIT_LOG
    WHERE CONFIG_ID = ec.CONFIG_ID
    ORDER BY START_TIME DESC
    LIMIT 1
) latest ON TRUE
LEFT JOIN LATERAL (
    SELECT
        SUM(TOTAL_RUNS)      AS TOTAL_RUNS,
        SUM(SUCCESSFUL_RUNS) AS SUCCESSFUL_RUNS,
        SUM(FAILED_RUNS)     AS FAILED_RUNS
    FROM AUDIT.EXTRACT_AUDIT_SUMMARY
    WHERE CONFIG_ID = ec.CONFIG_ID
) summary ON TRUE;

-- Config validation violations — surfaces any row with an invalid column value
CREATE OR REPLACE VIEW FRAMEWORK.V_CONFIG_VIOLATIONS AS
SELECT
    CONFIG_ID,
    CONFIG_NAME,
    IS_ACTIVE,
    FILE_FORMAT,
    COMPRESSION,
    SFTP_AUTH_TYPE,
    SFTP_CHECKSUM_TYPE,
    CASE
        WHEN FILE_FORMAT NOT IN ('CSV','PARQUET','JSON')
            THEN 'Bad FILE_FORMAT: ' || FILE_FORMAT
        WHEN COMPRESSION NOT IN ('NONE','GZIP','BZ2','ZSTD','AUTO')
            THEN 'Bad COMPRESSION: ' || COMPRESSION
        WHEN SFTP_AUTH_TYPE IS NOT NULL
             AND SFTP_AUTH_TYPE NOT IN ('PASSWORD','KEY')
            THEN 'Bad SFTP_AUTH_TYPE: ' || SFTP_AUTH_TYPE
        WHEN SFTP_CHECKSUM_TYPE IS NOT NULL
             AND SFTP_CHECKSUM_TYPE NOT IN ('MD5','SHA256','SHA512')
            THEN 'Bad SFTP_CHECKSUM_TYPE: ' || SFTP_CHECKSUM_TYPE
    END AS VIOLATION,
    NOTES
FROM FRAMEWORK.EXTRACT_CONFIG
WHERE FILE_FORMAT     NOT IN ('CSV','PARQUET','JSON')
   OR COMPRESSION     NOT IN ('NONE','GZIP','BZ2','ZSTD','AUTO')
   OR (SFTP_AUTH_TYPE     IS NOT NULL AND SFTP_AUTH_TYPE     NOT IN ('PASSWORD','KEY'))
   OR (SFTP_CHECKSUM_TYPE IS NOT NULL AND SFTP_CHECKSUM_TYPE NOT IN ('MD5','SHA256','SHA512'));

COMMENT ON VIEW FRAMEWORK.V_CONFIG_VIOLATIONS
    IS 'Surfaces EXTRACT_CONFIG rows with invalid column values — replaces CHECK constraint enforcement';

-- SFTP transfer history joined to extract audit
CREATE OR REPLACE VIEW AUDIT.V_SFTP_TRANSFER_HISTORY AS
SELECT
    t.TRANSFER_ID,
    t.RUN_ID,
    t.CONFIG_NAME,
    t.SFTP_HOST,
    t.SFTP_REMOTE_PATH,
    t.STATUS,
    t.ATTEMPT_NUMBER,
    t.LOCAL_FILE_SIZE_BYTES,
    t.THROUGHPUT_MBPS,
    t.DURATION_MS,
    t.CHECKSUM_TYPE,
    t.CHECKSUM_VALUE,
    t.PGP_ENCRYPTED,
    t.FLAG_FILE_PATH,
    t.TRANSFER_START,
    t.TRANSFER_END,
    t.ERROR_CODE,
    t.ERROR_MESSAGE,
    a.ROWS_EXTRACTED,
    a.SFTP_RETRY_COUNT
FROM AUDIT.SFTP_TRANSFER_LOG t
JOIN AUDIT.EXTRACT_AUDIT_LOG a ON t.RUN_ID = a.RUN_ID
ORDER BY t.TRANSFER_START DESC;

-- SFTP failures only
CREATE OR REPLACE VIEW AUDIT.V_SFTP_FAILED_TRANSFERS AS
SELECT
    CONFIG_NAME, SFTP_HOST, SFTP_REMOTE_PATH,
    ATTEMPT_NUMBER, TRANSFER_START, ERROR_CODE, ERROR_MESSAGE
FROM AUDIT.SFTP_TRANSFER_LOG
WHERE STATUS = 'FAILED'
ORDER BY TRANSFER_START DESC;

-- Daily throughput and volume stats per config and SFTP host
CREATE OR REPLACE VIEW AUDIT.V_SFTP_THROUGHPUT_STATS AS
SELECT
    CONFIG_NAME,
    SFTP_HOST,
    DATE(TRANSFER_START)                     AS TRANSFER_DATE,
    COUNT(*)                                 AS TOTAL_FILES,
    SUM(LOCAL_FILE_SIZE_BYTES) / 1024 / 1024 AS TOTAL_MB,
    AVG(THROUGHPUT_MBPS)                     AS AVG_THROUGHPUT_MBPS,
    MAX(THROUGHPUT_MBPS)                     AS MAX_THROUGHPUT_MBPS,
    AVG(DURATION_MS) / 1000                  AS AVG_DURATION_SEC,
    SUM(CASE WHEN STATUS = 'SUCCESS' THEN 1 ELSE 0 END) AS SUCCESS_COUNT,
    SUM(CASE WHEN STATUS = 'FAILED'  THEN 1 ELSE 0 END) AS FAIL_COUNT
FROM AUDIT.SFTP_TRANSFER_LOG
GROUP BY 1, 2, 3
ORDER BY TRANSFER_DATE DESC;

-- =============================================================================
-- SECTION 7: USEFUL AUDIT QUERIES (reference / ad-hoc)
-- =============================================================================

-- Check for config violations right now:
-- SELECT * FROM FRAMEWORK.V_CONFIG_VIOLATIONS;

-- Recent run history (last 24 hours):
-- SELECT CONFIG_NAME, STATUS, START_TIME, DURATION_SECONDS,
--        ROWS_EXTRACTED, FILES_GENERATED, ERROR_MESSAGE
-- FROM AUDIT.V_EXTRACT_RUN_HISTORY
-- WHERE START_TIME >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
-- ORDER BY START_TIME DESC;

-- Failed runs (last 7 days):
-- SELECT CONFIG_NAME, RUN_ID, START_TIME, ERROR_CODE, ERROR_MESSAGE
-- FROM AUDIT.EXTRACT_AUDIT_LOG
-- WHERE STATUS = 'FAILED'
--   AND START_TIME >= DATEADD('day', -7, CURRENT_TIMESTAMP())
-- ORDER BY START_TIME DESC;

-- Last run status per extract job:
-- SELECT * FROM AUDIT.V_EXTRACT_LAST_RUN ORDER BY CONFIG_NAME;

-- Daily summary (rows, files, MB):
-- SELECT SUMMARY_DATE, CONFIG_NAME, TOTAL_RUNS, SUCCESSFUL_RUNS,
--        FAILED_RUNS, TOTAL_ROWS, TOTAL_FILES,
--        ROUND(TOTAL_BYTES / 1024 / 1024, 2) AS TOTAL_MB
-- FROM AUDIT.EXTRACT_AUDIT_SUMMARY
-- ORDER BY SUMMARY_DATE DESC, CONFIG_NAME;

-- SFTP retry analysis (last 30 days):
-- SELECT CONFIG_NAME, SFTP_HOST,
--        COUNT(DISTINCT RUN_ID)  AS RUNS_WITH_RETRIES,
--        SUM(ATTEMPT_NUMBER - 1) AS TOTAL_RETRIES,
--        AVG(ATTEMPT_NUMBER)     AS AVG_ATTEMPTS_PER_FILE
-- FROM AUDIT.SFTP_TRANSFER_LOG
-- WHERE ATTEMPT_NUMBER > 1
--   AND TRANSFER_START >= DATEADD('day', -30, CURRENT_TIMESTAMP())
-- GROUP BY 1, 2
-- ORDER BY TOTAL_RETRIES DESC;

-- Weekly SFTP bytes transferred per config:
-- SELECT DATE_TRUNC('week', TRANSFER_START) AS WEEK,
--        CONFIG_NAME, COUNT(*) AS FILES,
--        ROUND(SUM(LOCAL_FILE_SIZE_BYTES) / 1024 / 1024 / 1024, 3) AS TOTAL_GB,
--        AVG(THROUGHPUT_MBPS) AS AVG_MBPS
-- FROM AUDIT.SFTP_TRANSFER_LOG
-- WHERE STATUS = 'SUCCESS'
-- GROUP BY 1, 2
-- ORDER BY WEEK DESC, TOTAL_GB DESC;

-- =============================================================================
-- SECTION 8: VERIFY DEPLOYMENT
-- =============================================================================
-- SHOW PROCEDURES IN SCHEMA DATA_EXTRACT_DB.FRAMEWORK;
-- SHOW TASKS     IN SCHEMA DATA_EXTRACT_DB.FRAMEWORK;
--
-- Test dry run (confirms SQL parsing without S3/SFTP connectivity):
-- CALL DATA_EXTRACT_DB.FRAMEWORK.DRY_RUN_EXTRACT('DAILY_SALES_EXTRACT');
--
-- Test SFTP connection (confirms auth without transferring files):
-- CALL DATA_EXTRACT_DB.FRAMEWORK.TEST_SFTP_CONNECTION('CUSTOMER_SFTP_EXPORT');
--
-- Sync tasks from config table:
-- CALL DATA_EXTRACT_DB.FRAMEWORK.SYNC_EXTRACT_TASKS();
--
-- Check for any config violations:
-- SELECT * FROM FRAMEWORK.V_CONFIG_VIOLATIONS;
