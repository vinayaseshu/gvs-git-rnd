-- =============================================================================
-- SNOWFLAKE DATA VALIDATION FRAMEWORK
-- File: 05_tasks_sample_config_usage.sql
-- Description: Snowflake Tasks for scheduling, sample config inserts,
--              and usage examples
-- =============================================================================

-- =============================================================================
-- SECTION 1: SNOWFLAKE TASKS FOR PARALLEL EXECUTION
-- =============================================================================

-- Root task: creates a new run_id and launches parallel group sub-tasks
-- Runs daily at 02:00 UTC
CREATE OR REPLACE TASK VALIDATION_DB.CONFIG.TASK_MASTER_DAILY
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 0 2 * * * UTC'
    COMMENT   = 'Daily master validation run - launches all active groups'
AS
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    NULL,       -- all active validations
    NULL,       -- all types
    NULL,       -- all groups
    'PROD',
    'SCHEDULED_TASK',
    FALSE
);

-- Parallel group tasks (one per group, can be triggered concurrently by DAG)
CREATE OR REPLACE TASK VALIDATION_DB.CONFIG.TASK_GROUP_FINANCE
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 30 2 * * * UTC'
    COMMENT   = 'Finance parallel group validations'
AS
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    NULL, NULL, 'FINANCE', 'PROD', 'SCHEDULED_TASK', FALSE
);

CREATE OR REPLACE TASK VALIDATION_DB.CONFIG.TASK_GROUP_SALES
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 30 2 * * * UTC'
AS
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    NULL, NULL, 'SALES', 'PROD', 'SCHEDULED_TASK', FALSE
);

CREATE OR REPLACE TASK VALIDATION_DB.CONFIG.TASK_GROUP_OPERATIONS
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 30 2 * * * UTC'
AS
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    NULL, NULL, 'OPERATIONS', 'PROD', 'SCHEDULED_TASK', FALSE
);

-- Resume tasks (they start in SUSPENDED state)
-- ALTER TASK VALIDATION_DB.CONFIG.TASK_MASTER_DAILY RESUME;
-- ALTER TASK VALIDATION_DB.CONFIG.TASK_GROUP_FINANCE RESUME;
-- ALTER TASK VALIDATION_DB.CONFIG.TASK_GROUP_SALES RESUME;
-- ALTER TASK VALIDATION_DB.CONFIG.TASK_GROUP_OPERATIONS RESUME;

-- =============================================================================
-- SECTION 2: PARALLEL GROUP CONFIGURATION
-- =============================================================================

INSERT INTO VALIDATION_DB.CONFIG.PARALLEL_GROUP_CONFIG
    (GROUP_NAME, MAX_CONCURRENT, WAREHOUSE_NAME, WAREHOUSE_SIZE)
VALUES
    ('DEFAULT',    5, 'COMPUTE_WH',   'MEDIUM'),
    ('FINANCE',    3, 'FINANCE_WH',   'LARGE'),
    ('SALES',      4, 'COMPUTE_WH',   'MEDIUM'),
    ('OPERATIONS', 4, 'COMPUTE_WH',   'MEDIUM'),
    ('CRITICAL',   2, 'CRITICAL_WH',  'X-LARGE');

-- =============================================================================
-- SECTION 3: SAMPLE VALIDATION CONFIG RECORDS
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 3a. Row Count validations
-- ---------------------------------------------------------------------------
INSERT INTO VALIDATION_DB.CONFIG.VALIDATION_CONFIG (
    VALIDATION_NAME, VALIDATION_TYPE,
    SOURCE_DB, SOURCE_SCHEMA, SOURCE_TABLE,
    TARGET_DB, TARGET_SCHEMA, TARGET_TABLE,
    FILTER_CONDITION, THRESHOLD_PCT,
    IS_ACTIVE, EXECUTION_PRIORITY, PARALLEL_GROUP, VALIDATION_FREQUENCY
) VALUES
-- Simple full row count
(
    'RC_ORDERS_FULL',     'ROW_COUNT',
    'SOURCE_DB', 'SALES',  'ORDERS',
    'TARGET_DB', 'SALES',  'ORDERS',
    NULL,                  0,
    TRUE, 10, 'SALES',     'DAILY'
),
-- Incremental with date filter
(
    'RC_ORDERS_INCREMENTAL', 'ROW_COUNT',
    'SOURCE_DB', 'SALES',  'ORDERS',
    'TARGET_DB', 'SALES',  'ORDERS',
    'STATUS IN (''COMPLETED'',''SHIPPED'')', 0.5,
    TRUE, 20, 'SALES',     'DAILY'
),
-- Finance with threshold tolerance
(
    'RC_TRANSACTIONS_DAILY', 'ROW_COUNT',
    'SOURCE_DB', 'FINANCE', 'TRANSACTIONS',
    'TARGET_DB', 'FINANCE', 'TRANSACTIONS',
    'TRANSACTION_DATE = CURRENT_DATE() - 1',  0.01,
    TRUE, 10, 'FINANCE',   'DAILY'
),
(
    'RC_CUSTOMERS_FULL', 'ROW_COUNT',
    'SOURCE_DB', 'CRM',    'CUSTOMERS',
    'TARGET_DB', 'CRM',    'CUSTOMERS',
    NULL,                  0,
    TRUE, 30, 'SALES',     'WEEKLY'
);

-- Update incremental date columns
UPDATE VALIDATION_DB.CONFIG.VALIDATION_CONFIG
SET INCREMENTAL_DATE_COL = 'ORDER_DATE', INCREMENTAL_LOOKBACK_DAYS = 3
WHERE VALIDATION_NAME = 'RC_ORDERS_INCREMENTAL';

-- ---------------------------------------------------------------------------
-- 3b. Schema validations
-- ---------------------------------------------------------------------------
INSERT INTO VALIDATION_DB.CONFIG.VALIDATION_CONFIG (
    VALIDATION_NAME, VALIDATION_TYPE,
    SOURCE_DB, SOURCE_SCHEMA, SOURCE_TABLE,
    TARGET_DB, TARGET_SCHEMA, TARGET_TABLE,
    IS_ACTIVE, EXECUTION_PRIORITY, PARALLEL_GROUP, VALIDATION_FREQUENCY
) VALUES
(
    'SCH_ORDERS',        'SCHEMA',
    'SOURCE_DB', 'SALES',   'ORDERS',
    'TARGET_DB', 'SALES',   'ORDERS',
    TRUE, 5, 'SALES',       'DAILY'
),
(
    'SCH_TRANSACTIONS',  'SCHEMA',
    'SOURCE_DB', 'FINANCE', 'TRANSACTIONS',
    'TARGET_DB', 'FINANCE', 'TRANSACTIONS',
    TRUE, 5, 'FINANCE',     'DAILY'
),
(
    'SCH_CUSTOMERS',     'SCHEMA',
    'SOURCE_DB', 'CRM',     'CUSTOMERS',
    'TARGET_DB', 'CRM',     'CUSTOMERS',
    TRUE, 5, 'SALES',       'WEEKLY'
);

-- ---------------------------------------------------------------------------
-- 3c. Data validations – Full, Incremental, Sample, Hash
-- ---------------------------------------------------------------------------
INSERT INTO VALIDATION_DB.CONFIG.VALIDATION_CONFIG (
    VALIDATION_NAME, VALIDATION_TYPE,
    SOURCE_DB, SOURCE_SCHEMA, SOURCE_TABLE,
    TARGET_DB, TARGET_SCHEMA, TARGET_TABLE,
    KEY_COLUMNS, EXCLUDED_COLUMNS,
    FILTER_CONDITION, THRESHOLD_PCT,
    IS_ACTIVE, EXECUTION_PRIORITY, PARALLEL_GROUP,
    INCREMENTAL_DATE_COL, INCREMENTAL_LOOKBACK_DAYS,
    SAMPLE_PCT, VALIDATION_FREQUENCY
) VALUES
-- Full data validation
(
    'DATA_ORDERS_FULL',          'DATA_FULL',
    'SOURCE_DB', 'SALES', 'ORDERS',
    'TARGET_DB', 'SALES', 'ORDERS',
    'ORDER_ID',            'CREATED_AT,UPDATED_AT,ETL_TIMESTAMP',
    NULL,                  0,
    TRUE, 50, 'SALES',
    NULL, NULL, NULL,      'WEEKLY'
),
-- Incremental data validation
(
    'DATA_ORDERS_INCREMENTAL',   'DATA_INCREMENTAL',
    'SOURCE_DB', 'SALES', 'ORDERS',
    'TARGET_DB', 'SALES', 'ORDERS',
    'ORDER_ID',            'CREATED_AT,UPDATED_AT,ETL_TIMESTAMP',
    NULL,                  0.1,
    TRUE, 40, 'SALES',
    'ORDER_DATE', 1, NULL, 'DAILY'
),
-- Sample-based (10%)
(
    'DATA_TRANSACTIONS_SAMPLE',  'DATA_SAMPLE',
    'SOURCE_DB', 'FINANCE', 'TRANSACTIONS',
    'TARGET_DB', 'FINANCE', 'TRANSACTIONS',
    'TRANSACTION_ID',       'CREATED_AT,UPDATED_AT',
    NULL,                   0.5,
    TRUE, 60, 'FINANCE',
    NULL, NULL, 10,         'DAILY'
),
-- Hash-based for large table
(
    'DATA_EVENTS_HASH',          'DATA_HASH',
    'SOURCE_DB', 'ANALYTICS', 'EVENTS',
    'TARGET_DB', 'ANALYTICS', 'EVENTS',
    'EVENT_ID',               'INGESTED_AT',
    'EVENT_DATE >= DATEADD(day, -7, CURRENT_DATE())', 0,
    TRUE, 70, 'OPERATIONS',
    NULL, NULL, NULL,         'DAILY'
),
-- Composite key example
(
    'DATA_ORDER_ITEMS_FULL',     'DATA_FULL',
    'SOURCE_DB', 'SALES', 'ORDER_ITEMS',
    'TARGET_DB', 'SALES', 'ORDER_ITEMS',
    'ORDER_ID,LINE_ITEM_ID',  'CREATED_AT,UPDATED_AT',
    NULL,                     0,
    TRUE, 55, 'SALES',
    NULL, NULL, NULL,          'WEEKLY'
);

-- ---------------------------------------------------------------------------
-- 3d. Column-level overrides
-- ---------------------------------------------------------------------------
INSERT INTO VALIDATION_DB.CONFIG.VALIDATION_COLUMN_CONFIG
    (VALIDATION_ID, COLUMN_NAME, IS_EXCLUDED, IS_KEY_COLUMN, TOLERANCE_VALUE)
SELECT V.VALIDATION_ID, 'PRICE',       FALSE, FALSE, 0.01
FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG V
WHERE V.VALIDATION_NAME = 'DATA_ORDERS_FULL';

INSERT INTO VALIDATION_DB.CONFIG.VALIDATION_COLUMN_CONFIG
    (VALIDATION_ID, COLUMN_NAME, IS_EXCLUDED, IS_KEY_COLUMN)
SELECT V.VALIDATION_ID, 'LOAD_TIMESTAMP', TRUE, FALSE
FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG V
WHERE V.VALIDATION_NAME IN ('DATA_ORDERS_FULL','DATA_ORDERS_INCREMENTAL');

-- =============================================================================
-- SECTION 4: USAGE EXAMPLES
-- =============================================================================

/*
--------------------------------------------------------------------
4.1  Run ALL active validations
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK();

--------------------------------------------------------------------
4.2  Run specific validation IDs
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    '1,2,3',    -- validation_ids
    NULL,       -- types
    NULL,       -- group
    'PROD',
    'JOHN_DOE',
    FALSE
);

--------------------------------------------------------------------
4.3  Run only ROW_COUNT validations
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    NULL, 'ROW_COUNT', NULL, 'PROD', NULL, FALSE
);

--------------------------------------------------------------------
4.4  Run only the FINANCE parallel group
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    NULL, NULL, 'FINANCE', 'PROD', NULL, FALSE
);

--------------------------------------------------------------------
4.5  Dry run – planning only, no execution
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    NULL, NULL, NULL, 'PROD', NULL, TRUE
);

--------------------------------------------------------------------
4.6  Single row count validation
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_VALIDATE_ROW_COUNT('<run_id>', 1);

--------------------------------------------------------------------
4.7  Single schema validation
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_VALIDATE_SCHEMA('<run_id>', 4);

--------------------------------------------------------------------
4.8  Single data validation
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_VALIDATE_DATA('<run_id>', 7);

--------------------------------------------------------------------
4.9  Get run summary
--------------------------------------------------------------------
CALL VALIDATION_DB.CONFIG.SP_GET_RUN_SUMMARY('<run_id>');

--------------------------------------------------------------------
4.10 Query results
--------------------------------------------------------------------
-- Latest run overview
SELECT * FROM VALIDATION_DB.RESULTS.V_LATEST_RUN_SUMMARY LIMIT 10;

-- All failures
SELECT * FROM VALIDATION_DB.RESULTS.V_FAILED_VALIDATIONS;

-- Mismatch detail for a run
SELECT * FROM VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL
WHERE RUN_ID = '<run_id>'
ORDER BY MISMATCH_REASON, TABLE_NAME, KEY_VALUE;

-- Schema mismatches for a run
SELECT * FROM VALIDATION_DB.RESULTS.SCHEMA_MISMATCH_DETAIL
WHERE RUN_ID = '<run_id>'
ORDER BY MISMATCH_TYPE, TABLE_NAME, COLUMN_NAME;

-- Trend report: pass rate over last 30 days
SELECT
    DATE(EXECUTION_START_TIME)  AS RUN_DATE,
    COUNT(*)                    AS TOTAL_RUNS,
    SUM(CASE WHEN STATUS='COMPLETED' THEN 1 ELSE 0 END) AS SUCCESSFUL_RUNS,
    AVG(TOTAL_DURATION_SECONDS) AS AVG_DURATION_SEC,
    AVG((SUCCESS_COUNT / NULLIF(TOTAL_VALIDATIONS,0)) * 100) AS AVG_PASS_RATE_PCT
FROM VALIDATION_DB.RESULTS.RUN_MASTER
WHERE EXECUTION_START_TIME >= DATEADD(day, -30, CURRENT_DATE())
GROUP BY 1
ORDER BY 1 DESC;

-- Most frequently failing validations
SELECT
    VALIDATION_NAME,
    VALIDATION_TYPE,
    COUNT(*) AS TOTAL_RUNS,
    SUM(CASE WHEN STATUS='FAIL' THEN 1 ELSE 0 END) AS FAIL_COUNT,
    ROUND(AVG(MISMATCH_PCT),4)                      AS AVG_MISMATCH_PCT,
    ROUND(AVG(EXECUTION_TIME_SECONDS),1)             AS AVG_EXEC_SEC
FROM VALIDATION_DB.RESULTS.VALIDATION_DETAIL
WHERE EXECUTION_START_TIME >= DATEADD(day, -30, CURRENT_DATE())
GROUP BY 1,2
ORDER BY FAIL_COUNT DESC, AVG_MISMATCH_PCT DESC;

-- Framework execution log for a run
SELECT LOG_TIMESTAMP, LOG_LEVEL, STEP_NAME, LOG_MESSAGE
FROM VALIDATION_DB.RESULTS.FRAMEWORK_LOG
WHERE RUN_ID = '<run_id>'
ORDER BY LOG_TIMESTAMP;
*/

-- =============================================================================
-- SECTION 5: MAINTENANCE STORED PROCEDURE
-- =============================================================================

CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_PURGE_OLD_RESULTS(
    P_RETENTION_DAYS NUMBER DEFAULT 90
)
RETURNS VARCHAR
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS $$
    var cutoff = `DATEADD(day, -${P_RETENTION_DAYS}, CURRENT_DATE())`;
    var tables = [
        ['VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL',   'CREATED_AT'],
        ['VALIDATION_DB.RESULTS.SCHEMA_MISMATCH_DETAIL', 'CREATED_AT'],
        ['VALIDATION_DB.RESULTS.VALIDATION_DETAIL',      'CREATED_AT'],
        ['VALIDATION_DB.RESULTS.FRAMEWORK_LOG',          'LOG_TIMESTAMP'],
        ['VALIDATION_DB.RESULTS.RUN_MASTER',             'EXECUTION_START_TIME']
    ];
    var summary = [];

    tables.forEach(function(t) {
        var rs = snowflake.execute({
            sqlText: `DELETE FROM ${t[0]} WHERE ${t[1]} < ${cutoff}`
        });
        rs.next();
        summary.push(`${t[0]}: ${rs.getColumnValue(1)} rows deleted`);
    });

    return summary.join('\n');
$$;
