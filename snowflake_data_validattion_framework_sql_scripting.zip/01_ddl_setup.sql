-- =============================================================================
-- SNOWFLAKE DATA VALIDATION FRAMEWORK
-- File: 01_ddl_setup.sql
-- Description: Database, schema, and all metadata/result table DDL
-- =============================================================================

-- =============================================================================
-- SECTION 1: DATABASE & SCHEMA SETUP
-- =============================================================================

CREATE DATABASE IF NOT EXISTS VALIDATION_DB
    COMMENT = 'Central database for the Data Validation Framework';

CREATE SCHEMA IF NOT EXISTS VALIDATION_DB.CONFIG
    COMMENT = 'Configuration and metadata tables for validation rules';

CREATE SCHEMA IF NOT EXISTS VALIDATION_DB.RESULTS
    COMMENT = 'Execution results, history, and mismatch details';

CREATE SCHEMA IF NOT EXISTS VALIDATION_DB.STAGING
    COMMENT = 'Temporary staging tables used during validation execution';

-- =============================================================================
-- SECTION 2: CONFIGURATION TABLES
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 2.1  VALIDATION_CONFIG  – Master validation rule registry
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.CONFIG.VALIDATION_CONFIG (
    VALIDATION_ID           NUMBER          AUTOINCREMENT PRIMARY KEY,
    VALIDATION_NAME         VARCHAR(200)    NOT NULL,
    VALIDATION_TYPE         VARCHAR(50)     NOT NULL        -- ROW_COUNT | SCHEMA | DATA_FULL | DATA_INCREMENTAL | DATA_SAMPLE | DATA_HASH
        CONSTRAINT chk_val_type CHECK (VALIDATION_TYPE IN (
            'ROW_COUNT','SCHEMA','DATA_FULL','DATA_INCREMENTAL','DATA_SAMPLE','DATA_HASH')),

    -- Source coordinates
    SOURCE_DB               VARCHAR(100)    NOT NULL,
    SOURCE_SCHEMA           VARCHAR(100)    NOT NULL,
    SOURCE_TABLE            VARCHAR(200)    NOT NULL,

    -- Target coordinates
    TARGET_DB               VARCHAR(100)    NOT NULL,
    TARGET_SCHEMA           VARCHAR(100)    NOT NULL,
    TARGET_TABLE            VARCHAR(200)    NOT NULL,

    -- Key & filter settings
    KEY_COLUMNS             VARCHAR(2000),  -- CSV list of PK columns; required for DATA validations
    FILTER_CONDITION        VARCHAR(4000),  -- Optional WHERE clause (no WHERE keyword)
    INCREMENTAL_DATE_COL    VARCHAR(200),   -- Column used for incremental filtering
    INCREMENTAL_LOOKBACK_DAYS NUMBER(5)     DEFAULT 1,

    -- Column exclusions
    EXCLUDED_COLUMNS        VARCHAR(4000),  -- CSV of columns to skip in data comparison

    -- Threshold & tolerance
    THRESHOLD_PCT           NUMBER(10,4)    DEFAULT 0,      -- Acceptable mismatch tolerance (%)
    SAMPLE_PCT              NUMBER(5,2)     DEFAULT 10,     -- % sample for DATA_SAMPLE type

    -- Execution control
    IS_ACTIVE               BOOLEAN         DEFAULT TRUE,
    EXECUTION_PRIORITY      NUMBER(5)       DEFAULT 100,    -- Lower = runs first
    PARALLEL_GROUP          VARCHAR(100)    DEFAULT 'DEFAULT', -- Validations in same group run together
    RETRY_COUNT             NUMBER(3)       DEFAULT 2,
    RETRY_DELAY_SECONDS     NUMBER(5)       DEFAULT 30,
    TIMEOUT_MINUTES         NUMBER(5)       DEFAULT 60,

    -- Scheduling metadata
    VALIDATION_FREQUENCY    VARCHAR(50)     DEFAULT 'ON_DEMAND', -- ON_DEMAND | DAILY | WEEKLY | MONTHLY
    LAST_SCHEDULED_RUN      TIMESTAMP_NTZ,
    ENVIRONMENT             VARCHAR(50)     DEFAULT 'PROD',

    -- Audit columns
    CREATED_BY              VARCHAR(200)    DEFAULT CURRENT_USER(),
    CREATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_BY              VARCHAR(200),
    UPDATED_AT              TIMESTAMP_NTZ,

    CONSTRAINT uq_validation_name UNIQUE (VALIDATION_NAME)
)
COMMENT = 'Master configuration table driving all validation executions';

-- ---------------------------------------------------------------------------
-- 2.2  VALIDATION_COLUMN_CONFIG  – Per-column override settings
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.CONFIG.VALIDATION_COLUMN_CONFIG (
    COLUMN_CONFIG_ID        NUMBER          AUTOINCREMENT PRIMARY KEY,
    VALIDATION_ID           NUMBER          NOT NULL
        REFERENCES VALIDATION_DB.CONFIG.VALIDATION_CONFIG(VALIDATION_ID),
    COLUMN_NAME             VARCHAR(200)    NOT NULL,
    IS_EXCLUDED             BOOLEAN         DEFAULT FALSE,
    IS_KEY_COLUMN           BOOLEAN         DEFAULT FALSE,
    CUSTOM_CAST_SOURCE      VARCHAR(500),   -- Optional CAST expression for source value
    CUSTOM_CAST_TARGET      VARCHAR(500),   -- Optional CAST expression for target value
    TOLERANCE_VALUE         NUMBER(20,6),   -- Numeric tolerance for float comparisons
    CREATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),

    CONSTRAINT uq_col_config UNIQUE (VALIDATION_ID, COLUMN_NAME)
)
COMMENT = 'Column-level override settings per validation rule';

-- ---------------------------------------------------------------------------
-- 2.3  PARALLEL_GROUP_CONFIG  – Parallel execution group settings
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.CONFIG.PARALLEL_GROUP_CONFIG (
    GROUP_NAME              VARCHAR(100)    PRIMARY KEY,
    MAX_CONCURRENT          NUMBER(3)       DEFAULT 5,
    WAREHOUSE_NAME          VARCHAR(200),   -- Optional dedicated warehouse
    WAREHOUSE_SIZE          VARCHAR(50)     DEFAULT 'MEDIUM',
    IS_ACTIVE               BOOLEAN         DEFAULT TRUE,
    CREATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
)
COMMENT = 'Controls concurrency limits per parallel execution group';

-- ---------------------------------------------------------------------------
-- 2.4  ENVIRONMENT_CONFIG  – Environment-level global settings
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.CONFIG.ENVIRONMENT_CONFIG (
    ENV_KEY                 VARCHAR(200)    PRIMARY KEY,
    ENV_VALUE               VARCHAR(4000)   NOT NULL,
    DESCRIPTION             VARCHAR(1000),
    UPDATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
)
COMMENT = 'Global key-value settings for the validation framework';

-- Seed defaults
INSERT INTO VALIDATION_DB.CONFIG.ENVIRONMENT_CONFIG VALUES
    ('DEFAULT_THRESHOLD_PCT',   '0',        'Default mismatch tolerance %',         CURRENT_TIMESTAMP()),
    ('MAX_MISMATCH_ROWS',       '100000',   'Max rows written to MISMATCH_DETAIL',  CURRENT_TIMESTAMP()),
    ('FRAMEWORK_VERSION',       '1.0.0',    'Current framework version',            CURRENT_TIMESTAMP()),
    ('ALERT_ON_FAILURE',        'TRUE',     'Send alert on validation failure',      CURRENT_TIMESTAMP()),
    ('DEFAULT_SAMPLE_PCT',      '10',       'Default sample percentage',             CURRENT_TIMESTAMP()),
    ('HASH_BATCH_SIZE',         '500000',   'Row batch size for hash comparisons',   CURRENT_TIMESTAMP()),
    ('LOG_LEVEL',               'INFO',     'Framework log level: DEBUG|INFO|WARN',  CURRENT_TIMESTAMP());

-- =============================================================================
-- SECTION 3: RESULT TABLES
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 3.1  RUN_MASTER  – One row per framework execution
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.RESULTS.RUN_MASTER (
    RUN_ID                  VARCHAR(36)     PRIMARY KEY,            -- UUID
    EXECUTION_START_TIME    TIMESTAMP_NTZ   NOT NULL,
    EXECUTION_END_TIME      TIMESTAMP_NTZ,
    TRIGGERED_BY            VARCHAR(200)    DEFAULT CURRENT_USER(),
    ENVIRONMENT             VARCHAR(50),
    STATUS                  VARCHAR(20)     NOT NULL                -- RUNNING | COMPLETED | FAILED | PARTIAL
        CONSTRAINT chk_run_status CHECK (STATUS IN ('RUNNING','COMPLETED','FAILED','PARTIAL')),
    TOTAL_VALIDATIONS       NUMBER(10)      DEFAULT 0,
    SUCCESS_COUNT           NUMBER(10)      DEFAULT 0,
    FAILURE_COUNT           NUMBER(10)      DEFAULT 0,
    SKIPPED_COUNT           NUMBER(10)      DEFAULT 0,
    TOTAL_DURATION_SECONDS  NUMBER(15,3),
    RUN_PARAMETERS          VARIANT,        -- JSON blob of input params
    ERROR_SUMMARY           VARCHAR(4000),
    CREATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
)
COMMENT = 'Master run tracking table - one row per framework invocation'
CLUSTER BY (DATE(EXECUTION_START_TIME));

-- ---------------------------------------------------------------------------
-- 3.2  VALIDATION_DETAIL  – One row per validation per run
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.RESULTS.VALIDATION_DETAIL (
    DETAIL_ID               NUMBER          AUTOINCREMENT PRIMARY KEY,
    RUN_ID                  VARCHAR(36)     NOT NULL
        REFERENCES VALIDATION_DB.RESULTS.RUN_MASTER(RUN_ID),
    VALIDATION_ID           NUMBER          NOT NULL,
    VALIDATION_NAME         VARCHAR(200),
    VALIDATION_TYPE         VARCHAR(50),
    SOURCE_FULL_NAME        VARCHAR(600),   -- DB.SCHEMA.TABLE
    TARGET_FULL_NAME        VARCHAR(600),
    STATUS                  VARCHAR(20)     NOT NULL                -- PASS | FAIL | ERROR | SKIPPED
        CONSTRAINT chk_detail_status CHECK (STATUS IN ('PASS','FAIL','ERROR','SKIPPED')),
    SOURCE_VALUE            VARCHAR(4000),  -- Generic: count, schema hash, etc.
    TARGET_VALUE            VARCHAR(4000),
    DIFFERENCE              NUMBER(20,6),
    THRESHOLD_PCT           NUMBER(10,4),
    MISMATCH_PCT            NUMBER(10,4),
    MISMATCH_ROW_COUNT      NUMBER(15),
    EXECUTION_START_TIME    TIMESTAMP_NTZ,
    EXECUTION_END_TIME      TIMESTAMP_NTZ,
    EXECUTION_TIME_SECONDS  NUMBER(15,3),
    RETRY_ATTEMPT           NUMBER(3)       DEFAULT 0,
    ERROR_MESSAGE           VARCHAR(8000),
    FILTER_APPLIED          VARCHAR(4000),
    CREATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
)
COMMENT = 'Detailed result per validation per run'
CLUSTER BY (RUN_ID, VALIDATION_TYPE);

-- ---------------------------------------------------------------------------
-- 3.3  SCHEMA_MISMATCH_DETAIL  – Column-level schema diff results
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.RESULTS.SCHEMA_MISMATCH_DETAIL (
    SCHEMA_MISMATCH_ID      NUMBER          AUTOINCREMENT PRIMARY KEY,
    RUN_ID                  VARCHAR(36)     NOT NULL,
    VALIDATION_ID           NUMBER          NOT NULL,
    TABLE_NAME              VARCHAR(600),
    COLUMN_NAME             VARCHAR(200),
    MISMATCH_TYPE           VARCHAR(50),    -- MISSING_IN_TARGET | EXTRA_IN_TARGET | DATATYPE | PRECISION | SCALE | NULLABLE | DEFAULT | ORDER
    SOURCE_ATTRIBUTE        VARCHAR(500),
    TARGET_ATTRIBUTE        VARCHAR(500),
    COLUMN_ORDER_SOURCE     NUMBER(5),
    COLUMN_ORDER_TARGET     NUMBER(5),
    CREATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
)
COMMENT = 'Column-level schema differences between source and target'
CLUSTER BY (RUN_ID);

-- ---------------------------------------------------------------------------
-- 3.4  DATA_MISMATCH_DETAIL  – Row/value-level data diff results
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL (
    MISMATCH_ID             NUMBER          AUTOINCREMENT PRIMARY KEY,
    RUN_ID                  VARCHAR(36)     NOT NULL,
    VALIDATION_ID           NUMBER          NOT NULL,
    TABLE_NAME              VARCHAR(600),
    KEY_VALUE               VARCHAR(4000),  -- JSON representation of composite key
    COLUMN_NAME             VARCHAR(200),
    SOURCE_VALUE            VARCHAR(8000),
    TARGET_VALUE            VARCHAR(8000),
    MISMATCH_REASON         VARCHAR(200),   -- MISSING_IN_TARGET | MISSING_IN_SOURCE | VALUE_MISMATCH | DUPLICATE_KEY
    CREATED_AT              TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
)
COMMENT = 'Row and value-level mismatches from data validation'
CLUSTER BY (RUN_ID, VALIDATION_ID);

-- ---------------------------------------------------------------------------
-- 3.5  FRAMEWORK_LOG  – Execution audit log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS VALIDATION_DB.RESULTS.FRAMEWORK_LOG (
    LOG_ID                  NUMBER          AUTOINCREMENT PRIMARY KEY,
    RUN_ID                  VARCHAR(36),
    VALIDATION_ID           NUMBER,
    LOG_LEVEL               VARCHAR(10),    -- DEBUG | INFO | WARN | ERROR
    LOG_MESSAGE             VARCHAR(8000),
    STEP_NAME               VARCHAR(200),
    LOG_TIMESTAMP           TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),
    SESSION_ID              VARCHAR(200)    DEFAULT TO_VARCHAR(CURRENT_SESSION())
)
COMMENT = 'Framework execution audit log'
CLUSTER BY (DATE(LOG_TIMESTAMP));

-- =============================================================================
-- SECTION 4: HELPER VIEWS
-- =============================================================================

CREATE OR REPLACE VIEW VALIDATION_DB.RESULTS.V_LATEST_RUN_SUMMARY AS
SELECT
    RM.RUN_ID,
    RM.EXECUTION_START_TIME,
    RM.EXECUTION_END_TIME,
    RM.TRIGGERED_BY,
    RM.ENVIRONMENT,
    RM.STATUS                   AS RUN_STATUS,
    RM.TOTAL_VALIDATIONS,
    RM.SUCCESS_COUNT,
    RM.FAILURE_COUNT,
    RM.SKIPPED_COUNT,
    RM.TOTAL_DURATION_SECONDS,
    ROUND(
        CASE WHEN RM.TOTAL_VALIDATIONS > 0
             THEN (RM.SUCCESS_COUNT / RM.TOTAL_VALIDATIONS) * 100 ELSE 0
        END, 2)                 AS SUCCESS_RATE_PCT,
    ROW_NUMBER() OVER (ORDER BY RM.EXECUTION_START_TIME DESC) AS RUN_RANK
FROM VALIDATION_DB.RESULTS.RUN_MASTER RM;

CREATE OR REPLACE VIEW VALIDATION_DB.RESULTS.V_VALIDATION_DASHBOARD AS
SELECT
    VD.RUN_ID,
    VD.VALIDATION_NAME,
    VD.VALIDATION_TYPE,
    VD.SOURCE_FULL_NAME,
    VD.TARGET_FULL_NAME,
    VD.STATUS,
    VD.SOURCE_VALUE,
    VD.TARGET_VALUE,
    VD.DIFFERENCE,
    VD.MISMATCH_PCT,
    VD.MISMATCH_ROW_COUNT,
    VD.EXECUTION_TIME_SECONDS,
    VD.ERROR_MESSAGE,
    RM.EXECUTION_START_TIME     AS RUN_START,
    RM.TRIGGERED_BY
FROM VALIDATION_DB.RESULTS.VALIDATION_DETAIL VD
JOIN VALIDATION_DB.RESULTS.RUN_MASTER RM ON RM.RUN_ID = VD.RUN_ID;

CREATE OR REPLACE VIEW VALIDATION_DB.RESULTS.V_FAILED_VALIDATIONS AS
SELECT *
FROM VALIDATION_DB.RESULTS.V_VALIDATION_DASHBOARD
WHERE STATUS IN ('FAIL','ERROR')
ORDER BY RUN_START DESC;

CREATE OR REPLACE VIEW VALIDATION_DB.CONFIG.V_ACTIVE_VALIDATIONS AS
SELECT
    VC.*,
    PG.MAX_CONCURRENT,
    PG.WAREHOUSE_NAME
FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG VC
LEFT JOIN VALIDATION_DB.CONFIG.PARALLEL_GROUP_CONFIG PG
    ON PG.GROUP_NAME = VC.PARALLEL_GROUP
WHERE VC.IS_ACTIVE = TRUE
ORDER BY VC.EXECUTION_PRIORITY, VC.PARALLEL_GROUP, VC.VALIDATION_ID;

-- =============================================================================
-- SECTION 5: INDEXES / SEARCH OPTIMIZATION (Snowflake)
-- =============================================================================

ALTER TABLE VALIDATION_DB.RESULTS.VALIDATION_DETAIL
    ADD SEARCH OPTIMIZATION ON EQUALITY(RUN_ID, VALIDATION_ID, STATUS);

ALTER TABLE VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL
    ADD SEARCH OPTIMIZATION ON EQUALITY(RUN_ID, VALIDATION_ID);

ALTER TABLE VALIDATION_DB.RESULTS.SCHEMA_MISMATCH_DETAIL
    ADD SEARCH OPTIMIZATION ON EQUALITY(RUN_ID, VALIDATION_ID);
