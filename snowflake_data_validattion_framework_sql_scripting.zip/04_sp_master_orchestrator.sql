-- =============================================================================
-- SNOWFLAKE DATA VALIDATION FRAMEWORK  (Snowflake Scripting / SQL)
-- File: 04_sp_master_orchestrator.sql
-- Description: SP_RUN_VALIDATION_FRAMEWORK  – master orchestrator
--              SP_RUN_PARALLEL_GROUP         – group-scoped executor
--              SP_GET_RUN_SUMMARY            – reporting helper
--              SP_PURGE_OLD_RESULTS          – maintenance
-- =============================================================================

-- =============================================================================
-- SP_RUN_VALIDATION_FRAMEWORK
--       Master entry point.  Selects active validations filtered by the
--       supplied parameters, executes each in priority order with automatic
--       retry, and writes a complete audit trail to RUN_MASTER /
--       VALIDATION_DETAIL / FRAMEWORK_LOG.
--
--       Parameters
--       ----------
--       P_VALIDATION_IDS    CSV of specific VALIDATION_IDs to run (NULL = all)
--       P_VALIDATION_TYPES  CSV of types to include (NULL = all)
--       P_PARALLEL_GROUP    Single group name to restrict execution (NULL = all)
--       P_ENVIRONMENT       Tag written to RUN_MASTER.ENVIRONMENT
--       P_TRIGGERED_BY      Override for TRIGGERED_BY (defaults to CURRENT_USER)
--       P_DRY_RUN           TRUE = plan only, no validation SPs executed
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_RUN_VALIDATION_FRAMEWORK(
    P_VALIDATION_IDS    VARCHAR  DEFAULT NULL,
    P_VALIDATION_TYPES  VARCHAR  DEFAULT NULL,
    P_PARALLEL_GROUP    VARCHAR  DEFAULT NULL,
    P_ENVIRONMENT       VARCHAR  DEFAULT 'PROD',
    P_TRIGGERED_BY      VARCHAR  DEFAULT NULL,
    P_DRY_RUN           BOOLEAN  DEFAULT FALSE
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    -- Run identity
    v_run_id            VARCHAR;
    v_triggered_by      VARCHAR;
    v_run_params        VARCHAR;
    v_global_start      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
    v_end_time          TIMESTAMP_NTZ;

    -- Candidate query construction
    v_where_parts       VARCHAR DEFAULT 'IS_ACTIVE = TRUE';
    v_candidate_sql     VARCHAR;
    v_total_cnt_sql     VARCHAR;

    -- Per-validation iteration
    v_val_id            NUMBER;
    v_val_name          VARCHAR;
    v_val_type          VARCHAR;
    v_retry_count       NUMBER;
    v_src_full          VARCHAR;
    v_tgt_full          VARCHAR;

    -- Execution tracking
    v_total             NUMBER  DEFAULT 0;
    v_success           NUMBER  DEFAULT 0;
    v_failure           NUMBER  DEFAULT 0;
    v_skipped           NUMBER  DEFAULT 0;

    -- Per-validation attempt tracking
    v_attempt           NUMBER;
    v_last_err          VARCHAR;
    v_success_flag      BOOLEAN;
    v_val_result        OBJECT;
    v_val_status        VARCHAR;

    -- Duration
    v_duration_sec      NUMBER(15,3);
    v_final_status      VARCHAR;

    -- Candidate cursor
    candidate_res       RESULTSET;
    c_cand              CURSOR FOR candidate_res;

    -- Candidate count
    cnt_res             RESULTSET;
    c_cnt               CURSOR FOR cnt_res;
BEGIN
    -- -------------------------------------------------------------------------
    -- 1. Generate run ID and open RUN_MASTER record
    -- -------------------------------------------------------------------------
    v_run_id       := VALIDATION_DB.CONFIG.FN_GENERATE_UUID();
    v_triggered_by := NVL(:P_TRIGGERED_BY, CURRENT_USER());

    v_run_params :=
        OBJECT_CONSTRUCT(
            'validation_ids',   :P_VALIDATION_IDS,
            'validation_types', :P_VALIDATION_TYPES,
            'parallel_group',   :P_PARALLEL_GROUP,
            'dry_run',          :P_DRY_RUN
        )::VARCHAR;

    IF (NOT :P_DRY_RUN) THEN
        INSERT INTO VALIDATION_DB.RESULTS.RUN_MASTER
            (RUN_ID, EXECUTION_START_TIME, TRIGGERED_BY, ENVIRONMENT,
             STATUS, TOTAL_VALIDATIONS, RUN_PARAMETERS)
        VALUES
            (:v_run_id, :v_global_start, :v_triggered_by, :P_ENVIRONMENT,
             'RUNNING', 0, PARSE_JSON(:v_run_params));
    END IF;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :v_run_id, NULL, 'INFO', 'ORCHESTRATOR',
        'Framework run started. run_id=' || v_run_id
        || '  dry_run=' || :P_DRY_RUN::VARCHAR
    );

    -- -------------------------------------------------------------------------
    -- 2. Build candidate filter
    -- -------------------------------------------------------------------------
    IF (:P_VALIDATION_IDS IS NOT NULL AND LENGTH(TRIM(:P_VALIDATION_IDS)) > 0) THEN
        v_where_parts := v_where_parts
            || ' AND VALIDATION_ID IN (' || :P_VALIDATION_IDS || ')';
    END IF;

    IF (:P_VALIDATION_TYPES IS NOT NULL AND LENGTH(TRIM(:P_VALIDATION_TYPES)) > 0) THEN
        -- Build an IN list from the CSV  e.g. 'ROW_COUNT','SCHEMA'
        v_where_parts := v_where_parts
            || ' AND VALIDATION_TYPE IN ('''
            || REPLACE(TRIM(:P_VALIDATION_TYPES), ',', ''',''')
            || ''')';
    END IF;

    IF (:P_PARALLEL_GROUP IS NOT NULL AND LENGTH(TRIM(:P_PARALLEL_GROUP)) > 0) THEN
        v_where_parts := v_where_parts
            || ' AND PARALLEL_GROUP = ''' || :P_PARALLEL_GROUP || '''';
    END IF;

    v_candidate_sql :=
        'SELECT VALIDATION_ID, VALIDATION_NAME, VALIDATION_TYPE,
                NVL(RETRY_COUNT, 2) AS RETRY_COUNT,
                SOURCE_DB||''.''||SOURCE_SCHEMA||''.''||SOURCE_TABLE AS SRC_FULL,
                TARGET_DB||''.''||TARGET_SCHEMA||''.''||TARGET_TABLE AS TGT_FULL
         FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG
         WHERE ' || v_where_parts || '
         ORDER BY EXECUTION_PRIORITY ASC, PARALLEL_GROUP, VALIDATION_ID';

    -- Count candidates
    EXECUTE IMMEDIATE
        'SELECT COUNT(*) FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG WHERE '
        || v_where_parts
        INTO v_total;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :v_run_id, NULL, 'INFO', 'ORCHESTRATOR',
        'Candidates: ' || v_total::VARCHAR || ' validations'
    );

    -- -------------------------------------------------------------------------
    -- 3. Dry run: return plan without executing
    -- -------------------------------------------------------------------------
    IF (:P_DRY_RUN) THEN
        RETURN OBJECT_CONSTRUCT(
            'run_id',   :v_run_id,
            'status',   'DRY_RUN_COMPLETE',
            'total',    :v_total,
            'dry_run',  TRUE
        );
    END IF;

    IF (v_total = 0) THEN
        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :v_run_id, NULL, 'WARN', 'ORCHESTRATOR',
            'No active validations matched the filter criteria'
        );
        UPDATE VALIDATION_DB.RESULTS.RUN_MASTER
           SET STATUS               = 'COMPLETED',
               TOTAL_VALIDATIONS    = 0,
               EXECUTION_END_TIME   = CURRENT_TIMESTAMP(),
               TOTAL_DURATION_SECONDS = 0
         WHERE RUN_ID = :v_run_id;

        RETURN OBJECT_CONSTRUCT(
            'run_id', :v_run_id, 'status', 'COMPLETED', 'total', 0
        );
    END IF;

    -- -------------------------------------------------------------------------
    -- 4. Execute each validation with retry
    -- -------------------------------------------------------------------------
    candidate_res := (EXECUTE IMMEDIATE :v_candidate_sql);
    OPEN c_cand;

    LOOP
        FETCH c_cand INTO
            v_val_id, v_val_name, v_val_type,
            v_retry_count, v_src_full, v_tgt_full;

        v_attempt      := 0;
        v_success_flag := FALSE;
        v_last_err     := NULL;

        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :v_run_id, :v_val_id, 'INFO', 'ORCHESTRATOR',
            'Executing: ' || v_val_name || ' (' || v_val_type || ')'
        );

        -- Retry loop
        WHILE (v_attempt <= v_retry_count AND NOT v_success_flag) DO

            IF (v_attempt > 0) THEN
                CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
                    :v_run_id, :v_val_id, 'WARN', 'ORCHESTRATOR',
                    'Retry ' || v_attempt::VARCHAR || '/' || v_retry_count::VARCHAR
                    || ' for ' || v_val_name
                );
            END IF;

            -- Dispatch based on type
            IF (v_val_type = 'ROW_COUNT') THEN
                CALL VALIDATION_DB.CONFIG.SP_VALIDATE_ROW_COUNT(
                    :v_run_id, :v_val_id
                ) INTO v_val_result;

            ELSEIF (v_val_type = 'SCHEMA') THEN
                CALL VALIDATION_DB.CONFIG.SP_VALIDATE_SCHEMA(
                    :v_run_id, :v_val_id
                ) INTO v_val_result;

            ELSEIF (v_val_type IN ('DATA_FULL','DATA_INCREMENTAL',
                                   'DATA_SAMPLE','DATA_HASH')) THEN
                CALL VALIDATION_DB.CONFIG.SP_VALIDATE_DATA(
                    :v_run_id, :v_val_id
                ) INTO v_val_result;

            ELSE
                v_last_err     := 'Unknown validation type: ' || v_val_type;
                v_attempt      := v_attempt + 1;
                CONTINUE;
            END IF;

            v_val_status := v_val_result['status']::VARCHAR;

            IF (v_val_status IN ('PASS', 'FAIL')) THEN
                v_success_flag := TRUE;
                IF (v_val_status = 'PASS') THEN
                    v_success := v_success + 1;
                ELSE
                    v_failure := v_failure + 1;
                END IF;

                -- Record retry count on the detail row (if this was a retry)
                IF (v_attempt > 0) THEN
                    UPDATE VALIDATION_DB.RESULTS.VALIDATION_DETAIL
                       SET RETRY_ATTEMPT = :v_attempt
                     WHERE RUN_ID        = :v_run_id
                       AND VALIDATION_ID = :v_val_id
                       AND RETRY_ATTEMPT = 0;
                END IF;

            ELSE
                -- Status is ERROR — record message and retry
                v_last_err := NVL(v_val_result['error']::VARCHAR, 'Unknown error');
                v_attempt  := v_attempt + 1;
            END IF;

        END WHILE;   -- end retry loop

        -- If all retries exhausted and still not successful
        IF (NOT v_success_flag) THEN
            v_failure := v_failure + 1;

            CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
                :v_run_id, :v_val_id, 'ERROR', 'ORCHESTRATOR',
                v_val_name || ' failed after ' || v_attempt::VARCHAR
                || ' attempt(s): ' || NVL(v_last_err, '?')
            );

            -- Ensure a detail error row exists (insert only if not already written)
            INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
                (RUN_ID, VALIDATION_ID, VALIDATION_NAME, VALIDATION_TYPE,
                 SOURCE_FULL_NAME, TARGET_FULL_NAME, STATUS, ERROR_MESSAGE,
                 RETRY_ATTEMPT,
                 EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS)
            SELECT :v_run_id, :v_val_id, :v_val_name, :v_val_type,
                   :v_src_full, :v_tgt_full, 'ERROR', :v_last_err,
                   :v_attempt,
                   CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 0
            WHERE NOT EXISTS (
                SELECT 1 FROM VALIDATION_DB.RESULTS.VALIDATION_DETAIL
                 WHERE RUN_ID = :v_run_id AND VALIDATION_ID = :v_val_id
            );
        END IF;

        -- Refresh run master counters every iteration
        UPDATE VALIDATION_DB.RESULTS.RUN_MASTER
           SET TOTAL_VALIDATIONS = :v_total,
               SUCCESS_COUNT     = :v_success,
               FAILURE_COUNT     = :v_failure
         WHERE RUN_ID = :v_run_id;

    END LOOP;

    CLOSE c_cand;

    -- -------------------------------------------------------------------------
    -- 5. Finalise
    -- -------------------------------------------------------------------------
    v_end_time     := CURRENT_TIMESTAMP();
    v_duration_sec := DATEDIFF('millisecond', v_global_start, v_end_time) / 1000.0;

    v_final_status :=
        CASE
            WHEN v_failure = 0              THEN 'COMPLETED'
            WHEN v_success = 0              THEN 'FAILED'
            ELSE                                 'PARTIAL'
        END;

    UPDATE VALIDATION_DB.RESULTS.RUN_MASTER
       SET STATUS                 = :v_final_status,
           EXECUTION_END_TIME     = :v_end_time,
           TOTAL_VALIDATIONS      = :v_total,
           SUCCESS_COUNT          = :v_success,
           FAILURE_COUNT          = :v_failure,
           SKIPPED_COUNT          = :v_skipped,
           TOTAL_DURATION_SECONDS = :v_duration_sec
     WHERE RUN_ID = :v_run_id;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :v_run_id, NULL, 'INFO', 'ORCHESTRATOR',
        'Run complete. Status=' || v_final_status
        || ' Total=' || v_total::VARCHAR
        || ' Pass=' || v_success::VARCHAR
        || ' Fail=' || v_failure::VARCHAR
        || ' Duration=' || ROUND(v_duration_sec, 1)::VARCHAR || 's'
    );

    RETURN OBJECT_CONSTRUCT(
        'run_id',   :v_run_id,
        'status',   :v_final_status,
        'total',    :v_total,
        'success',  :v_success,
        'failure',  :v_failure,
        'skipped',  :v_skipped,
        'duration_seconds', :v_duration_sec
    );

EXCEPTION
    WHEN OTHER THEN
        -- Best-effort: mark the run as FAILED
        UPDATE VALIDATION_DB.RESULTS.RUN_MASTER
           SET STATUS             = 'FAILED',
               EXECUTION_END_TIME = CURRENT_TIMESTAMP(),
               ERROR_SUMMARY      = :SQLERRM
         WHERE RUN_ID = :v_run_id;

        RETURN OBJECT_CONSTRUCT(
            'run_id', :v_run_id,
            'status', 'FAILED',
            'error',  :SQLERRM
        );
END;
$$;


-- =============================================================================
-- SP_RUN_PARALLEL_GROUP
--       Lightweight executor for a single PARALLEL_GROUP.
--       Intended to be called by a dedicated Snowflake Task so that multiple
--       groups can execute concurrently in separate sessions.
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_RUN_PARALLEL_GROUP(
    P_RUN_ID         VARCHAR,
    P_PARALLEL_GROUP VARCHAR,
    P_ENVIRONMENT    VARCHAR DEFAULT 'PROD'
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_val_id        NUMBER;
    v_val_name      VARCHAR;
    v_val_type      VARCHAR;
    v_val_result    OBJECT;
    v_val_status    VARCHAR;
    v_success       NUMBER  DEFAULT 0;
    v_failure       NUMBER  DEFAULT 0;

    group_res       RESULTSET;
    c_grp           CURSOR FOR group_res;
BEGIN
    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, NULL, 'INFO', 'PARALLEL_GROUP',
        'Starting group: ' || :P_PARALLEL_GROUP
    );

    group_res := (
        SELECT VALIDATION_ID, VALIDATION_NAME, VALIDATION_TYPE
          FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG
         WHERE PARALLEL_GROUP = :P_PARALLEL_GROUP
           AND IS_ACTIVE      = TRUE
         ORDER BY EXECUTION_PRIORITY, VALIDATION_ID
    );

    OPEN c_grp;
    LOOP
        FETCH c_grp INTO v_val_id, v_val_name, v_val_type;

        IF (v_val_type = 'ROW_COUNT') THEN
            CALL VALIDATION_DB.CONFIG.SP_VALIDATE_ROW_COUNT(
                :P_RUN_ID, :v_val_id
            ) INTO v_val_result;
        ELSEIF (v_val_type = 'SCHEMA') THEN
            CALL VALIDATION_DB.CONFIG.SP_VALIDATE_SCHEMA(
                :P_RUN_ID, :v_val_id
            ) INTO v_val_result;
        ELSE
            CALL VALIDATION_DB.CONFIG.SP_VALIDATE_DATA(
                :P_RUN_ID, :v_val_id
            ) INTO v_val_result;
        END IF;

        v_val_status := NVL(v_val_result['status']::VARCHAR, 'ERROR');

        IF (v_val_status = 'PASS') THEN
            v_success := v_success + 1;
        ELSE
            v_failure := v_failure + 1;
        END IF;

    END LOOP;
    CLOSE c_grp;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, NULL, 'INFO', 'PARALLEL_GROUP',
        'Group ' || :P_PARALLEL_GROUP || ' complete.'
        || ' Pass=' || v_success::VARCHAR
        || ' Fail=' || v_failure::VARCHAR
    );

    RETURN OBJECT_CONSTRUCT(
        'group',   :P_PARALLEL_GROUP,
        'success', :v_success,
        'failure', :v_failure
    );

EXCEPTION
    WHEN OTHER THEN
        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :P_RUN_ID, NULL, 'ERROR', 'PARALLEL_GROUP',
            'Group ' || :P_PARALLEL_GROUP || ' exception: ' || SQLERRM
        );
        RETURN OBJECT_CONSTRUCT(
            'group',  :P_PARALLEL_GROUP,
            'status', 'ERROR',
            'error',  :SQLERRM
        );
END;
$$;


-- =============================================================================
-- SP_GET_RUN_SUMMARY
--       Returns a structured OBJECT with run-level KPIs and a nested array
--       of per-validation details.  Useful for programmatic inspection or
--       integration with notification/alerting pipelines.
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_GET_RUN_SUMMARY(
    P_RUN_ID VARCHAR
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_run_id            VARCHAR;
    v_status            VARCHAR;
    v_start             TIMESTAMP_NTZ;
    v_end               TIMESTAMP_NTZ;
    v_duration          NUMBER(15,3);
    v_total             NUMBER;
    v_success           NUMBER;
    v_failure           NUMBER;
    v_skipped           NUMBER;
    v_detail_array      ARRAY;

    summary_res         RESULTSET;
    c_sum               CURSOR FOR summary_res;
BEGIN
    summary_res := (
        SELECT
            RM.RUN_ID,
            RM.STATUS,
            RM.EXECUTION_START_TIME,
            RM.EXECUTION_END_TIME,
            RM.TOTAL_DURATION_SECONDS,
            RM.TOTAL_VALIDATIONS,
            RM.SUCCESS_COUNT,
            RM.FAILURE_COUNT,
            RM.SKIPPED_COUNT,
            ARRAY_AGG(
                OBJECT_CONSTRUCT(
                    'validation_name',  VD.VALIDATION_NAME,
                    'type',             VD.VALIDATION_TYPE,
                    'status',           VD.STATUS,
                    'source',           VD.SOURCE_FULL_NAME,
                    'target',           VD.TARGET_FULL_NAME,
                    'mismatch_pct',     VD.MISMATCH_PCT,
                    'exec_sec',         VD.EXECUTION_TIME_SECONDS,
                    'error',            VD.ERROR_MESSAGE
                )
            ) WITHIN GROUP (ORDER BY VD.DETAIL_ID) AS DETAIL_ARRAY
        FROM VALIDATION_DB.RESULTS.RUN_MASTER RM
        LEFT JOIN VALIDATION_DB.RESULTS.VALIDATION_DETAIL VD
               ON VD.RUN_ID = RM.RUN_ID
        WHERE RM.RUN_ID = :P_RUN_ID
        GROUP BY 1,2,3,4,5,6,7,8,9
    );

    OPEN c_sum;
    FETCH c_sum INTO
        v_run_id, v_status, v_start, v_end, v_duration,
        v_total, v_success, v_failure, v_skipped, v_detail_array;
    CLOSE c_sum;

    IF (v_run_id IS NULL) THEN
        RETURN OBJECT_CONSTRUCT('error', 'RUN_ID not found: ' || :P_RUN_ID);
    END IF;

    RETURN OBJECT_CONSTRUCT(
        'run_id',            :v_run_id,
        'status',            :v_status,
        'start_time',        :v_start::VARCHAR,
        'end_time',          :v_end::VARCHAR,
        'duration_seconds',  :v_duration,
        'total_validations', :v_total,
        'success_count',     :v_success,
        'failure_count',     :v_failure,
        'skipped_count',     :v_skipped,
        'detail',            :v_detail_array
    );

EXCEPTION
    WHEN OTHER THEN
        RETURN OBJECT_CONSTRUCT('error', :SQLERRM);
END;
$$;


-- =============================================================================
-- SP_PURGE_OLD_RESULTS
--       Deletes result rows older than P_RETENTION_DAYS across all result
--       tables in dependency order (children before parents).
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_PURGE_OLD_RESULTS(
    P_RETENTION_DAYS NUMBER DEFAULT 90
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_cutoff        DATE DEFAULT DATEADD('day', -:P_RETENTION_DAYS, CURRENT_DATE());
    v_rows_detail   NUMBER;
    v_rows_schema   NUMBER;
    v_rows_data     NUMBER;
    v_rows_log      NUMBER;
    v_rows_master   NUMBER;
BEGIN
    -- Children first to respect FK-like audit chain

    DELETE FROM VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL
     WHERE CREATED_AT < :v_cutoff;
    v_rows_data := SQLROWCOUNT;

    DELETE FROM VALIDATION_DB.RESULTS.SCHEMA_MISMATCH_DETAIL
     WHERE CREATED_AT < :v_cutoff;
    v_rows_schema := SQLROWCOUNT;

    DELETE FROM VALIDATION_DB.RESULTS.VALIDATION_DETAIL
     WHERE CREATED_AT < :v_cutoff;
    v_rows_detail := SQLROWCOUNT;

    DELETE FROM VALIDATION_DB.RESULTS.FRAMEWORK_LOG
     WHERE LOG_TIMESTAMP < :v_cutoff;
    v_rows_log := SQLROWCOUNT;

    DELETE FROM VALIDATION_DB.RESULTS.RUN_MASTER
     WHERE EXECUTION_START_TIME < :v_cutoff;
    v_rows_master := SQLROWCOUNT;

    RETURN 'Purged rows older than ' || :P_RETENTION_DAYS::VARCHAR || ' days:'
        || ' DATA_MISMATCH='   || v_rows_data::VARCHAR
        || ' SCHEMA_MISMATCH=' || v_rows_schema::VARCHAR
        || ' VALIDATION_DETAIL=' || v_rows_detail::VARCHAR
        || ' FRAMEWORK_LOG='   || v_rows_log::VARCHAR
        || ' RUN_MASTER='      || v_rows_master::VARCHAR;

EXCEPTION
    WHEN OTHER THEN
        RETURN 'PURGE ERROR: ' || SQLERRM;
END;
$$;
