-- =============================================================================
-- SNOWFLAKE DATA VALIDATION FRAMEWORK  (Snowflake Scripting / SQL)
-- File: 02_sp_row_count_schema_validation.sql
-- Description: SP_LOG_MESSAGE, FN_GENERATE_UUID, SP_VALIDATE_ROW_COUNT,
--              SP_VALIDATE_SCHEMA  — all in pure Snowflake Scripting
-- =============================================================================

-- =============================================================================
-- SP 1: SP_LOG_MESSAGE
--       Writes a log row when the message level >= the configured LOG_LEVEL.
--       Level hierarchy:  DEBUG(0) < INFO(1) < WARN(2) < ERROR(3)
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
    P_RUN_ID        VARCHAR,
    P_VALIDATION_ID NUMBER,
    P_LEVEL         VARCHAR,    -- DEBUG | INFO | WARN | ERROR
    P_STEP          VARCHAR,
    P_MESSAGE       VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_config_level  VARCHAR;
    v_msg_rank      INTEGER;
    v_cfg_rank      INTEGER;
BEGIN
    -- Resolve configured log level
    SELECT ENV_VALUE
      INTO v_config_level
      FROM VALIDATION_DB.CONFIG.ENVIRONMENT_CONFIG
     WHERE ENV_KEY = 'LOG_LEVEL';

    -- Convert level labels to numeric ranks for comparison
    v_msg_rank := CASE UPPER(P_LEVEL)
                      WHEN 'DEBUG' THEN 0
                      WHEN 'INFO'  THEN 1
                      WHEN 'WARN'  THEN 2
                      WHEN 'ERROR' THEN 3
                      ELSE 1
                  END;

    v_cfg_rank := CASE UPPER(v_config_level)
                      WHEN 'DEBUG' THEN 0
                      WHEN 'INFO'  THEN 1
                      WHEN 'WARN'  THEN 2
                      WHEN 'ERROR' THEN 3
                      ELSE 1
                  END;

    -- Only write rows at or above the configured threshold
    IF (v_msg_rank >= v_cfg_rank) THEN
        INSERT INTO VALIDATION_DB.RESULTS.FRAMEWORK_LOG
            (RUN_ID, VALIDATION_ID, LOG_LEVEL, STEP_NAME, LOG_MESSAGE)
        VALUES
            (:P_RUN_ID, :P_VALIDATION_ID, :P_LEVEL, :P_STEP, :P_MESSAGE);
        RETURN 'OK';
    ELSE
        RETURN 'SKIPPED';
    END IF;

EXCEPTION
    WHEN OTHER THEN
        RETURN 'LOG_ERROR: ' || SQLERRM;
END;
$$;


-- =============================================================================
-- FN_GENERATE_UUID
--       Generates a version-4 UUID using Snowflake's built-in function.
-- =============================================================================
CREATE OR REPLACE FUNCTION VALIDATION_DB.CONFIG.FN_GENERATE_UUID()
RETURNS VARCHAR
LANGUAGE SQL
AS
$$
    UUID_STRING()
$$;


-- =============================================================================
-- SP_VALIDATE_ROW_COUNT
--       Compares COUNT(*) between source and target tables.
--       Supports optional WHERE filters and incremental date windows.
--       Writes one row to VALIDATION_DETAIL and returns a result OBJECT.
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_VALIDATE_ROW_COUNT(
    P_RUN_ID        VARCHAR,
    P_VALIDATION_ID NUMBER
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    -- Config variables
    v_source_db             VARCHAR;
    v_source_schema         VARCHAR;
    v_source_table          VARCHAR;
    v_target_db             VARCHAR;
    v_target_schema         VARCHAR;
    v_target_table          VARCHAR;
    v_filter_condition      VARCHAR;
    v_threshold_pct         NUMBER(10,4);
    v_incremental_date_col  VARCHAR;
    v_incremental_lookback  NUMBER;
    v_validation_name       VARCHAR;

    -- Derived
    v_src_full              VARCHAR;
    v_tgt_full              VARCHAR;
    v_where_clause          VARCHAR  DEFAULT '';
    v_filter_part           VARCHAR  DEFAULT '';
    v_date_part             VARCHAR  DEFAULT '';
    v_count_sql             VARCHAR;

    -- Counts and metrics
    v_src_count             NUMBER   DEFAULT 0;
    v_tgt_count             NUMBER   DEFAULT 0;
    v_difference            NUMBER   DEFAULT 0;
    v_mismatch_pct          NUMBER(10,4) DEFAULT 0;
    v_status                VARCHAR  DEFAULT 'FAIL';

    -- Timing
    v_start_time            TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
    v_end_time              TIMESTAMP_NTZ;
    v_duration_sec          NUMBER(15,3);

    -- Temp result set handle
    res                     RESULTSET;
BEGIN
    -- -------------------------------------------------------------------------
    -- 1. Load configuration row
    -- -------------------------------------------------------------------------
    SELECT SOURCE_DB, SOURCE_SCHEMA, SOURCE_TABLE,
           TARGET_DB, TARGET_SCHEMA, TARGET_TABLE,
           NVL(FILTER_CONDITION, ''),
           NVL(THRESHOLD_PCT, 0),
           NVL(INCREMENTAL_DATE_COL, ''),
           NVL(INCREMENTAL_LOOKBACK_DAYS, 1),
           VALIDATION_NAME
      INTO v_source_db, v_source_schema, v_source_table,
           v_target_db, v_target_schema, v_target_table,
           v_filter_condition,
           v_threshold_pct,
           v_incremental_date_col,
           v_incremental_lookback,
           v_validation_name
      FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG
     WHERE VALIDATION_ID = :P_VALIDATION_ID;

    v_src_full := v_source_db  || '.' || v_source_schema  || '.' || v_source_table;
    v_tgt_full := v_target_db  || '.' || v_target_schema  || '.' || v_target_table;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'ROW_COUNT',
        'Starting row count: ' || v_validation_name || ' | ' || v_src_full || ' vs ' || v_tgt_full
    );

    -- -------------------------------------------------------------------------
    -- 2. Build WHERE clause
    --    Combine optional filter + optional incremental date window
    -- -------------------------------------------------------------------------
    IF (LENGTH(TRIM(v_filter_condition)) > 0) THEN
        v_filter_part := '(' || v_filter_condition || ')';
    END IF;

    IF (LENGTH(TRIM(v_incremental_date_col)) > 0) THEN
        v_date_part := v_incremental_date_col
                       || ' >= DATEADD(day, -'
                       || v_incremental_lookback::VARCHAR
                       || ', CURRENT_DATE())';
    END IF;

    IF (LENGTH(v_filter_part) > 0 AND LENGTH(v_date_part) > 0) THEN
        v_where_clause := ' WHERE ' || v_filter_part || ' AND ' || v_date_part;
    ELSEIF (LENGTH(v_filter_part) > 0) THEN
        v_where_clause := ' WHERE ' || v_filter_part;
    ELSEIF (LENGTH(v_date_part) > 0) THEN
        v_where_clause := ' WHERE ' || v_date_part;
    END IF;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'DEBUG', 'ROW_COUNT',
        'WHERE clause: ' || NVL(v_where_clause, '(none)')
    );

    -- -------------------------------------------------------------------------
    -- 3. Count source rows (dynamic SQL)
    -- -------------------------------------------------------------------------
    v_count_sql := 'SELECT COUNT(*) FROM ' || v_src_full || v_where_clause;
    res         := (EXECUTE IMMEDIATE :v_count_sql);
    LET cur_src CURSOR FOR res;
    OPEN cur_src;
    FETCH cur_src INTO v_src_count;
    CLOSE cur_src;

    -- -------------------------------------------------------------------------
    -- 4. Count target rows
    -- -------------------------------------------------------------------------
    v_count_sql := 'SELECT COUNT(*) FROM ' || v_tgt_full || v_where_clause;
    res         := (EXECUTE IMMEDIATE :v_count_sql);
    LET cur_tgt CURSOR FOR res;
    OPEN cur_tgt;
    FETCH cur_tgt INTO v_tgt_count;
    CLOSE cur_tgt;

    -- -------------------------------------------------------------------------
    -- 5. Evaluate pass / fail
    -- -------------------------------------------------------------------------
    v_difference := v_src_count - v_tgt_count;

    v_mismatch_pct :=
        CASE
            WHEN v_src_count > 0 THEN ABS(v_difference) / v_src_count * 100
            WHEN v_tgt_count > 0 THEN 100
            ELSE 0
        END;

    v_status := IFF(v_mismatch_pct <= v_threshold_pct, 'PASS', 'FAIL');

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'ROW_COUNT',
        'src=' || v_src_count::VARCHAR
        || ' tgt=' || v_tgt_count::VARCHAR
        || ' diff=' || v_difference::VARCHAR
        || ' mismatch_pct=' || ROUND(v_mismatch_pct, 4)::VARCHAR
        || '% threshold=' || v_threshold_pct::VARCHAR
        || '% status=' || v_status
    );

    -- -------------------------------------------------------------------------
    -- 6. Persist to VALIDATION_DETAIL
    -- -------------------------------------------------------------------------
    v_end_time    := CURRENT_TIMESTAMP();
    v_duration_sec := DATEDIFF('millisecond', v_start_time, v_end_time) / 1000.0;

    INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
        (RUN_ID, VALIDATION_ID, VALIDATION_NAME, VALIDATION_TYPE,
         SOURCE_FULL_NAME, TARGET_FULL_NAME, STATUS,
         SOURCE_VALUE, TARGET_VALUE, DIFFERENCE,
         THRESHOLD_PCT, MISMATCH_PCT,
         EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS,
         FILTER_APPLIED)
    VALUES
        (:P_RUN_ID, :P_VALIDATION_ID, :v_validation_name, 'ROW_COUNT',
         :v_src_full, :v_tgt_full, :v_status,
         :v_src_count::VARCHAR, :v_tgt_count::VARCHAR, :v_difference,
         :v_threshold_pct, :v_mismatch_pct,
         :v_start_time, :v_end_time, :v_duration_sec,
         NULLIF(TRIM(REPLACE(:v_where_clause, 'WHERE ', '')), ''));

    RETURN OBJECT_CONSTRUCT(
        'status',       :v_status,
        'source_count', :v_src_count,
        'target_count', :v_tgt_count,
        'difference',   :v_difference,
        'mismatch_pct', :v_mismatch_pct,
        'error',        NULL
    );

EXCEPTION
    WHEN OTHER THEN
        v_end_time     := CURRENT_TIMESTAMP();
        v_duration_sec := DATEDIFF('millisecond', v_start_time, v_end_time) / 1000.0;

        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :P_RUN_ID, :P_VALIDATION_ID, 'ERROR', 'ROW_COUNT',
            'Exception: ' || SQLERRM
        );

        INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
            (RUN_ID, VALIDATION_ID, VALIDATION_TYPE, STATUS,
             ERROR_MESSAGE,
             EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS)
        VALUES
            (:P_RUN_ID, :P_VALIDATION_ID, 'ROW_COUNT', 'ERROR',
             :SQLERRM,
             :v_start_time, :v_end_time, :v_duration_sec);

        RETURN OBJECT_CONSTRUCT(
            'status', 'ERROR',
            'error',  :SQLERRM
        );
END;
$$;


-- =============================================================================
-- SP_VALIDATE_SCHEMA
--       Full-outer-joins INFORMATION_SCHEMA.COLUMNS for source and target.
--       Detects 8 mismatch types; writes rows to SCHEMA_MISMATCH_DETAIL
--       and one summary row to VALIDATION_DETAIL.
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_VALIDATE_SCHEMA(
    P_RUN_ID        VARCHAR,
    P_VALIDATION_ID NUMBER
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    -- Config
    v_source_db     VARCHAR;
    v_source_schema VARCHAR;
    v_source_table  VARCHAR;
    v_target_db     VARCHAR;
    v_target_schema VARCHAR;
    v_target_table  VARCHAR;
    v_validation_name VARCHAR;

    -- Derived
    v_src_full      VARCHAR;
    v_tgt_full      VARCHAR;
    v_table_label   VARCHAR;

    -- Iteration variables
    v_column_name   VARCHAR;
    v_src_dtype     VARCHAR;
    v_tgt_dtype     VARCHAR;
    v_src_prec      VARCHAR;
    v_tgt_prec      VARCHAR;
    v_src_scale     VARCHAR;
    v_tgt_scale     VARCHAR;
    v_src_nullable  VARCHAR;
    v_tgt_nullable  VARCHAR;
    v_src_default   VARCHAR;
    v_tgt_default   VARCHAR;
    v_src_order     NUMBER;
    v_tgt_order     NUMBER;
    v_mismatch_type VARCHAR;
    v_src_attr      VARCHAR;
    v_tgt_attr      VARCHAR;

    -- Counters / status
    v_mismatch_cnt  NUMBER   DEFAULT 0;
    v_status        VARCHAR  DEFAULT 'PASS';

    -- Timing
    v_start_time    TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
    v_end_time      TIMESTAMP_NTZ;
    v_duration_sec  NUMBER(15,3);

    -- Dynamic SQL
    v_schema_sql    VARCHAR;
    schema_res      RESULTSET;
BEGIN
    -- -------------------------------------------------------------------------
    -- 1. Load config
    -- -------------------------------------------------------------------------
    SELECT SOURCE_DB, SOURCE_SCHEMA, SOURCE_TABLE,
           TARGET_DB, TARGET_SCHEMA, TARGET_TABLE,
           VALIDATION_NAME
      INTO v_source_db, v_source_schema, v_source_table,
           v_target_db, v_target_schema, v_target_table,
           v_validation_name
      FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG
     WHERE VALIDATION_ID = :P_VALIDATION_ID;

    v_src_full    := v_source_db || '.' || v_source_schema || '.' || v_source_table;
    v_tgt_full    := v_target_db || '.' || v_target_schema || '.' || v_target_table;
    v_table_label := v_src_full  || ' vs ' || v_tgt_full;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'SCHEMA',
        'Starting schema validation: ' || v_table_label
    );

    -- -------------------------------------------------------------------------
    -- 2. Build and execute the FULL OUTER JOIN diff query dynamically
    --    Interpolates database/schema/table names which cannot be parameterised.
    -- -------------------------------------------------------------------------
    v_schema_sql :=
        'WITH SRC AS (
            SELECT COLUMN_NAME, ORDINAL_POSITION, DATA_TYPE,
                   NUMERIC_PRECISION, NUMERIC_SCALE,
                   IS_NULLABLE, COLUMN_DEFAULT
            FROM ' || v_source_db || '.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER(''' || v_source_schema || ''')
              AND TABLE_NAME   = UPPER(''' || v_source_table  || ''')
         ),
         TGT AS (
            SELECT COLUMN_NAME, ORDINAL_POSITION, DATA_TYPE,
                   NUMERIC_PRECISION, NUMERIC_SCALE,
                   IS_NULLABLE, COLUMN_DEFAULT
            FROM ' || v_target_db || '.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = UPPER(''' || v_target_schema || ''')
              AND TABLE_NAME   = UPPER(''' || v_target_table  || ''')
         )
         SELECT
             COALESCE(S.COLUMN_NAME, T.COLUMN_NAME)     AS COLUMN_NAME,
             NVL(S.DATA_TYPE,  ''__ABSENT__'')           AS SRC_DATA_TYPE,
             NVL(T.DATA_TYPE,  ''__ABSENT__'')           AS TGT_DATA_TYPE,
             NVL(TO_VARCHAR(S.NUMERIC_PRECISION), '''')  AS SRC_PRECISION,
             NVL(TO_VARCHAR(T.NUMERIC_PRECISION), '''')  AS TGT_PRECISION,
             NVL(TO_VARCHAR(S.NUMERIC_SCALE),     '''')  AS SRC_SCALE,
             NVL(TO_VARCHAR(T.NUMERIC_SCALE),     '''')  AS TGT_SCALE,
             NVL(S.IS_NULLABLE, ''__ABSENT__'')          AS SRC_NULLABLE,
             NVL(T.IS_NULLABLE, ''__ABSENT__'')          AS TGT_NULLABLE,
             NVL(S.COLUMN_DEFAULT, '''')                 AS SRC_DEFAULT,
             NVL(T.COLUMN_DEFAULT, '''')                 AS TGT_DEFAULT,
             S.ORDINAL_POSITION                          AS SRC_ORDER,
             T.ORDINAL_POSITION                          AS TGT_ORDER,
             CASE
                 WHEN S.COLUMN_NAME IS NULL                          THEN ''EXTRA_IN_TARGET''
                 WHEN T.COLUMN_NAME IS NULL                          THEN ''MISSING_IN_TARGET''
                 WHEN S.DATA_TYPE  <> T.DATA_TYPE                   THEN ''DATATYPE_MISMATCH''
                 WHEN NVL(TO_VARCHAR(S.NUMERIC_PRECISION),'''')
                   <> NVL(TO_VARCHAR(T.NUMERIC_PRECISION),'''')     THEN ''PRECISION_MISMATCH''
                 WHEN NVL(TO_VARCHAR(S.NUMERIC_SCALE),'''')
                   <> NVL(TO_VARCHAR(T.NUMERIC_SCALE),'''')         THEN ''SCALE_MISMATCH''
                 WHEN NVL(S.IS_NULLABLE,'''') <> NVL(T.IS_NULLABLE,'''') THEN ''NULLABLE_MISMATCH''
                 WHEN NVL(S.COLUMN_DEFAULT,'''') <> NVL(T.COLUMN_DEFAULT,'''') THEN ''DEFAULT_MISMATCH''
                 WHEN S.ORDINAL_POSITION IS DISTINCT FROM T.ORDINAL_POSITION THEN ''ORDER_MISMATCH''
                 ELSE ''MATCH''
             END AS MISMATCH_TYPE
         FROM SRC S
         FULL OUTER JOIN TGT T ON UPPER(S.COLUMN_NAME) = UPPER(T.COLUMN_NAME)
         ORDER BY COALESCE(S.ORDINAL_POSITION, T.ORDINAL_POSITION)';

    schema_res := (EXECUTE IMMEDIATE :v_schema_sql);

    -- -------------------------------------------------------------------------
    -- 3. Cursor loop: collect and persist every non-MATCH row
    -- -------------------------------------------------------------------------
    LET schema_cur CURSOR FOR schema_res;
    OPEN schema_cur;

    LOOP
        FETCH schema_cur INTO
            v_column_name,
            v_src_dtype,  v_tgt_dtype,
            v_src_prec,   v_tgt_prec,
            v_src_scale,  v_tgt_scale,
            v_src_nullable, v_tgt_nullable,
            v_src_default,  v_tgt_default,
            v_src_order,  v_tgt_order,
            v_mismatch_type;

        IF (v_mismatch_type = 'MATCH') THEN
            CONTINUE;
        END IF;

        -- Map mismatch type → human-readable source/target attribute labels
        CASE v_mismatch_type
            WHEN 'DATATYPE_MISMATCH'   THEN
                v_src_attr := v_src_dtype;
                v_tgt_attr := v_tgt_dtype;
            WHEN 'PRECISION_MISMATCH'  THEN
                v_src_attr := 'PRECISION:' || v_src_prec;
                v_tgt_attr := 'PRECISION:' || v_tgt_prec;
            WHEN 'SCALE_MISMATCH'      THEN
                v_src_attr := 'SCALE:' || v_src_scale;
                v_tgt_attr := 'SCALE:' || v_tgt_scale;
            WHEN 'NULLABLE_MISMATCH'   THEN
                v_src_attr := 'NULLABLE:' || v_src_nullable;
                v_tgt_attr := 'NULLABLE:' || v_tgt_nullable;
            WHEN 'DEFAULT_MISMATCH'    THEN
                v_src_attr := 'DEFAULT:' || v_src_default;
                v_tgt_attr := 'DEFAULT:' || v_tgt_default;
            WHEN 'ORDER_MISMATCH'      THEN
                v_src_attr := 'ORDER:' || NVL(v_src_order::VARCHAR, '?');
                v_tgt_attr := 'ORDER:' || NVL(v_tgt_order::VARCHAR, '?');
            WHEN 'MISSING_IN_TARGET'   THEN
                v_src_attr := v_src_dtype;
                v_tgt_attr := 'ABSENT';
            WHEN 'EXTRA_IN_TARGET'     THEN
                v_src_attr := 'ABSENT';
                v_tgt_attr := v_tgt_dtype;
            ELSE
                v_src_attr := '?';
                v_tgt_attr := '?';
        END CASE;

        v_mismatch_cnt := v_mismatch_cnt + 1;

        INSERT INTO VALIDATION_DB.RESULTS.SCHEMA_MISMATCH_DETAIL
            (RUN_ID, VALIDATION_ID, TABLE_NAME, COLUMN_NAME,
             MISMATCH_TYPE, SOURCE_ATTRIBUTE, TARGET_ATTRIBUTE,
             COLUMN_ORDER_SOURCE, COLUMN_ORDER_TARGET)
        VALUES
            (:P_RUN_ID, :P_VALIDATION_ID, :v_table_label, :v_column_name,
             :v_mismatch_type, :v_src_attr, :v_tgt_attr,
             :v_src_order, :v_tgt_order);

    END LOOP;

    CLOSE schema_cur;

    -- -------------------------------------------------------------------------
    -- 4. Finalise and persist summary
    -- -------------------------------------------------------------------------
    v_status       := IFF(v_mismatch_cnt = 0, 'PASS', 'FAIL');
    v_end_time     := CURRENT_TIMESTAMP();
    v_duration_sec := DATEDIFF('millisecond', v_start_time, v_end_time) / 1000.0;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'SCHEMA',
        'Schema validation complete. Mismatches: ' || v_mismatch_cnt::VARCHAR
        || '  Status: ' || v_status
    );

    INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
        (RUN_ID, VALIDATION_ID, VALIDATION_NAME, VALIDATION_TYPE,
         SOURCE_FULL_NAME, TARGET_FULL_NAME, STATUS,
         SOURCE_VALUE, TARGET_VALUE, MISMATCH_ROW_COUNT,
         EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS)
    VALUES
        (:P_RUN_ID, :P_VALIDATION_ID, :v_validation_name, 'SCHEMA',
         :v_src_full, :v_tgt_full, :v_status,
         'SCHEMA_COLUMNS', :v_mismatch_cnt::VARCHAR, :v_mismatch_cnt,
         :v_start_time, :v_end_time, :v_duration_sec);

    RETURN OBJECT_CONSTRUCT(
        'status',         :v_status,
        'mismatch_count', :v_mismatch_cnt,
        'error',          NULL
    );

EXCEPTION
    WHEN OTHER THEN
        v_end_time     := CURRENT_TIMESTAMP();
        v_duration_sec := DATEDIFF('millisecond', v_start_time, v_end_time) / 1000.0;

        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :P_RUN_ID, :P_VALIDATION_ID, 'ERROR', 'SCHEMA',
            'Exception: ' || SQLERRM
        );

        INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
            (RUN_ID, VALIDATION_ID, VALIDATION_TYPE, STATUS,
             ERROR_MESSAGE,
             EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS)
        VALUES
            (:P_RUN_ID, :P_VALIDATION_ID, 'SCHEMA', 'ERROR',
             :SQLERRM,
             :v_start_time, :v_end_time, :v_duration_sec);

        RETURN OBJECT_CONSTRUCT(
            'status', 'ERROR',
            'error',  :SQLERRM
        );
END;
$$;
