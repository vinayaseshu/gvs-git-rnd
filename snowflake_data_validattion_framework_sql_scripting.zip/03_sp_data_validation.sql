-- =============================================================================
-- SNOWFLAKE DATA VALIDATION FRAMEWORK  (Snowflake Scripting / SQL)
-- File: 03_sp_data_validation.sql
-- Description: SP_VALIDATE_DATA — unified dispatcher for full, incremental,
--              sample, and hash-based data comparisons.
--              SP_VALIDATE_DATA_HASH — dedicated hash comparison sub-routine.
-- =============================================================================

-- =============================================================================
-- SP_VALIDATE_DATA_HASH
--       Hash-based row comparison for very large tables.
--       Computes MD5 of all non-key, non-excluded columns per row,
--       then FULL OUTER JOINs on the key to find differences.
--       Called internally by SP_VALIDATE_DATA when type = DATA_HASH.
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_VALIDATE_DATA_HASH(
    P_RUN_ID            VARCHAR,
    P_VALIDATION_ID     NUMBER,
    P_VALIDATION_NAME   VARCHAR,
    P_SRC_FULL          VARCHAR,
    P_TGT_FULL          VARCHAR,
    P_KEY_EXPR          VARCHAR,   -- Concatenated key expression string
    P_HASH_COLS_EXPR    VARCHAR,   -- Pipe-delimited hash input expression
    P_WHERE_CLAUSE      VARCHAR,   -- Full WHERE clause (or empty string)
    P_THRESHOLD_PCT     NUMBER,
    P_START_TIME        TIMESTAMP_NTZ
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_hash_sql      VARCHAR;
    v_mismatch_cnt  NUMBER  DEFAULT 0;
    v_total_rows    NUMBER  DEFAULT 0;
    v_mismatch_pct  NUMBER(10,4) DEFAULT 0;
    v_status        VARCHAR DEFAULT 'FAIL';
    v_end_time      TIMESTAMP_NTZ;
    v_duration_sec  NUMBER(15,3);
    cnt_res         RESULTSET;
    c_cnt           CURSOR FOR cnt_res;
BEGIN
    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'HASH_VALIDATION',
        'Starting hash comparison for ' || :P_SRC_FULL
    );

    -- -------------------------------------------------------------------------
    -- Insert mismatches: keys whose MD5 hashes differ between src and tgt
    -- -------------------------------------------------------------------------
    v_hash_sql :=
        'INSERT INTO VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL
             (VALIDATION_ID, RUN_ID, TABLE_NAME, KEY_VALUE,
              COLUMN_NAME, SOURCE_VALUE, TARGET_VALUE, MISMATCH_REASON)
         WITH SRC_H AS (
             SELECT ' || :P_KEY_EXPR         || ' AS KEY_VAL,
                    MD5(' || :P_HASH_COLS_EXPR || ') AS ROW_HASH
             FROM ' || :P_SRC_FULL || :P_WHERE_CLAUSE || '
         ),
         TGT_H AS (
             SELECT ' || :P_KEY_EXPR         || ' AS KEY_VAL,
                    MD5(' || :P_HASH_COLS_EXPR || ') AS ROW_HASH
             FROM ' || :P_TGT_FULL || :P_WHERE_CLAUSE || '
         )
         SELECT ' || :P_VALIDATION_ID::VARCHAR || ',
                ''' || :P_RUN_ID || ''',
                ''' || :P_SRC_FULL || ' vs ' || :P_TGT_FULL || ''',
                COALESCE(S.KEY_VAL, T.KEY_VAL),
                ''__ROW_HASH__'',
                NVL(S.ROW_HASH, ''__NULL__''),
                NVL(T.ROW_HASH, ''__NULL__''),
                CASE
                    WHEN S.KEY_VAL IS NULL THEN ''MISSING_IN_SOURCE''
                    WHEN T.KEY_VAL IS NULL THEN ''MISSING_IN_TARGET''
                    ELSE ''HASH_MISMATCH''
                END
         FROM SRC_H S
         FULL OUTER JOIN TGT_H T ON S.KEY_VAL = T.KEY_VAL
         WHERE S.ROW_HASH IS DISTINCT FROM T.ROW_HASH';

    EXECUTE IMMEDIATE :v_hash_sql;

    -- -------------------------------------------------------------------------
    -- Count mismatches and source total for percentage
    -- -------------------------------------------------------------------------
    cnt_res := (
        SELECT COUNT(*) AS MC
          FROM VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL
         WHERE RUN_ID        = :P_RUN_ID
           AND VALIDATION_ID = :P_VALIDATION_ID
    );
    OPEN c_cnt; FETCH c_cnt INTO v_mismatch_cnt; CLOSE c_cnt;

    EXECUTE IMMEDIATE
        'SELECT COUNT(*) FROM ' || :P_SRC_FULL || :P_WHERE_CLAUSE
        INTO v_total_rows;

    v_mismatch_pct :=
        CASE
            WHEN v_total_rows  > 0 THEN v_mismatch_cnt / v_total_rows * 100
            WHEN v_mismatch_cnt > 0 THEN 100
            ELSE 0
        END;

    v_status       := IFF(v_mismatch_pct <= :P_THRESHOLD_PCT, 'PASS', 'FAIL');
    v_end_time     := CURRENT_TIMESTAMP();
    v_duration_sec := DATEDIFF('millisecond', :P_START_TIME, v_end_time) / 1000.0;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'HASH_VALIDATION',
        'Hash complete. Mismatches=' || v_mismatch_cnt::VARCHAR
        || ' Pct=' || ROUND(v_mismatch_pct, 4)::VARCHAR
        || '% Status=' || v_status
    );

    INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
        (RUN_ID, VALIDATION_ID, VALIDATION_NAME, VALIDATION_TYPE,
         SOURCE_FULL_NAME, TARGET_FULL_NAME, STATUS,
         SOURCE_VALUE, TARGET_VALUE, MISMATCH_ROW_COUNT,
         THRESHOLD_PCT, MISMATCH_PCT,
         EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS)
    VALUES
        (:P_RUN_ID, :P_VALIDATION_ID, :P_VALIDATION_NAME, 'DATA_HASH',
         :P_SRC_FULL, :P_TGT_FULL, :v_status,
         :v_total_rows::VARCHAR, :v_mismatch_cnt::VARCHAR, :v_mismatch_cnt,
         :P_THRESHOLD_PCT, :v_mismatch_pct,
         :P_START_TIME, :v_end_time, :v_duration_sec);

    RETURN OBJECT_CONSTRUCT(
        'status',        :v_status,
        'mismatch_count',:v_mismatch_cnt,
        'mismatch_pct',  :v_mismatch_pct,
        'total_rows',    :v_total_rows,
        'error',         NULL
    );

EXCEPTION
    WHEN OTHER THEN
        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :P_RUN_ID, :P_VALIDATION_ID, 'ERROR', 'HASH_VALIDATION',
            'Exception: ' || SQLERRM
        );
        RETURN OBJECT_CONSTRUCT('status', 'ERROR', 'error', :SQLERRM);
END;
$$;


-- =============================================================================
-- SP_VALIDATE_DATA
--       Unified data-comparison dispatcher.
--       Reads config, resolves columns dynamically, builds the mismatch SQL,
--       and routes to hash sub-SP when VALIDATION_TYPE = DATA_HASH.
--
--       Supported types:
--         DATA_FULL        – complete FULL OUTER JOIN comparison
--         DATA_INCREMENTAL – same, but filtered to an incremental date window
--         DATA_SAMPLE      – same, with TABLESAMPLE (N%) on both sides
--         DATA_HASH        – MD5-hash-per-row approach for large tables
-- =============================================================================
CREATE OR REPLACE PROCEDURE VALIDATION_DB.CONFIG.SP_VALIDATE_DATA(
    P_RUN_ID        VARCHAR,
    P_VALIDATION_ID NUMBER
)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    -- Config variables
    v_source_db         VARCHAR;
    v_source_schema     VARCHAR;
    v_source_table      VARCHAR;
    v_target_db         VARCHAR;
    v_target_schema     VARCHAR;
    v_target_table      VARCHAR;
    v_filter_condition  VARCHAR;
    v_threshold_pct     NUMBER(10,4);
    v_validation_type   VARCHAR;
    v_incremental_col   VARCHAR;
    v_lookback_days     NUMBER;
    v_sample_pct        NUMBER(5,2);
    v_validation_name   VARCHAR;
    v_key_columns       VARCHAR;
    v_excluded_columns  VARCHAR;
    v_max_mismatch_rows NUMBER;

    -- Derived names
    v_src_full          VARCHAR;
    v_tgt_full          VARCHAR;
    v_src_from          VARCHAR;   -- May include TABLESAMPLE
    v_tgt_from          VARCHAR;

    -- WHERE clause parts
    v_where_clause      VARCHAR DEFAULT '';
    v_filter_part       VARCHAR DEFAULT '';
    v_date_part         VARCHAR DEFAULT '';

    -- Column lists built via dynamic SQL
    v_key_cols_csv      VARCHAR DEFAULT '';
    v_compare_cols_csv  VARCHAR DEFAULT '';
    v_first_col         VARCHAR DEFAULT '';

    -- SQL fragments assembled for mismatch detection
    v_key_expr_src      VARCHAR;   -- Key concat expression using SRC. prefix
    v_key_expr_tgt      VARCHAR;   -- Key concat expression using TGT. prefix
    v_key_expr_s        VARCHAR;   -- Key concat using S. prefix (join block)
    v_join_pred         VARCHAR;   -- ON clause for FULL OUTER JOIN
    v_hash_cols_expr    VARCHAR;   -- Pipe-concat of all compare cols for MD5
    v_mismatch_sql      VARCHAR;
    v_union_blocks      VARCHAR DEFAULT '';
    v_col_block         VARCHAR;

    -- Counters and metrics
    v_mismatch_cnt      NUMBER  DEFAULT 0;
    v_total_rows        NUMBER  DEFAULT 0;
    v_dup_count         NUMBER  DEFAULT 0;
    v_mismatch_pct      NUMBER(10,4) DEFAULT 0;
    v_status            VARCHAR DEFAULT 'FAIL';

    -- Timing
    v_start_time        TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
    v_end_time          TIMESTAMP_NTZ;
    v_duration_sec      NUMBER(15,3);

    -- Temp cursors / resultsets
    col_res             RESULTSET;
    c_col               CURSOR FOR col_res;
    cnt_res             RESULTSET;
    c_cnt               CURSOR FOR cnt_res;
    v_col_name          VARCHAR;
    v_col_is_key        BOOLEAN;
    v_col_is_excl       BOOLEAN;

    -- Hash sub-SP result
    v_hash_result       OBJECT;
    v_hash_status       VARCHAR;

BEGIN
    -- -------------------------------------------------------------------------
    -- 1. Load config row
    -- -------------------------------------------------------------------------
    SELECT SOURCE_DB, SOURCE_SCHEMA, SOURCE_TABLE,
           TARGET_DB, TARGET_SCHEMA, TARGET_TABLE,
           NVL(FILTER_CONDITION,''),
           NVL(THRESHOLD_PCT, 0),
           VALIDATION_TYPE,
           NVL(INCREMENTAL_DATE_COL,''),
           NVL(INCREMENTAL_LOOKBACK_DAYS, 1),
           NVL(SAMPLE_PCT, 10),
           VALIDATION_NAME,
           NVL(KEY_COLUMNS,''),
           NVL(EXCLUDED_COLUMNS,'')
      INTO v_source_db, v_source_schema, v_source_table,
           v_target_db, v_target_schema, v_target_table,
           v_filter_condition, v_threshold_pct,
           v_validation_type,
           v_incremental_col, v_lookback_days,
           v_sample_pct, v_validation_name,
           v_key_columns, v_excluded_columns
      FROM VALIDATION_DB.CONFIG.VALIDATION_CONFIG
     WHERE VALIDATION_ID = :P_VALIDATION_ID;

    SELECT NVL(TRY_CAST(ENV_VALUE AS NUMBER), 100000)
      INTO v_max_mismatch_rows
      FROM VALIDATION_DB.CONFIG.ENVIRONMENT_CONFIG
     WHERE ENV_KEY = 'MAX_MISMATCH_ROWS';

    v_src_full := v_source_db || '.' || v_source_schema || '.' || v_source_table;
    v_tgt_full := v_target_db || '.' || v_target_schema || '.' || v_target_table;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'DATA_VALIDATION',
        'Starting ' || v_validation_type || ': ' || v_src_full || ' vs ' || v_tgt_full
    );

    -- -------------------------------------------------------------------------
    -- 2. Build WHERE clause
    -- -------------------------------------------------------------------------
    IF (LENGTH(TRIM(v_filter_condition)) > 0) THEN
        v_filter_part := '(' || v_filter_condition || ')';
    END IF;

    IF (v_validation_type = 'DATA_INCREMENTAL' AND LENGTH(TRIM(v_incremental_col)) > 0) THEN
        v_date_part := v_incremental_col
                       || ' >= DATEADD(day, -' || v_lookback_days::VARCHAR || ', CURRENT_DATE())';
    END IF;

    IF (LENGTH(v_filter_part) > 0 AND LENGTH(v_date_part) > 0) THEN
        v_where_clause := ' WHERE ' || v_filter_part || ' AND ' || v_date_part;
    ELSEIF (LENGTH(v_filter_part) > 0) THEN
        v_where_clause := ' WHERE ' || v_filter_part;
    ELSEIF (LENGTH(v_date_part) > 0) THEN
        v_where_clause := ' WHERE ' || v_date_part;
    END IF;

    -- TABLESAMPLE modifier for DATA_SAMPLE type
    v_src_from := v_src_full || IFF(v_validation_type = 'DATA_SAMPLE',
                                    ' TABLESAMPLE (' || v_sample_pct::VARCHAR || ')', '');
    v_tgt_from := v_tgt_full || IFF(v_validation_type = 'DATA_SAMPLE',
                                    ' TABLESAMPLE (' || v_sample_pct::VARCHAR || ')', '');

    -- -------------------------------------------------------------------------
    -- 3. Resolve key columns and compare columns from INFORMATION_SCHEMA
    --    Merges: VALIDATION_CONFIG.KEY_COLUMNS / EXCLUDED_COLUMNS
    --            + VALIDATION_COLUMN_CONFIG overrides
    -- -------------------------------------------------------------------------
    -- Build a staging table in-session using a transient temp table approach.
    -- We accumulate key / compare column lists as comma-separated VARCHAR.

    -- Load actual columns from source INFORMATION_SCHEMA into a temp table
    EXECUTE IMMEDIATE
        'CREATE OR REPLACE TEMPORARY TABLE VALIDATION_DB.STAGING.TMP_COL_RESOLVE_'
        || :P_VALIDATION_ID::VARCHAR || ' AS
         SELECT C.COLUMN_NAME,
                C.ORDINAL_POSITION,
                CASE WHEN UPPER(C.COLUMN_NAME)
                          = ANY (SELECT TRIM(VALUE)
                                   FROM TABLE(SPLIT_TO_TABLE(UPPER('''
                || v_key_columns || '''), '',''))
                               )
                     THEN TRUE ELSE FALSE END AS IS_KEY,
                CASE WHEN UPPER(C.COLUMN_NAME)
                          = ANY (SELECT TRIM(VALUE)
                                   FROM TABLE(SPLIT_TO_TABLE(UPPER('''
                || v_excluded_columns || '''), '',''))
                               )
                          OR UPPER(C.COLUMN_NAME)
                          = ANY (SELECT UPPER(CC.COLUMN_NAME)
                                   FROM VALIDATION_DB.CONFIG.VALIDATION_COLUMN_CONFIG CC
                                  WHERE CC.VALIDATION_ID = '
                || :P_VALIDATION_ID::VARCHAR || '
                                    AND CC.IS_EXCLUDED = TRUE)
                     THEN TRUE ELSE FALSE END AS IS_EXCLUDED
         FROM ' || v_source_db || '.INFORMATION_SCHEMA.COLUMNS C
         WHERE C.TABLE_SCHEMA = UPPER(''' || v_source_schema || ''')
           AND C.TABLE_NAME   = UPPER(''' || v_source_table  || ''')
         ORDER BY C.ORDINAL_POSITION';

    -- Also apply IS_KEY overrides from VALIDATION_COLUMN_CONFIG
    EXECUTE IMMEDIATE
        'UPDATE VALIDATION_DB.STAGING.TMP_COL_RESOLVE_' || :P_VALIDATION_ID::VARCHAR || '
         SET IS_KEY = TRUE
         WHERE UPPER(COLUMN_NAME) IN (
             SELECT UPPER(COLUMN_NAME)
               FROM VALIDATION_DB.CONFIG.VALIDATION_COLUMN_CONFIG
              WHERE VALIDATION_ID = ' || :P_VALIDATION_ID::VARCHAR || '
                AND IS_KEY_COLUMN = TRUE
         )';

    -- If no key columns resolved, default to the first column
    LET key_check_res RESULTSET := (
        SELECT COUNT(*) FROM IDENTIFIER('VALIDATION_DB.STAGING.TMP_COL_RESOLVE_'
            || :P_VALIDATION_ID::VARCHAR) WHERE IS_KEY = TRUE
    );
    LET kc CURSOR FOR key_check_res;
    OPEN kc;
    FETCH kc INTO v_dup_count;   -- reusing variable
    CLOSE kc;

    IF (v_dup_count = 0) THEN
        EXECUTE IMMEDIATE
            'UPDATE VALIDATION_DB.STAGING.TMP_COL_RESOLVE_' || :P_VALIDATION_ID::VARCHAR || '
             SET IS_KEY = TRUE
             WHERE ORDINAL_POSITION = (
                 SELECT MIN(ORDINAL_POSITION)
                   FROM VALIDATION_DB.STAGING.TMP_COL_RESOLVE_'
             || :P_VALIDATION_ID::VARCHAR || ')';
    END IF;

    -- Materialise key and compare column lists as CSV strings
    EXECUTE IMMEDIATE
        'SELECT LISTAGG(CASE WHEN IS_KEY     = TRUE AND IS_EXCLUDED = FALSE
                              THEN COLUMN_NAME END, '','')
                        WITHIN GROUP (ORDER BY ORDINAL_POSITION),
                LISTAGG(CASE WHEN IS_KEY     = FALSE AND IS_EXCLUDED = FALSE
                              THEN COLUMN_NAME END, '','')
                        WITHIN GROUP (ORDER BY ORDINAL_POSITION),
                MIN(COLUMN_NAME)
           FROM VALIDATION_DB.STAGING.TMP_COL_RESOLVE_' || :P_VALIDATION_ID::VARCHAR
    INTO v_key_cols_csv, v_compare_cols_csv, v_first_col;

    -- Null-guard
    v_key_cols_csv     := NVL(NULLIF(TRIM(v_key_cols_csv),    ''), v_first_col);
    v_compare_cols_csv := NVL(NULLIF(TRIM(v_compare_cols_csv),''), '');

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'DEBUG', 'DATA_VALIDATION',
        'Key cols: [' || v_key_cols_csv || ']  Compare cols: ['
        || LEFT(v_compare_cols_csv, 200) || ']'
    );

    -- -------------------------------------------------------------------------
    -- 4. Build key concat expressions
    --    Pattern: COALESCE(TO_VARCHAR(SRC.COL1),'__NULL__')||'|'||...
    -- -------------------------------------------------------------------------
    EXECUTE IMMEDIATE
        'SELECT
             LISTAGG(''COALESCE(TO_VARCHAR(SRC.'' || COLUMN_NAME || ''),''''__NULL__'''')'', ''||''''|''''||'')
                     WITHIN GROUP (ORDER BY ORDINAL_POSITION),
             LISTAGG(''COALESCE(TO_VARCHAR(TGT.'' || COLUMN_NAME || ''),''''__NULL__'''')'', ''||''''|''''||'')
                     WITHIN GROUP (ORDER BY ORDINAL_POSITION),
             LISTAGG(''COALESCE(TO_VARCHAR(S.''   || COLUMN_NAME || ''),''''__NULL__'''')'', ''||''''|''''||'')
                     WITHIN GROUP (ORDER BY ORDINAL_POSITION)
         FROM VALIDATION_DB.STAGING.TMP_COL_RESOLVE_' || :P_VALIDATION_ID::VARCHAR || '
         WHERE IS_KEY = TRUE AND IS_EXCLUDED = FALSE'
    INTO v_key_expr_src, v_key_expr_tgt, v_key_expr_s;

    -- JOIN predicate
    EXECUTE IMMEDIATE
        'SELECT LISTAGG(
             ''COALESCE(TO_VARCHAR(S.'' || COLUMN_NAME || ''),''''__NULL____'') = ''
             ||''COALESCE(TO_VARCHAR(T.'' || COLUMN_NAME || ''),''''__NULL____'')'',
             '' AND '')
             WITHIN GROUP (ORDER BY ORDINAL_POSITION)
         FROM VALIDATION_DB.STAGING.TMP_COL_RESOLVE_' || :P_VALIDATION_ID::VARCHAR || '
         WHERE IS_KEY = TRUE AND IS_EXCLUDED = FALSE'
    INTO v_join_pred;

    -- Hash expression for DATA_HASH type
    EXECUTE IMMEDIATE
        'SELECT LISTAGG(''COALESCE(TO_VARCHAR('' || COLUMN_NAME || ''),'''''''')'',
                        ''||''''|''''||'')
                 WITHIN GROUP (ORDER BY ORDINAL_POSITION)
         FROM VALIDATION_DB.STAGING.TMP_COL_RESOLVE_' || :P_VALIDATION_ID::VARCHAR || '
         WHERE IS_KEY = FALSE AND IS_EXCLUDED = FALSE'
    INTO v_hash_cols_expr;

    -- -------------------------------------------------------------------------
    -- 5. Route DATA_HASH to dedicated sub-procedure
    -- -------------------------------------------------------------------------
    IF (v_validation_type = 'DATA_HASH') THEN
        CALL VALIDATION_DB.CONFIG.SP_VALIDATE_DATA_HASH(
            :P_RUN_ID,
            :P_VALIDATION_ID,
            :v_validation_name,
            :v_src_full,
            :v_tgt_full,
            :v_key_expr_s,
            :v_hash_cols_expr,
            :v_where_clause,
            :v_threshold_pct,
            :v_start_time
        ) INTO v_hash_result;

        -- Clean up temp table
        EXECUTE IMMEDIATE
            'DROP TABLE IF EXISTS VALIDATION_DB.STAGING.TMP_COL_RESOLVE_'
            || :P_VALIDATION_ID::VARCHAR;

        RETURN :v_hash_result;
    END IF;

    -- -------------------------------------------------------------------------
    -- 6. Duplicate key check (warning only)
    -- -------------------------------------------------------------------------
    EXECUTE IMMEDIATE
        'SELECT COUNT(*) FROM (
             SELECT ' || v_key_cols_csv || ', COUNT(*) AS CNT
               FROM ' || v_src_from || v_where_clause || '
             GROUP BY ' || v_key_cols_csv || '
             HAVING COUNT(*) > 1
         )'
    INTO v_dup_count;

    IF (v_dup_count > 0) THEN
        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :P_RUN_ID, :P_VALIDATION_ID, 'WARN', 'DATA_VALIDATION',
            'Source has ' || v_dup_count::VARCHAR || ' duplicate key groups'
        );
    END IF;

    -- -------------------------------------------------------------------------
    -- 7. Build and execute mismatch INSERT … SELECT
    --
    --    Structure (UNION ALL blocks):
    --      Block A : rows present in source but missing in target
    --      Block B : rows present in target but missing in source
    --      Block C : per-column value mismatch (one block per compare column)
    --      Block D : duplicate keys (top 1000 only)
    -- -------------------------------------------------------------------------

    -- Block A – MISSING_IN_TARGET
    v_union_blocks :=
        'SELECT ' || :P_VALIDATION_ID::VARCHAR || ' AS VALIDATION_ID,
                ''' || :P_RUN_ID || ''' AS RUN_ID,
                ''' || v_src_full || ' vs ' || v_tgt_full || ''' AS TABLE_NAME,
                ' || v_key_expr_src || ' AS KEY_VALUE,
                ''__ROW__''   AS COLUMN_NAME,
                ''EXISTS''    AS SOURCE_VALUE,
                NULL          AS TARGET_VALUE,
                ''MISSING_IN_TARGET'' AS MISMATCH_REASON
         FROM ' || v_src_from || ' SRC' || v_where_clause || '
         WHERE (' || v_key_expr_src || ') NOT IN (
             SELECT ' || v_key_expr_tgt || ' FROM ' || v_tgt_from || ' TGT'
             || v_where_clause || '
         )';

    -- Block B – MISSING_IN_SOURCE
    v_union_blocks := v_union_blocks ||
        ' UNION ALL
         SELECT ' || :P_VALIDATION_ID::VARCHAR || ',
                ''' || :P_RUN_ID || ''',
                ''' || v_src_full || ' vs ' || v_tgt_full || ''',
                ' || v_key_expr_tgt || ',
                ''__ROW__'', NULL, ''EXISTS'', ''MISSING_IN_SOURCE''
         FROM ' || v_tgt_from || ' TGT' || v_where_clause || '
         WHERE (' || v_key_expr_tgt || ') NOT IN (
             SELECT ' || v_key_expr_src || ' FROM ' || v_src_from || ' SRC'
             || v_where_clause || '
         )';

    -- Blocks C – per-column VALUE_MISMATCH
    -- Iterate over compare columns using the temp table
    col_res := (
        SELECT COLUMN_NAME
          FROM IDENTIFIER('VALIDATION_DB.STAGING.TMP_COL_RESOLVE_'
               || :P_VALIDATION_ID::VARCHAR)
         WHERE IS_KEY      = FALSE
           AND IS_EXCLUDED = FALSE
         ORDER BY ORDINAL_POSITION
    );
    OPEN c_col;
    LOOP
        FETCH c_col INTO v_col_name;

        v_col_block :=
            ' UNION ALL
             SELECT ' || :P_VALIDATION_ID::VARCHAR || ',
                    ''' || :P_RUN_ID || ''',
                    ''' || v_src_full || ' vs ' || v_tgt_full || ''',
                    ' || v_key_expr_s || ',
                    ''' || v_col_name || ''',
                    COALESCE(TO_VARCHAR(S.' || v_col_name || '),''__NULL__''),
                    COALESCE(TO_VARCHAR(T.' || v_col_name || '),''__NULL__''),
                    ''VALUE_MISMATCH''
             FROM ' || v_src_from || ' S
             JOIN ' || v_tgt_from || ' T ON ' || v_join_pred
             || IFF(LENGTH(v_where_clause) > 0, v_where_clause, '')
             || ' WHERE COALESCE(TO_VARCHAR(S.' || v_col_name || '),''__NULL__'')
                     <> COALESCE(TO_VARCHAR(T.' || v_col_name || '),''__NULL__'')';

        v_union_blocks := v_union_blocks || v_col_block;
    END LOOP;
    CLOSE c_col;

    -- Block D – DUPLICATE_KEY (capped at 1000 rows)
    v_union_blocks := v_union_blocks ||
        ' UNION ALL
         SELECT ' || :P_VALIDATION_ID::VARCHAR || ',
                ''' || :P_RUN_ID || ''',
                ''' || v_src_full || ' vs ' || v_tgt_full || ''',
                ' || v_key_cols_csv || ',
                ''__KEY__'',
                TO_VARCHAR(COUNT(*)), NULL, ''DUPLICATE_KEY''
         FROM ' || v_src_from || v_where_clause || '
         GROUP BY ' || v_key_cols_csv || '
         HAVING COUNT(*) > 1
         LIMIT 1000';

    -- Final INSERT
    v_mismatch_sql :=
        'INSERT INTO VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL
             (VALIDATION_ID, RUN_ID, TABLE_NAME, KEY_VALUE,
              COLUMN_NAME, SOURCE_VALUE, TARGET_VALUE, MISMATCH_REASON)
         SELECT VALIDATION_ID, RUN_ID, TABLE_NAME, KEY_VALUE,
                COLUMN_NAME, SOURCE_VALUE, TARGET_VALUE, MISMATCH_REASON
         FROM (' || v_union_blocks || ') M
         LIMIT ' || v_max_mismatch_rows::VARCHAR;

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'DEBUG', 'DATA_VALIDATION',
        'Executing mismatch detection INSERT…SELECT'
    );

    EXECUTE IMMEDIATE :v_mismatch_sql;

    -- -------------------------------------------------------------------------
    -- 8. Count results and evaluate status
    -- -------------------------------------------------------------------------
    cnt_res := (
        SELECT COUNT(*) AS MC
          FROM VALIDATION_DB.RESULTS.DATA_MISMATCH_DETAIL
         WHERE RUN_ID        = :P_RUN_ID
           AND VALIDATION_ID = :P_VALIDATION_ID
    );
    OPEN c_cnt; FETCH c_cnt INTO v_mismatch_cnt; CLOSE c_cnt;

    EXECUTE IMMEDIATE
        'SELECT COUNT(*) FROM ' || v_src_from || v_where_clause
        INTO v_total_rows;

    v_mismatch_pct :=
        CASE
            WHEN v_total_rows  > 0 THEN v_mismatch_cnt / v_total_rows * 100
            WHEN v_mismatch_cnt > 0 THEN 100
            ELSE 0
        END;

    v_status := IFF(v_mismatch_pct <= v_threshold_pct, 'PASS', 'FAIL');

    CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
        :P_RUN_ID, :P_VALIDATION_ID, 'INFO', 'DATA_VALIDATION',
        'Complete. Mismatches=' || v_mismatch_cnt::VARCHAR
        || ' Pct=' || ROUND(v_mismatch_pct, 4)::VARCHAR
        || '% Status=' || v_status
    );

    -- -------------------------------------------------------------------------
    -- 9. Persist summary to VALIDATION_DETAIL
    -- -------------------------------------------------------------------------
    v_end_time     := CURRENT_TIMESTAMP();
    v_duration_sec := DATEDIFF('millisecond', v_start_time, v_end_time) / 1000.0;

    INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
        (RUN_ID, VALIDATION_ID, VALIDATION_NAME, VALIDATION_TYPE,
         SOURCE_FULL_NAME, TARGET_FULL_NAME, STATUS,
         SOURCE_VALUE, TARGET_VALUE, MISMATCH_ROW_COUNT,
         THRESHOLD_PCT, MISMATCH_PCT,
         EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS,
         FILTER_APPLIED)
    VALUES
        (:P_RUN_ID, :P_VALIDATION_ID, :v_validation_name, :v_validation_type,
         :v_src_full, :v_tgt_full, :v_status,
         :v_total_rows::VARCHAR, :v_mismatch_cnt::VARCHAR, :v_mismatch_cnt,
         :v_threshold_pct, :v_mismatch_pct,
         :v_start_time, :v_end_time, :v_duration_sec,
         NULLIF(TRIM(REPLACE(:v_where_clause, 'WHERE ', '')), ''));

    -- Clean up temp table
    EXECUTE IMMEDIATE
        'DROP TABLE IF EXISTS VALIDATION_DB.STAGING.TMP_COL_RESOLVE_'
        || :P_VALIDATION_ID::VARCHAR;

    RETURN OBJECT_CONSTRUCT(
        'status',         :v_status,
        'mismatch_count', :v_mismatch_cnt,
        'mismatch_pct',   :v_mismatch_pct,
        'total_rows',     :v_total_rows,
        'error',          NULL
    );

EXCEPTION
    WHEN OTHER THEN
        v_end_time     := CURRENT_TIMESTAMP();
        v_duration_sec := DATEDIFF('millisecond', v_start_time, v_end_time) / 1000.0;

        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(
            :P_RUN_ID, :P_VALIDATION_ID, 'ERROR', 'DATA_VALIDATION',
            'Exception: ' || SQLERRM
        );

        INSERT INTO VALIDATION_DB.RESULTS.VALIDATION_DETAIL
            (RUN_ID, VALIDATION_ID, VALIDATION_TYPE, STATUS,
             ERROR_MESSAGE,
             EXECUTION_START_TIME, EXECUTION_END_TIME, EXECUTION_TIME_SECONDS)
        VALUES
            (:P_RUN_ID, :P_VALIDATION_ID, :v_validation_type, 'ERROR',
             :SQLERRM,
             :v_start_time, :v_end_time, :v_duration_sec);

        -- Best-effort cleanup
        EXECUTE IMMEDIATE
            'DROP TABLE IF EXISTS VALIDATION_DB.STAGING.TMP_COL_RESOLVE_'
            || :P_VALIDATION_ID::VARCHAR;

        RETURN OBJECT_CONSTRUCT(
            'status', 'ERROR',
            'error',  :SQLERRM
        );
END;
$$;
