# Snowflake Scripting Conversion — Change Notes

All stored procedures have been rewritten from **JavaScript** (`LANGUAGE JAVASCRIPT`)
to **Snowflake Scripting** (`LANGUAGE SQL`).  The DDL table definitions
(`01_ddl_setup.sql`) and task/config scripts (`05_tasks_sample_config_usage.sql`)
are unchanged.

---

## Files Changed

| File | Status |
|------|--------|
| `01_ddl_setup.sql` | **Unchanged** (pure DDL — no JS) |
| `02_sp_row_count_schema_validation.sql` | **Rewritten** |
| `03_sp_data_validation.sql` | **Rewritten** |
| `04_sp_master_orchestrator.sql` | **Rewritten** |
| `05_tasks_sample_config_usage.sql` | **Unchanged** (config inserts + CALL examples) |

---

## Key Conversion Decisions

### 1. `FN_GENERATE_UUID()` — JS `Math.random()` → `UUID_STRING()`
The original used a pure-JS UUID v4 generator.
Replaced with Snowflake's native `UUID_STRING()` built-in, which is
cryptographically stronger and guaranteed unique within a session.

```sql
-- Before (JavaScript UDF)
LANGUAGE JAVASCRIPT AS $$
    return ([1e7]+-1e3+…).replace(/[018]/g, …);
$$

-- After (SQL UDF)
LANGUAGE SQL AS $$ UUID_STRING() $$
```

---

### 2. `SP_LOG_MESSAGE` — JS `try/catch` + `snowflake.execute()` → SQL `DECLARE / BEGIN / EXCEPTION`
The level-filter comparison that used a JS dictionary (`levels = {DEBUG:0 …}`)
is now expressed as two `CASE` expressions over integer ranks.

```sql
v_msg_rank := CASE UPPER(P_LEVEL) WHEN 'DEBUG' THEN 0 … END;
v_cfg_rank := CASE UPPER(v_config_level) WHEN 'DEBUG' THEN 0 … END;
IF (v_msg_rank >= v_cfg_rank) THEN … END IF;
```

---

### 3. Dynamic SQL execution — `snowflake.execute({sqlText:…})` → `EXECUTE IMMEDIATE`
All dynamic queries (count SQL, column discovery, mismatch INSERT) use
`EXECUTE IMMEDIATE :v_sql_string`.

For queries that return a single scalar, the short form is used:
```sql
EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM …' INTO v_count;
```

For multi-row result sets, the pattern is:
```sql
v_res := (EXECUTE IMMEDIATE :v_sql);
LET c CURSOR FOR v_res;
OPEN c;
LOOP FETCH c INTO …; END LOOP;
CLOSE c;
```

---

### 4. `SP_VALIDATE_ROW_COUNT` — count via cursor
JavaScript iterated a `ResultSet`; Snowflake Scripting uses a typed `CURSOR`:

```sql
v_count_sql := 'SELECT COUNT(*) FROM ' || v_src_full || v_where_clause;
res         := (EXECUTE IMMEDIATE :v_count_sql);
LET cur CURSOR FOR res;
OPEN cur; FETCH cur INTO v_src_count; CLOSE cur;
```

---

### 5. `SP_VALIDATE_SCHEMA` — cursor loop replaces JS `while (rs.next())`
The JS `switch(mismatchType)` block became a SQL `CASE` statement inside
the cursor loop body.  Each non-MATCH row is INSERTed individually
(identical behaviour; same result table).

---

### 6. `SP_VALIDATE_DATA` — column list built via temp table + `LISTAGG`
The JS version built column arrays in memory by iterating `INFORMATION_SCHEMA`.
The SQL version materialises a temporary table
`VALIDATION_DB.STAGING.TMP_COL_RESOLVE_<id>` and uses `LISTAGG … WITHIN GROUP`
to produce the CSV column lists and concatenation expressions needed for
dynamic SQL.  The temp table is dropped at the end of the SP (or in the
`EXCEPTION` block).

This approach keeps all column logic inside the SQL engine and avoids
passing large strings through the procedure boundary.

---

### 7. `SP_VALIDATE_DATA_HASH` — extracted into its own SP
The JS inner function `_hashValidation(…)` cannot exist in SQL Scripting
(no nested function declarations).  It was promoted to a standalone SP
called `SP_VALIDATE_DATA_HASH` and invoked via `CALL … INTO v_result`
from `SP_VALIDATE_DATA`.

---

### 8. `SP_RUN_VALIDATION_FRAMEWORK` — retry loop uses `WHILE … DO`
The JS `while (attempt <= retries && !success)` becomes:

```sql
WHILE (v_attempt <= v_retry_count AND NOT v_success_flag) DO
    …
    IF (v_val_status IN ('PASS','FAIL')) THEN
        v_success_flag := TRUE;
    ELSE
        v_attempt := v_attempt + 1;
    END IF;
END WHILE;
```

Dynamic dispatch on `VALIDATION_TYPE` uses `IF / ELSEIF` chains with
`CALL … INTO v_val_result` instead of a JS `switch` + string-based SP call.

---

### 9. `SP_GET_RUN_SUMMARY` — returns `OBJECT` via cursor fetch
The JS version built a plain object from `getColumnValue` calls.
The SQL version fetches the aggregate query into typed variables and
assembles the return value with `OBJECT_CONSTRUCT(…)`.

---

### 10. `SP_PURGE_OLD_RESULTS` — `SQLROWCOUNT` for deleted-row counts
JS computed row counts via extra `SELECT COUNT(*)` queries.
SQL Scripting provides `SQLROWCOUNT` immediately after each `DELETE`.

---

## Error Handling Pattern
Every SP follows the same structure:

```sql
BEGIN
    …business logic…
EXCEPTION
    WHEN OTHER THEN
        -- Log the error
        CALL VALIDATION_DB.CONFIG.SP_LOG_MESSAGE(…, 'ERROR', …, SQLERRM);
        -- Insert an ERROR row into VALIDATION_DETAIL
        INSERT INTO … VALUES (…, 'ERROR', :SQLERRM, …);
        -- Return a structured error object
        RETURN OBJECT_CONSTRUCT('status','ERROR','error',:SQLERRM);
END;
```

`SQLERRM` is the Snowflake Scripting equivalent of JS `e.message`.

---

## Deployment Order (unchanged)

```
01_ddl_setup.sql
02_sp_row_count_schema_validation.sql
03_sp_data_validation.sql
04_sp_master_orchestrator.sql
05_tasks_sample_config_usage.sql
```
