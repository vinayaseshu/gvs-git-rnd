# Snowflake Data Extract Framework (Snowpark)

A reusable, config-driven data extract framework built with Snowpark Python.
Supports S3 delivery, full-featured SFTP transfer, complete audit logging,
and Snowflake Task scheduling — all driven from a single configuration table.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                      DATA EXTRACT FRAMEWORK                         │
│                                                                     │
│  ┌─────────────────┐   ┌──────────────────────────────────────┐    │
│  │  EXTRACT_CONFIG  │──▶│         DataExtractEngine (v2)       │    │
│  │  (config table)  │   │  ┌──────────────┐  ┌─────────────┐  │    │
│  └─────────────────┘   │  │S3ExportMgr   │  │SFTPTransfer │  │    │
│                         │  └──────────────┘  │  Manager    │  │    │
│  ┌─────────────────┐   │                     └─────────────┘  │    │
│  │ Snowflake Tasks  │──▶│              ┌──────────────────┐    │    │
│  │  (scheduler)     │   │              │   AuditManager   │    │    │
│  └─────────────────┘   │              └──────────────────┘    │    │
│                         └──────────────────────────────────────┘    │
│                                      │                              │
│  ┌───────────────────────────────────▼──────────────────────────┐   │
│  │        AUDIT.EXTRACT_AUDIT_LOG  +  SFTP_TRANSFER_LOG         │   │
│  └──────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
        │                        │                    │
        ▼                        ▼                    ▼
   Snowflake Tables          S3 Bucket          SFTP Server(s)
   (data source)            (file output)       (partner delivery)
```

---

## Files

| # | File | Description |
|---|------|-------------|
| 01 | `01_setup_config_tables.sql` | DDL for EXTRACT_CONFIG, EXTRACT_AUDIT_LOG, EXTRACT_AUDIT_SUMMARY + sample configs |
| 02 | `02_data_extract_framework.py` | Core utilities: AuditManager, S3ExportManager, resolve_file_name, build_source_query |
| 03 | `03_stored_procedures_and_tasks.sql` | Base stored procedures (S3-only) + Snowflake Task schedules |
| 04 | `04_deployment.sql` | End-to-end deployment guide: stages, secrets, roles, permissions |
| 05 | `05_sftp_extension_schema.sql` | Schema extensions for SFTP: new config columns, SFTP_TRANSFER_LOG, SFTP monitoring views |
| 06 | `06_sftp_transfer_manager.py` | Production SFTP module: auth, retry, checksums, PGP, flag files, multi-destination |
| 07 | `07_data_extract_engine_v2.py` | v2 engine: SFTP_ONLY mode, fan-out, retry tracking; stored procedure entry points |
| 08 | `08_sftp_stored_procedures.sql` | Stored procedure definitions referencing all three Python files + SFTP monitoring queries |

---

## Deployment Order

```
01_setup_config_tables.sql        -- Create tables
04_deployment.sql                 -- Configure stages, secrets, roles
  -> Upload Python files to CODE_STAGE (see below)
05_sftp_extension_schema.sql      -- Add SFTP columns & new tables  (skip if no SFTP)
08_sftp_stored_procedures.sql     -- Deploy v2 stored procedures     (replaces 03)
```

> If you do **not** need SFTP, run `03_stored_procedures_and_tasks.sql` instead of `08`.

---

## Quick Start

### 1. Deploy Tables
```sql
-- Execute in a Snowflake worksheet
-- 01_setup_config_tables.sql
```

### 2. Upload Python Files
```bash
# From SnowSQL CLI
snowsql -a your_account -u your_user
PUT file://02_data_extract_framework.py  @DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
PUT file://06_sftp_transfer_manager.py   @DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
PUT file://07_data_extract_engine_v2.py  @DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
LIST @DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE;
```

### 3. Deploy Stored Procedures
```sql
-- Execute 08_sftp_stored_procedures.sql  (SFTP-enabled)
-- or      03_stored_procedures_and_tasks.sql  (S3-only)
```

### 4. Add an Extract Config
```sql
INSERT INTO DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SCHEDULE_ENABLED, SCHEDULE_CRON
) VALUES (
    'MY_DAILY_EXTRACT', 'MY_DB', 'PUBLIC', 'MY_TABLE',
    'CSV', 'my_extract_{YYYYMMDD}.csv',
    TRUE, 'MY_S3_STAGE', 'extracts/daily/',
    TRUE, '0 6 * * *'
);
```

### 5. Run and Monitor
```sql
-- Preview SQL (no data moved)
CALL DATA_EXTRACT_DB.FRAMEWORK.DRY_RUN_EXTRACT('MY_DAILY_EXTRACT');

-- Execute
CALL DATA_EXTRACT_DB.FRAMEWORK.RUN_EXTRACT_BY_NAME('MY_DAILY_EXTRACT');

-- Check results
SELECT * FROM DATA_EXTRACT_DB.AUDIT.V_EXTRACT_RUN_HISTORY LIMIT 20;
```

---

## EXTRACT_CONFIG Key Fields

| Column | Description | Example |
|--------|-------------|---------|
| `CONFIG_NAME` | Unique job identifier | `DAILY_SALES_EXTRACT` |
| `SOURCE_DATABASE/SCHEMA/TABLE` | Source Snowflake object | `SALES_DB.PUBLIC.ORDERS` |
| `SOURCE_QUERY` | Custom SQL (overrides TABLE) | `SELECT a, b FROM t JOIN ...` |
| `FILTER_CONDITION` | WHERE clause appended | `STATUS = 'ACTIVE'` |
| `FILE_FORMAT` | Output format | `CSV`, `PARQUET`, `JSON` |
| `FILE_NAME_PATTERN` | Dynamic filename with tokens | `SALES_{YYYYMMDD}.csv.gz` |
| `COMPRESSION` | File compression | `GZIP`, `SNAPPY`, `NONE` |
| `S3_ENABLED` | Write to S3 stage | `TRUE` / `FALSE` |
| `S3_STAGE_NAME` | Snowflake external stage name | `MY_S3_STAGE` |
| `S3_PATH_PREFIX` | S3 folder path | `extracts/sales/` |
| `SFTP_ENABLED` | Push to SFTP after S3 export | `TRUE` / `FALSE` |
| `SFTP_ONLY` | Skip S3; write direct to SFTP | `TRUE` / `FALSE` |
| `SFTP_HOST` | SFTP server hostname | `sftp.partner.com` |
| `SFTP_SECRET_NAME` | Snowflake Secret for credentials | `SFTP_PARTNER_SECRET` |
| `SFTP_AUTH_TYPE` | Authentication method | `PASSWORD` / `KEY` |
| `SCHEDULE_CRON` | Cron expression (UTC) | `0 6 * * *` (6 AM daily) |
| `SCHEDULE_MINUTES` | Interval-based schedule | `60` (every hour) |

### File Name Pattern Tokens

| Token | Resolves To | Example |
|-------|-------------|---------|
| `{YYYYMMDD}` | Date | `20250120` |
| `{YYYYMMDD_HH24MISS}` | Full datetime | `20250120_063045` |
| `{YYYYMMDD_HH24}` | Date + hour | `20250120_06` |
| `{YYYY}` / `{MM}` / `{DD}` | Year / Month / Day | `2025` / `01` / `20` |
| `{HH24}` / `{MI}` / `{SS}` | Hour / Minute / Second | `06` / `30` / `00` |
| `{EPOCH}` | Unix timestamp | `1737356445` |

---

## SFTP Features

The SFTP layer (`06_sftp_transfer_manager.py`) supports:

- **Password and SSH key authentication** (RSA, Ed25519, ECDSA, DSS)
- **Atomic upload** — uploads as `.tmp` then renames to final name
- **Checksum sidecar files** — writes `.md5` / `.sha256` alongside data files
- **Flag / trigger files** — writes an empty `.done` file after successful upload
- **PGP encryption** — encrypts files before upload using a stored public key
- **Configurable retry** with exponential back-off
- **Multi-destination fan-out** — primary + secondary SFTP targets in one run
- **Remote directory cleanup** — purge files older than N days
- **SSH host key verification** (or bypass for dev environments)
- **Per-file audit rows** in `AUDIT.SFTP_TRANSFER_LOG`

### SFTP Setup

1. Create a Snowflake Secret with the SFTP password or private key:
   ```sql
   CREATE SECRET DATA_EXTRACT_DB.FRAMEWORK.SFTP_MY_PARTNER
       TYPE = GENERIC_STRING
       SECRET_STRING = 'your_sftp_password';
   ```

2. Configure the extract:
   ```sql
   UPDATE DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG
   SET SFTP_ENABLED    = TRUE,
       SFTP_HOST       = 'sftp.partner.com',
       SFTP_PORT       = 22,
       SFTP_USERNAME   = 'transfer_user',
       SFTP_SECRET_NAME= 'SFTP_MY_PARTNER',
       SFTP_REMOTE_PATH= '/inbound/data/'
   WHERE CONFIG_NAME = 'MY_EXTRACT';
   ```

3. Test connectivity before running:
   ```sql
   CALL DATA_EXTRACT_DB.FRAMEWORK.TEST_SFTP_CONNECTION('MY_EXTRACT');
   ```

---

## Scheduling

### Auto-Sync Tasks from Config Table
```sql
-- Creates or drops tasks automatically based on SCHEDULE_ENABLED in config
CALL DATA_EXTRACT_DB.FRAMEWORK.SYNC_EXTRACT_TASKS();
```

### Manual Task Control
```sql
ALTER TASK DATA_EXTRACT_DB.FRAMEWORK.TASK_DAILY_SALES_EXTRACT SUSPEND;
ALTER TASK DATA_EXTRACT_DB.FRAMEWORK.TASK_DAILY_SALES_EXTRACT RESUME;
SHOW TASKS IN SCHEMA DATA_EXTRACT_DB.FRAMEWORK;
```

---

## Monitoring

```sql
-- Latest run per job (status, rows, success rate)
SELECT CONFIG_NAME, LAST_STATUS, LAST_RUN_TIME, LAST_ROWS, SUCCESS_RATE_PCT
FROM DATA_EXTRACT_DB.AUDIT.V_EXTRACT_LAST_RUN;

-- Failed runs this week
SELECT CONFIG_NAME, START_TIME, ERROR_CODE, ERROR_MESSAGE
FROM DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_LOG
WHERE STATUS = 'FAILED'
  AND START_TIME >= DATEADD('day', -7, CURRENT_TIMESTAMP());

-- SFTP transfer history with throughput
SELECT * FROM DATA_EXTRACT_DB.AUDIT.V_SFTP_TRANSFER_HISTORY LIMIT 50;

-- Daily totals (rows, files, MB)
SELECT SUMMARY_DATE, CONFIG_NAME, TOTAL_RUNS, SUCCESSFUL_RUNS,
       ROUND(TOTAL_BYTES / 1024 / 1024, 1) AS TOTAL_MB
FROM DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_SUMMARY
ORDER BY SUMMARY_DATE DESC;
```

---

## Dependencies

| Package | Source | Used For |
|---------|--------|----------|
| `snowflake-snowpark-python` | Built-in | Snowflake session, SQL execution |
| `paramiko` | Snowflake Anaconda channel | SFTP connections |
| `pandas` | Snowflake Anaconda channel | SFTP_ONLY local file generation |
| `python-gnupg` | Snowflake Anaconda channel | PGP file encryption (optional) |

All packages are declared in the stored procedure `PACKAGES` clause — no manual installation needed.
