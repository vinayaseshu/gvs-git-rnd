-- =============================================================================
-- DATA EXTRACT FRAMEWORK - SFTP Extension Stored Procedures
-- =============================================================================
-- Run AFTER:  05_sftp_extension_schema.sql
-- Requires:   All three Python files uploaded to CODE_STAGE:
--
--   PUT file://02_data_extract_framework.py  @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
--   PUT file://06_sftp_transfer_manager.py   @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
--   PUT file://07_data_extract_engine_v2.py  @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
--
-- Verify uploads:
--   LIST @FRAMEWORK.CODE_STAGE;
-- =============================================================================

USE ROLE SYSADMIN;
USE DATABASE DATA_EXTRACT_DB;
USE WAREHOUSE COMPUTE_WH;

-- =============================================================================
-- 1. STORED PROCEDURES (v2 engine — replaces 03_stored_procedures_and_tasks.sql)
-- =============================================================================

CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_EXTRACT_BY_NAME(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER = 'data_extract_engine_v2.run_extract_by_name'
IMPORTS = (
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/sftp_transfer_manager.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine_v2.py'
)
COMMENT = 'Run a named extract job (v2: full SFTP support)'
;

CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_EXTRACT_BY_ID(CONFIG_ID NUMBER)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER = 'data_extract_engine_v2.run_extract_by_id'
IMPORTS = (
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/sftp_transfer_manager.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine_v2.py'
)
COMMENT = 'Run an extract job by config ID (v2: full SFTP support)'
;

CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_ALL_EXTRACTS()
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER = 'data_extract_engine_v2.run_all_extracts'
IMPORTS = (
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/sftp_transfer_manager.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine_v2.py'
)
COMMENT = 'Run all active extract jobs (v2: full SFTP support)'
;

CREATE OR REPLACE PROCEDURE FRAMEWORK.DRY_RUN_EXTRACT(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER = 'data_extract_engine_v2.dry_run_extract'
IMPORTS = (
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/sftp_transfer_manager.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine_v2.py'
)
COMMENT = 'Preview extract SQL without running'
;

CREATE OR REPLACE PROCEDURE FRAMEWORK.TEST_SFTP_CONNECTION(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko', 'pandas', 'python-gnupg')
HANDLER = 'data_extract_engine_v2.test_sftp_connection'
IMPORTS = (
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/sftp_transfer_manager.py',
    '@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_engine_v2.py'
)
COMMENT = 'Test SFTP connectivity for a config without transferring files'
;

-- =============================================================================
-- 2. SFTP MONITORING VIEWS (see also 05_sftp_extension_schema.sql)
-- =============================================================================

-- All SFTP transfers in the last 24 hours
SELECT
    CONFIG_NAME,
    SFTP_HOST,
    SFTP_REMOTE_PATH,
    STATUS,
    ATTEMPT_NUMBER,
    ROUND(LOCAL_FILE_SIZE_BYTES / 1024 / 1024, 2) AS FILE_MB,
    THROUGHPUT_MBPS,
    DURATION_MS,
    CHECKSUM_TYPE,
    CHECKSUM_VALUE,
    PGP_ENCRYPTED,
    FLAG_FILE_PATH,
    TRANSFER_START
FROM AUDIT.SFTP_TRANSFER_LOG
WHERE TRANSFER_START >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
ORDER BY TRANSFER_START DESC;

-- Failed SFTP transfers
SELECT * FROM AUDIT.V_SFTP_FAILED_TRANSFERS;

-- Throughput stats per host per day
SELECT * FROM AUDIT.V_SFTP_THROUGHPUT_STATS
ORDER BY TRANSFER_DATE DESC, CONFIG_NAME;

-- Full transfer history with source row counts
SELECT * FROM AUDIT.V_SFTP_TRANSFER_HISTORY
LIMIT 50;

-- Retry analysis (last 30 days)
SELECT
    CONFIG_NAME,
    SFTP_HOST,
    COUNT(DISTINCT RUN_ID)  AS RUNS_WITH_RETRIES,
    SUM(ATTEMPT_NUMBER - 1) AS TOTAL_RETRIES,
    AVG(ATTEMPT_NUMBER)     AS AVG_ATTEMPTS_PER_FILE
FROM AUDIT.SFTP_TRANSFER_LOG
WHERE ATTEMPT_NUMBER > 1
  AND TRANSFER_START >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY 1, 2
ORDER BY TOTAL_RETRIES DESC;

-- Checksum verification report
SELECT
    CONFIG_NAME,
    SFTP_HOST,
    SFTP_REMOTE_PATH,
    CHECKSUM_TYPE,
    CHECKSUM_VALUE,
    TRANSFER_START,
    STATUS
FROM AUDIT.SFTP_TRANSFER_LOG
WHERE CHECKSUM_VALUE IS NOT NULL
  AND STATUS = 'SUCCESS'
ORDER BY TRANSFER_START DESC;

-- Weekly bytes transferred per config
SELECT
    DATE_TRUNC('week', TRANSFER_START) AS WEEK,
    CONFIG_NAME,
    COUNT(*)                           AS FILES,
    ROUND(SUM(LOCAL_FILE_SIZE_BYTES) / 1024 / 1024 / 1024, 3) AS TOTAL_GB,
    AVG(THROUGHPUT_MBPS)               AS AVG_MBPS
FROM AUDIT.SFTP_TRANSFER_LOG
WHERE STATUS = 'SUCCESS'
GROUP BY 1, 2
ORDER BY WEEK DESC, TOTAL_GB DESC;
