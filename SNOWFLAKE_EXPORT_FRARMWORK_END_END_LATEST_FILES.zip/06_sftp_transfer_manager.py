"""
=============================================================================
DATA EXTRACT FRAMEWORK - SFTP Extension Module
=============================================================================
File: sftp_transfer_manager.py

Full production-grade SFTP transfer layer that extends the base framework.

Capabilities:
  - Password + SSH private key authentication
  - Atomic upload via .tmp rename
  - MD5 / SHA256 / SHA512 checksum sidecar files
  - .done / .trigger flag files
  - PGP encryption via gnupg before upload
  - Auto-create remote directory tree
  - Configurable retry with exponential back-off
  - SSH keep-alive to prevent idle disconnects
  - Host key verification (or bypass for dev)
  - Bandwidth-aware chunked transfers with throughput logging
  - Multi-destination fan-out (primary + secondary targets)
  - Remote directory cleanup (retention policy)
  - SFTP-only mode (no S3 intermediate stage required)
  - Per-file audit rows in SFTP_TRANSFER_LOG
  - Full integration with existing AuditManager

=============================================================================
"""

import io
import os
import time
import uuid
import json
import shutil
import hashlib
import tempfile
import traceback
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any, Tuple

import paramiko
from paramiko.ssh_exception import (
    AuthenticationException,
    BadHostKeyException,
    NoValidConnectionsError,
    SSHException,
)
from snowflake.snowpark import Session

# Import shared utilities from base module
from data_extract_framework import resolve_file_name

# ---------------------------------------------------------------------------
# Conditional PGP import (gnupg package, optional)
# ---------------------------------------------------------------------------
try:
    import gnupg
    _PGP_AVAILABLE = True
except ImportError:
    _PGP_AVAILABLE = False


# ---------------------------------------------------------------------------
# Table references
# ---------------------------------------------------------------------------
SFTP_TRANSFER_LOG = "DATA_EXTRACT_DB.AUDIT.SFTP_TRANSFER_LOG"
AUDIT_TABLE       = "DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_LOG"


# =============================================================================
# CHECKSUM HELPERS
# =============================================================================

def compute_checksum(file_path: str, algorithm: str = "MD5") -> str:
    """
    Compute a hex checksum of a local file.

    Args:
        file_path:  Absolute path to the local file.
        algorithm:  'MD5', 'SHA256', or 'SHA512'.

    Returns:
        Lowercase hex digest string.
    """
    algo_map = {
        "MD5":    hashlib.md5,
        "SHA256": hashlib.sha256,
        "SHA512": hashlib.sha512,
    }
    if algorithm.upper() not in algo_map:
        raise ValueError(f"Unsupported checksum algorithm: {algorithm}")

    h = algo_map[algorithm.upper()]()
    with open(file_path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def write_checksum_file(file_path: str, checksum: str, algorithm: str) -> str:
    """
    Write a checksum sidecar file alongside the data file.
    Format matches standard Linux md5sum / sha256sum output.

    Returns:
        Path of the written checksum file.
    """
    suffix_map = {"MD5": ".md5", "SHA256": ".sha256", "SHA512": ".sha512"}
    checksum_path = file_path + suffix_map.get(algorithm.upper(), ".checksum")
    file_name = os.path.basename(file_path)
    with open(checksum_path, "w") as fh:
        fh.write(f"{checksum}  {file_name}\n")
    return checksum_path


# =============================================================================
# PGP ENCRYPTION HELPER
# =============================================================================

def encrypt_file_pgp(
    input_path: str,
    pgp_public_key_armored: str,
    output_path: Optional[str] = None,
) -> str:
    """
    Encrypt a local file with a PGP public key.

    Args:
        input_path:            Path to plaintext file.
        pgp_public_key_armored: ASCII-armored PGP public key string.
        output_path:           Destination for encrypted file.
                               Defaults to input_path + '.pgp'.

    Returns:
        Path of the encrypted file.

    Raises:
        RuntimeError if gnupg is unavailable or encryption fails.
    """
    if not _PGP_AVAILABLE:
        raise RuntimeError(
            "gnupg Python package is not installed. "
            "Add 'python-gnupg' to your Snowpark packages list."
        )

    if output_path is None:
        output_path = input_path + ".pgp"

    gpg_home = tempfile.mkdtemp(prefix="gnupg_")
    try:
        gpg = gnupg.GPG(gnupghome=gpg_home)
        import_result = gpg.import_keys(pgp_public_key_armored)
        if not import_result.fingerprints:
            raise ValueError("Failed to import PGP public key — key may be malformed.")

        fingerprint = import_result.fingerprints[0]

        with open(input_path, "rb") as fh:
            encrypt_result = gpg.encrypt_file(
                fh,
                recipients=[fingerprint],
                output=output_path,
                always_trust=True,
            )

        if not encrypt_result.ok:
            raise RuntimeError(f"PGP encryption failed: {encrypt_result.status}")

        print(f"[PGP] Encrypted {input_path} -> {output_path}")
        return output_path

    finally:
        shutil.rmtree(gpg_home, ignore_errors=True)


# =============================================================================
# SFTP CONNECTION BUILDER
# =============================================================================

class SFTPConnection:
    """
    Wraps a single authenticated paramiko SFTP session with keep-alive,
    host-key verification, and a clean context-manager interface.

    Usage:
        with SFTPConnection(params) as sftp:
            sftp.client.put(local, remote)
    """

    def __init__(self, params: Dict[str, Any], credential: str):
        """
        Args:
            params:     Dict with keys: host, port, username, auth_type,
                        connect_timeout, banner_timeout, keep_alive_sec,
                        known_host_key, host_key_bypass.
            credential: Password string or PEM private key string.
        """
        self.params     = params
        self.credential = credential
        self._transport: Optional[paramiko.Transport]  = None
        self._sftp:      Optional[paramiko.SFTPClient] = None

    # ------------------------------------------------------------------
    def __enter__(self) -> "SFTPConnection":
        self._connect()
        return self

    def __exit__(self, *_):
        self._disconnect()

    # ------------------------------------------------------------------
    @property
    def client(self) -> paramiko.SFTPClient:
        if self._sftp is None:
            raise RuntimeError("SFTP connection is not open.")
        return self._sftp

    # ------------------------------------------------------------------
    def _connect(self):
        p = self.params
        host      = p["host"]
        port      = int(p.get("port", 22))
        username  = p["username"]
        auth_type = p.get("auth_type", "PASSWORD").upper()
        conn_to   = int(p.get("connect_timeout", 30))
        banner_to = int(p.get("banner_timeout", 15))
        ka_sec    = int(p.get("keep_alive_sec", 60))

        print(f"[SFTP] Connecting to {host}:{port} as '{username}' ({auth_type})")

        # ------ Build transport ------
        sock = paramiko.Transport((host, port))
        sock.set_keepalive(ka_sec)
        sock.banner_timeout = banner_to

        # Optional host-key verification
        host_key_policy = self._build_host_key_policy(p)

        # Start SSH negotiation
        sock.start_client(timeout=conn_to)

        # Verify server host key
        if not p.get("host_key_bypass", False):
            self._verify_host_key(sock, p.get("known_host_key"))

        # Authenticate
        if auth_type == "PASSWORD":
            sock.auth_password(username, self.credential)
        elif auth_type == "KEY":
            pkey = self._load_private_key(self.credential)
            sock.auth_publickey(username, pkey)
        else:
            raise ValueError(f"Unknown auth_type: {auth_type}")

        if not sock.is_authenticated():
            raise AuthenticationException(f"Authentication failed for {username}@{host}")

        self._transport = sock
        self._sftp      = paramiko.SFTPClient.from_transport(sock)
        print(f"[SFTP] Connected and authenticated: {host}:{port}")

    # ------------------------------------------------------------------
    def _disconnect(self):
        try:
            if self._sftp:
                self._sftp.close()
        except Exception:
            pass
        try:
            if self._transport:
                self._transport.close()
        except Exception:
            pass
        self._sftp      = None
        self._transport = None
        print("[SFTP] Connection closed.")

    # ------------------------------------------------------------------
    @staticmethod
    def _load_private_key(pem_string: str) -> paramiko.PKey:
        """
        Load a paramiko PKey from a PEM string.
        Tries RSA, then Ed25519, then ECDSA, then DSS.
        """
        key_classes = [
            paramiko.RSAKey,
            paramiko.Ed25519Key,
            paramiko.ECDSAKey,
            paramiko.DSSKey,
        ]
        buf = io.StringIO(pem_string)
        for klass in key_classes:
            buf.seek(0)
            try:
                return klass.from_private_key(buf)
            except Exception:
                continue
        raise ValueError("Could not load private key — unsupported format or wrong PEM.")

    # ------------------------------------------------------------------
    @staticmethod
    def _verify_host_key(transport: paramiko.Transport, expected_fingerprint: Optional[str]):
        """
        Verify the server's host key against a stored fingerprint.
        The fingerprint should be the SHA-256 base64 string as shown by
        'ssh-keygen -l -f /etc/ssh/ssh_host_rsa_key.pub'.
        """
        if not expected_fingerprint:
            # No fingerprint configured — log warning but continue
            print("[SFTP] WARNING: No known_host_key configured. Skipping host verification.")
            return

        server_key    = transport.get_remote_server_key()
        actual_fp     = paramiko.util.hexify(server_key.get_fingerprint()).lower()
        expected_norm = expected_fingerprint.lower().replace(":", "").replace(" ", "")

        if actual_fp != expected_norm:
            raise BadHostKeyException(
                hostname=transport.getpeername()[0],
                got_key=server_key,
                expected_key=server_key,  # Filled in for error message only
            )
        print(f"[SFTP] Host key verified: {actual_fp}")

    # ------------------------------------------------------------------
    @staticmethod
    def _build_host_key_policy(params: Dict[str, Any]):
        """Returns paramiko host key policy class (unused directly here, kept for SSH client use)."""
        if params.get("host_key_bypass", False):
            print("[SFTP] WARNING: host_key_bypass=TRUE — host key verification disabled.")
            return paramiko.AutoAddPolicy()
        return paramiko.RejectPolicy()


# =============================================================================
# REMOTE FILESYSTEM HELPERS
# =============================================================================

def sftp_makedirs(sftp: paramiko.SFTPClient, remote_path: str):
    """
    Recursively create remote directories (like `mkdir -p`).
    Silently skips directories that already exist.
    """
    parts = [p for p in remote_path.replace("\\", "/").split("/") if p]
    current = "/" if remote_path.startswith("/") else ""

    for part in parts:
        current = current.rstrip("/") + "/" + part
        try:
            sftp.stat(current)
        except FileNotFoundError:
            print(f"[SFTP] Creating remote directory: {current}")
            sftp.mkdir(current)


def sftp_list_old_files(
    sftp: paramiko.SFTPClient,
    remote_path: str,
    older_than_days: int,
) -> List[str]:
    """
    List files in remote_path whose modification time is older than
    `older_than_days` days.  Returns list of full remote paths.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=older_than_days)
    old_files = []
    try:
        for attr in sftp.listdir_attr(remote_path):
            if attr.st_mtime:
                mod_time = datetime.fromtimestamp(attr.st_mtime, tz=timezone.utc)
                if mod_time < cutoff:
                    old_files.append(f"{remote_path.rstrip('/')}/{attr.filename}")
    except FileNotFoundError:
        pass
    return old_files


def sftp_archive_file(
    sftp: paramiko.SFTPClient,
    remote_file: str,
    archive_path: str,
):
    """Move a remote file to an archive directory before overwriting."""
    sftp_makedirs(sftp, archive_path)
    file_name    = remote_file.split("/")[-1]
    archive_dest = f"{archive_path.rstrip('/')}/{file_name}"
    try:
        sftp.rename(remote_file, archive_dest)
        print(f"[SFTP] Archived {remote_file} -> {archive_dest}")
    except FileNotFoundError:
        pass  # File didn't exist; nothing to archive


# =============================================================================
# CHUNKED UPLOAD WITH PROGRESS / THROUGHPUT TRACKING
# =============================================================================

def sftp_put_chunked(
    sftp: paramiko.SFTPClient,
    local_path:  str,
    remote_path: str,
    chunk_size:  int = 32768 * 1024,  # default 32 MB
) -> Tuple[int, float]:
    """
    Upload a local file to a remote SFTP path in chunks, returning
    (bytes_transferred, throughput_mbps).

    Falls back to sftp.put() for small files (<= chunk_size).
    """
    file_size = os.path.getsize(local_path)

    start_ts = time.monotonic()

    if file_size <= chunk_size:
        sftp.put(local_path, remote_path)
    else:
        # Manual chunked write for large files
        with open(local_path, "rb") as local_fh:
            with sftp.open(remote_path, "wb") as remote_fh:
                remote_fh.set_pipelined(True)
                transferred = 0
                while True:
                    data = local_fh.read(chunk_size)
                    if not data:
                        break
                    remote_fh.write(data)
                    transferred += len(data)
                    pct = transferred * 100 / file_size
                    print(f"[SFTP] Upload progress: {transferred}/{file_size} bytes ({pct:.1f}%)")

    elapsed = max(time.monotonic() - start_ts, 0.001)
    throughput_mbps = (file_size / elapsed) / (1024 * 1024)
    print(f"[SFTP] Upload done: {file_size:,} bytes in {elapsed:.2f}s ({throughput_mbps:.2f} MB/s)")
    return file_size, throughput_mbps


# =============================================================================
# PRODUCTION SFTP TRANSFER MANAGER
# =============================================================================

class SFTPTransferManager:
    """
    Production-grade SFTP transfer manager.

    Replaces the original skeleton implementation with full support for:
      - Multiple auth types (password, SSH key)
      - Atomic upload (.tmp -> rename)
      - Checksum sidecar files
      - Flag / trigger files
      - PGP encryption
      - Retry with exponential back-off
      - Multi-destination fan-out
      - Remote retention cleanup
      - SFTP-only mode (no S3 dependency)
      - Per-file audit rows in SFTP_TRANSFER_LOG
    """

    def __init__(self, session: Session):
        self.session = session

    # ------------------------------------------------------------------
    # PUBLIC ENTRY POINTS
    # ------------------------------------------------------------------

    def transfer(
        self,
        config: Dict[str, Any],
        local_file_paths: List[str],
        run_id: str,
        audit_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Transfer all files to the primary SFTP destination, then fan-out
        to any secondary targets defined in SFTP_SECONDARY_TARGETS.

        Args:
            config:           Extract config dict from EXTRACT_CONFIG table.
            local_file_paths: List of fully-qualified local file paths.
            run_id:           Current run UUID (for audit).
            audit_id:         Row ID from EXTRACT_AUDIT_LOG (optional FK).

        Returns:
            {
              "primary":   [list of successful remote paths on primary],
              "secondary": {host: [remote paths], ...},
              "total_bytes": int,
              "all_success": bool,
            }
        """
        sftp_start = datetime.now(timezone.utc)
        config_name = config.get("CONFIG_NAME", "UNKNOWN")

        # Build primary connection params from config
        primary_params = self._build_conn_params_from_config(config)
        primary_cred   = self._get_secret(config["SFTP_SECRET_NAME"])

        # Fan-out: primary always runs; secondary is optional
        all_targets = [{"params": primary_params, "cred": primary_cred, "is_primary": True}]

        secondary_raw = config.get("SFTP_SECONDARY_TARGETS")
        if secondary_raw:
            targets_list = secondary_raw if isinstance(secondary_raw, list) else json.loads(str(secondary_raw))
            for tgt in targets_list:
                tgt_cred = self._get_secret(tgt["secret_name"])
                tgt_params = {
                    "host":              tgt["host"],
                    "port":              int(tgt.get("port", 22)),
                    "username":          tgt["username"],
                    "auth_type":         tgt.get("auth_type", "PASSWORD"),
                    "connect_timeout":   int(config.get("SFTP_CONNECT_TIMEOUT") or 30),
                    "banner_timeout":    int(config.get("SFTP_BANNER_TIMEOUT")  or 15),
                    "keep_alive_sec":    int(config.get("SFTP_KEEP_ALIVE_SEC")  or 60),
                    "known_host_key":    None,
                    "host_key_bypass":   bool(config.get("SFTP_HOST_KEY_BYPASS", False)),
                }
                all_targets.append({"params": tgt_params, "cred": tgt_cred, "is_primary": False, "raw": tgt})

        results = {"primary": [], "secondary": {}, "total_bytes": 0, "all_success": True}

        for target in all_targets:
            t_params  = target["params"]
            t_cred    = target["cred"]
            t_host    = t_params["host"]
            is_primary = target.get("is_primary", True)

            # Determine remote path for this target
            if is_primary:
                remote_base = config.get("SFTP_REMOTE_PATH", "/")
            else:
                remote_base = target["raw"].get("remote_path", "/")

            print(f"\n[SFTP] {'Primary' if is_primary else 'Secondary'} target: {t_host}:{remote_base}")

            uploaded_paths, bytes_sent, success = self._transfer_to_target(
                config       = config,
                local_paths  = local_file_paths,
                conn_params  = t_params,
                credential   = t_cred,
                remote_base  = remote_base,
                run_id       = run_id,
                audit_id     = audit_id,
                config_name  = config_name,
            )

            results["total_bytes"] += bytes_sent
            if not success:
                results["all_success"] = False

            if is_primary:
                results["primary"] = uploaded_paths
            else:
                results["secondary"][t_host] = uploaded_paths

        # Update EXTRACT_AUDIT_LOG with SFTP timing + bytes
        sftp_end = datetime.now(timezone.utc)
        sftp_dur = int((sftp_end - sftp_start).total_seconds())
        self._update_audit_sftp_metrics(run_id, sftp_start, sftp_end, sftp_dur, results["total_bytes"])

        return results

    # ------------------------------------------------------------------
    # INTERNAL: Transfer all files to one target
    # ------------------------------------------------------------------

    def _transfer_to_target(
        self,
        config:      Dict[str, Any],
        local_paths: List[str],
        conn_params: Dict[str, Any],
        credential:  str,
        remote_base: str,
        run_id:      str,
        audit_id:    Optional[int],
        config_name: str,
    ) -> Tuple[List[str], int, bool]:
        """
        Upload all local files to a single SFTP server.

        Returns:
            (uploaded_remote_paths, total_bytes_transferred, all_succeeded)
        """
        retry_max   = int(config.get("SFTP_RETRY_ATTEMPTS") or 3)
        retry_delay = int(config.get("SFTP_RETRY_DELAY_SEC") or 30)
        chunk_size  = int(config.get("SFTP_CHUNK_SIZE_KB") or 32768) * 1024

        temp_suffix    = config.get("SFTP_TEMP_SUFFIX")    or ".tmp"
        rename_on_done = bool(config.get("SFTP_RENAME_ON_COMPLETE", True))
        overwrite      = bool(config.get("SFTP_OVERWRITE_REMOTE", True))
        archive_path   = config.get("SFTP_REMOTE_ARCHIVE_PATH")

        checksum_en    = bool(config.get("SFTP_CHECKSUM_ENABLED", True))
        checksum_alg   = (config.get("SFTP_CHECKSUM_TYPE") or "MD5").upper()
        flag_en        = bool(config.get("SFTP_FLAG_FILE_ENABLED", False))
        flag_suffix    = config.get("SFTP_FLAG_FILE_SUFFIX") or ".done"
        pgp_en         = bool(config.get("SFTP_PGP_ENABLED", False))
        pgp_secret     = config.get("SFTP_PGP_KEY_SECRET")
        del_local      = bool(config.get("SFTP_DELETE_LOCAL_AFTER", True))
        retention_days = int(config.get("SFTP_REMOTE_RETENTION_DAYS") or 0)

        uploaded_paths = []
        total_bytes    = 0
        all_ok         = True

        with SFTPConnection(conn_params, credential) as conn:
            sftp = conn.client

            # Ensure remote base directory exists
            sftp_makedirs(sftp, remote_base)

            # Optionally purge old remote files before uploading
            if retention_days > 0:
                old_files = sftp_list_old_files(sftp, remote_base, retention_days)
                for old_f in old_files:
                    print(f"[SFTP] Purging old remote file: {old_f}")
                    try:
                        sftp.remove(old_f)
                    except Exception as purge_err:
                        print(f"[SFTP] WARNING: Could not purge {old_f}: {purge_err}")

            # Upload each file
            for local_path in local_paths:
                file_name   = os.path.basename(local_path)
                remote_final = f"{remote_base.rstrip('/')}/{file_name}"

                ok, bytes_sent = self._upload_one_file(
                    sftp             = sftp,
                    local_path       = local_path,
                    remote_final     = remote_final,
                    temp_suffix      = temp_suffix,
                    rename_on_done   = rename_on_done,
                    overwrite        = overwrite,
                    archive_path     = archive_path,
                    chunk_size       = chunk_size,
                    checksum_en      = checksum_en,
                    checksum_alg     = checksum_alg,
                    flag_en          = flag_en,
                    flag_suffix      = flag_suffix,
                    pgp_en           = pgp_en,
                    pgp_secret       = pgp_secret,
                    retry_max        = retry_max,
                    retry_delay      = retry_delay,
                    run_id           = run_id,
                    audit_id         = audit_id,
                    config_name      = config_name,
                    conn_params      = conn_params,
                )

                if ok:
                    uploaded_paths.append(remote_final)
                    total_bytes += bytes_sent
                else:
                    all_ok = False

                # Clean up local file after upload attempt
                if del_local and os.path.exists(local_path):
                    os.remove(local_path)
                    print(f"[SFTP] Deleted local temp file: {local_path}")

        return uploaded_paths, total_bytes, all_ok

    # ------------------------------------------------------------------
    # INTERNAL: Upload a single file with retry
    # ------------------------------------------------------------------

    def _upload_one_file(
        self,
        sftp:          paramiko.SFTPClient,
        local_path:    str,
        remote_final:  str,
        temp_suffix:   str,
        rename_on_done: bool,
        overwrite:     bool,
        archive_path:  Optional[str],
        chunk_size:    int,
        checksum_en:   bool,
        checksum_alg:  str,
        flag_en:       bool,
        flag_suffix:   str,
        pgp_en:        bool,
        pgp_secret:    Optional[str],
        retry_max:     int,
        retry_delay:   int,
        run_id:        str,
        audit_id:      Optional[int],
        config_name:   str,
        conn_params:   Dict[str, Any],
    ) -> Tuple[bool, int]:
        """
        Upload one file, with retry, checksum, flag file, PGP, atomic rename.

        Returns:
            (success: bool, bytes_transferred: int)
        """
        file_name     = os.path.basename(local_path)
        file_size     = os.path.getsize(local_path)
        remote_temp   = remote_final + temp_suffix if rename_on_done else remote_final

        # --- PGP encryption (encrypt the local file before upload) ---
        actual_local_path  = local_path
        pgp_encrypted_flag = False
        if pgp_en and pgp_secret:
            pgp_key = self._get_secret(pgp_secret)
            encrypted_path = local_path + ".pgp"
            actual_local_path  = encrypt_file_pgp(local_path, pgp_key, encrypted_path)
            remote_final       = remote_final + ".pgp"
            remote_temp        = remote_temp  + ".pgp"
            file_size          = os.path.getsize(actual_local_path)
            pgp_encrypted_flag = True

        # --- Compute checksum of the file to upload ---
        checksum_value     = None
        local_checksum_path = None
        if checksum_en:
            print(f"[SFTP] Computing {checksum_alg} checksum for {actual_local_path}")
            checksum_value      = compute_checksum(actual_local_path, checksum_alg)
            local_checksum_path = write_checksum_file(actual_local_path, checksum_value, checksum_alg)
            print(f"[SFTP] Checksum ({checksum_alg}): {checksum_value}")

        # --- Retry loop ---
        attempt       = 0
        last_error    = None
        bytes_sent    = 0
        throughput    = 0.0
        transfer_ok   = False

        while attempt < retry_max:
            attempt += 1
            transfer_start = datetime.now(timezone.utc)
            transfer_end   = None
            duration_ms    = None
            status         = "FAILED"

            print(f"[SFTP] Attempt {attempt}/{retry_max}: {actual_local_path} -> {remote_temp}")
            try:
                # Archive existing remote file if configured
                if archive_path and overwrite:
                    sftp_archive_file(sftp, remote_final, archive_path)

                # Remove existing file if overwrite=True (no archive)
                elif overwrite:
                    try:
                        sftp.remove(remote_final)
                    except FileNotFoundError:
                        pass

                # Upload data file
                bytes_sent, throughput = sftp_put_chunked(
                    sftp, actual_local_path, remote_temp, chunk_size
                )

                # Upload checksum sidecar file
                remote_checksum_path = None
                if checksum_en and local_checksum_path:
                    suffix_map = {"MD5": ".md5", "SHA256": ".sha256", "SHA512": ".sha512"}
                    remote_checksum_path = remote_final + suffix_map.get(checksum_alg, ".checksum")
                    remote_checksum_temp = remote_checksum_path + temp_suffix if rename_on_done else remote_checksum_path
                    sftp.put(local_checksum_path, remote_checksum_temp)
                    if rename_on_done:
                        try:
                            sftp.remove(remote_checksum_path)
                        except FileNotFoundError:
                            pass
                        sftp.rename(remote_checksum_temp, remote_checksum_path)

                # Atomic rename: .tmp -> final name
                if rename_on_done:
                    print(f"[SFTP] Renaming {remote_temp} -> {remote_final}")
                    try:
                        sftp.remove(remote_final)
                    except FileNotFoundError:
                        pass
                    sftp.rename(remote_temp, remote_final)

                # Write flag / trigger file
                remote_flag_path = None
                if flag_en:
                    remote_flag_path = remote_final + flag_suffix
                    with tempfile.NamedTemporaryFile(delete=False, suffix=flag_suffix) as tmp_flag:
                        tmp_flag_path = tmp_flag.name
                    try:
                        sftp.put(tmp_flag_path, remote_flag_path)
                        print(f"[SFTP] Flag file written: {remote_flag_path}")
                    finally:
                        os.unlink(tmp_flag_path)

                transfer_end = datetime.now(timezone.utc)
                duration_ms  = int((transfer_end - transfer_start).total_seconds() * 1000)
                status       = "SUCCESS"
                transfer_ok  = True

                # Log success to SFTP_TRANSFER_LOG
                self._log_transfer(
                    run_id            = run_id,
                    audit_id          = audit_id,
                    config_name       = config_name,
                    local_file_path   = local_path,
                    local_file_size   = file_size,
                    checksum_type     = checksum_alg if checksum_en else None,
                    checksum_value    = checksum_value,
                    conn_params       = conn_params,
                    remote_path       = remote_final,
                    remote_temp_path  = remote_temp if rename_on_done else None,
                    status            = status,
                    attempt           = attempt,
                    transfer_start    = transfer_start,
                    transfer_end      = transfer_end,
                    duration_ms       = duration_ms,
                    throughput_mbps   = throughput,
                    flag_file_path    = remote_flag_path,
                    checksum_file_path= remote_checksum_path,
                    pgp_encrypted     = pgp_encrypted_flag,
                    error_code        = None,
                    error_message     = None,
                )
                break  # success — exit retry loop

            except Exception as exc:
                last_error     = exc
                transfer_end   = datetime.now(timezone.utc)
                duration_ms    = int((transfer_end - transfer_start).total_seconds() * 1000)
                error_code     = type(exc).__name__
                error_msg      = str(exc)

                print(f"[SFTP] Attempt {attempt} FAILED: {error_code}: {error_msg}")

                # Log failed attempt
                self._log_transfer(
                    run_id            = run_id,
                    audit_id          = audit_id,
                    config_name       = config_name,
                    local_file_path   = local_path,
                    local_file_size   = file_size,
                    checksum_type     = checksum_alg if checksum_en else None,
                    checksum_value    = None,
                    conn_params       = conn_params,
                    remote_path       = remote_final,
                    remote_temp_path  = remote_temp,
                    status            = "RETRY" if attempt < retry_max else "FAILED",
                    attempt           = attempt,
                    transfer_start    = transfer_start,
                    transfer_end      = transfer_end,
                    duration_ms       = duration_ms,
                    throughput_mbps   = 0.0,
                    flag_file_path    = None,
                    checksum_file_path= None,
                    pgp_encrypted     = pgp_encrypted_flag,
                    error_code        = error_code,
                    error_message     = error_msg[:2000],
                )

                if attempt < retry_max:
                    # Exponential back-off: delay * 2^(attempt-1)
                    sleep_time = retry_delay * (2 ** (attempt - 1))
                    print(f"[SFTP] Retrying in {sleep_time}s...")
                    time.sleep(sleep_time)

        # Cleanup PGP-encrypted temp file
        if pgp_en and actual_local_path != local_path and os.path.exists(actual_local_path):
            os.remove(actual_local_path)

        # Cleanup checksum temp file
        if local_checksum_path and os.path.exists(local_checksum_path):
            os.remove(local_checksum_path)

        if not transfer_ok and last_error:
            raise last_error  # Propagate to engine for top-level audit

        return transfer_ok, bytes_sent

    # ------------------------------------------------------------------
    # SFTP-ONLY MODE: Generate file in /tmp directly from Snowflake query
    # ------------------------------------------------------------------

    def generate_file_locally(
        self,
        session:         Session,
        config:          Dict[str, Any],
        effective_query: str,
        run_dt:          datetime,
    ) -> List[str]:
        """
        For SFTP_ONLY=TRUE configs: write the data to /tmp as CSV
        using Snowpark's DataFrame.write.csv() (or pandas for small datasets).

        Returns:
            List of local file paths written.
        """
        import os
        from snowflake.snowpark.functions import col

        file_name  = resolve_file_name(config["FILE_NAME_PATTERN"], run_dt)
        local_dir  = "/tmp/sftp_direct/"
        os.makedirs(local_dir, exist_ok=True)
        local_path = os.path.join(local_dir, file_name)

        fmt        = config.get("FILE_FORMAT", "CSV").upper()
        delimiter  = config.get("DELIMITER", ",")
        compression = config.get("COMPRESSION", "NONE").upper()

        print(f"[SFTP-ONLY] Writing data to local file: {local_path}")

        df = session.sql(effective_query)

        if fmt == "CSV":
            # Use Snowpark write to local temp stage then GET
            # (Snowpark in stored proc context can write to /tmp directly via pandas)
            pandas_df = df.to_pandas()
            pandas_df.to_csv(
                local_path,
                sep        = delimiter,
                index      = False,
                header     = bool(config.get("INCLUDE_HEADER", True)),
                na_rep     = config.get("NULL_VALUE", ""),
                compression= compression.lower() if compression != "NONE" else None,
            )
        elif fmt == "PARQUET":
            pandas_df = df.to_pandas()
            pandas_df.to_parquet(local_path, index=False)
        elif fmt == "JSON":
            pandas_df = df.to_pandas()
            pandas_df.to_json(local_path, orient="records", lines=True)
        else:
            raise ValueError(f"Unsupported FILE_FORMAT for SFTP-ONLY mode: {fmt}")

        row_count = len(pandas_df)
        file_size = os.path.getsize(local_path)
        print(f"[SFTP-ONLY] File written: {row_count} rows, {file_size:,} bytes -> {local_path}")
        return [local_path], row_count, file_size

    # ------------------------------------------------------------------
    # INTERNAL: Credential retrieval
    # ------------------------------------------------------------------

    def _get_secret(self, secret_name: str) -> str:
        """Retrieve a credential from a Snowflake Secret."""
        result = self.session.sql(
            f"SELECT SYSTEM$GET_SECRET_STRING('{secret_name}') AS S"
        ).collect()
        val = result[0]["S"]
        if val is None:
            raise ValueError(f"Secret '{secret_name}' returned NULL. Check secret name and permissions.")
        return val

    # ------------------------------------------------------------------
    # INTERNAL: Build connection params dict from EXTRACT_CONFIG columns
    # ------------------------------------------------------------------

    @staticmethod
    def _build_conn_params_from_config(config: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "host":            config["SFTP_HOST"],
            "port":            int(config.get("SFTP_PORT") or 22),
            "username":        config["SFTP_USERNAME"],
            "auth_type":       (config.get("SFTP_AUTH_TYPE") or "PASSWORD").upper(),
            "connect_timeout": int(config.get("SFTP_CONNECT_TIMEOUT") or 30),
            "banner_timeout":  int(config.get("SFTP_BANNER_TIMEOUT")  or 15),
            "keep_alive_sec":  int(config.get("SFTP_KEEP_ALIVE_SEC")  or 60),
            "known_host_key":  config.get("SFTP_KNOWN_HOST_KEY"),
            "host_key_bypass": bool(config.get("SFTP_HOST_KEY_BYPASS", False)),
        }

    # ------------------------------------------------------------------
    # INTERNAL: Insert row into SFTP_TRANSFER_LOG
    # ------------------------------------------------------------------

    def _log_transfer(
        self,
        run_id:             str,
        audit_id:           Optional[int],
        config_name:        str,
        local_file_path:    str,
        local_file_size:    int,
        checksum_type:      Optional[str],
        checksum_value:     Optional[str],
        conn_params:        Dict[str, Any],
        remote_path:        str,
        remote_temp_path:   Optional[str],
        status:             str,
        attempt:            int,
        transfer_start:     datetime,
        transfer_end:       Optional[datetime],
        duration_ms:        Optional[int],
        throughput_mbps:    float,
        flag_file_path:     Optional[str],
        checksum_file_path: Optional[str],
        pgp_encrypted:      bool,
        error_code:         Optional[str],
        error_message:      Optional[str],
    ):
        """Insert one row into AUDIT.SFTP_TRANSFER_LOG."""

        def q(v):
            """Escape and quote a string, or return NULL."""
            if v is None:
                return "NULL"
            return "'" + str(v).replace("'", "''") + "'"

        def ts(v):
            if v is None:
                return "NULL"
            return f"'{v.strftime('%Y-%m-%d %H:%M:%S.%f')}'"

        sql = f"""
            INSERT INTO {SFTP_TRANSFER_LOG} (
                AUDIT_ID, RUN_ID, CONFIG_NAME,
                LOCAL_FILE_PATH, LOCAL_FILE_SIZE_BYTES,
                CHECKSUM_TYPE, CHECKSUM_VALUE,
                SFTP_HOST, SFTP_PORT, SFTP_USERNAME,
                SFTP_REMOTE_PATH, SFTP_TEMP_PATH,
                STATUS, ATTEMPT_NUMBER,
                TRANSFER_START, TRANSFER_END,
                DURATION_MS, THROUGHPUT_MBPS,
                FLAG_FILE_PATH, CHECKSUM_FILE_PATH,
                PGP_ENCRYPTED,
                ERROR_CODE, ERROR_MESSAGE
            ) VALUES (
                {audit_id if audit_id else 'NULL'},
                {q(run_id)},
                {q(config_name)},
                {q(local_file_path)},
                {local_file_size},
                {q(checksum_type)},
                {q(checksum_value)},
                {q(conn_params['host'])},
                {conn_params.get('port', 22)},
                {q(conn_params.get('username'))},
                {q(remote_path)},
                {q(remote_temp_path)},
                {q(status)},
                {attempt},
                {ts(transfer_start)},
                {ts(transfer_end)},
                {duration_ms if duration_ms is not None else 'NULL'},
                {throughput_mbps:.4f},
                {q(flag_file_path)},
                {q(checksum_file_path)},
                {'TRUE' if pgp_encrypted else 'FALSE'},
                {q(error_code)},
                {q(error_message)}
            )
        """
        try:
            self.session.sql(sql).collect()
        except Exception as log_err:
            # Never let audit logging break the transfer pipeline
            print(f"[AUDIT-SFTP] WARNING: Failed to log transfer row: {log_err}")

    # ------------------------------------------------------------------
    # INTERNAL: Update EXTRACT_AUDIT_LOG with SFTP timing columns
    # ------------------------------------------------------------------

    def _update_audit_sftp_metrics(
        self,
        run_id:         str,
        sftp_start:     datetime,
        sftp_end:       datetime,
        duration_sec:   int,
        bytes_xferred:  int,
    ):
        sql = f"""
            UPDATE {AUDIT_TABLE}
            SET
                SFTP_TRANSFER_START_TIME   = '{sftp_start.strftime('%Y-%m-%d %H:%M:%S.%f')}',
                SFTP_TRANSFER_END_TIME     = '{sftp_end.strftime('%Y-%m-%d %H:%M:%S.%f')}',
                SFTP_TRANSFER_DURATION_SEC = {duration_sec},
                SFTP_BYTES_TRANSFERRED     = {bytes_xferred}
            WHERE RUN_ID = '{run_id}'
        """
        try:
            self.session.sql(sql).collect()
        except Exception as e:
            print(f"[AUDIT-SFTP] WARNING: Could not update SFTP metrics on audit log: {e}")


