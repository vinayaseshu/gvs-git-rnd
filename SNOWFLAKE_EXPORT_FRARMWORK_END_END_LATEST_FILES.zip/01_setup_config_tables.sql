-- =============================================================================
-- DATA EXTRACT FRAMEWORK - Configuration & Audit Tables Setup
-- =============================================================================

USE ROLE SYSADMIN;
USE WAREHOUSE COMPUTE_WH;

-- Create dedicated database and schema
CREATE DATABASE IF NOT EXISTS DATA_EXTRACT_DB;
CREATE SCHEMA IF NOT EXISTS DATA_EXTRACT_DB.FRAMEWORK;
CREATE SCHEMA IF NOT EXISTS DATA_EXTRACT_DB.AUDIT;

USE DATABASE DATA_EXTRACT_DB;
USE SCHEMA FRAMEWORK;

-- =============================================================================
-- 1. EXTRACT CONFIG TABLE
-- =============================================================================
CREATE OR REPLACE TABLE FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_ID           NUMBER AUTOINCREMENT PRIMARY KEY,
    CONFIG_NAME         VARCHAR(200)    NOT NULL UNIQUE,          -- Unique extract job name
    IS_ACTIVE           BOOLEAN         DEFAULT TRUE,             -- Enable/disable job
    
    -- Source Configuration
    SOURCE_DATABASE     VARCHAR(200)    NOT NULL,
    SOURCE_SCHEMA       VARCHAR(200)    NOT NULL,
    SOURCE_TABLE        VARCHAR(200),                             -- Table/View name (optional if SQL used)
    SOURCE_QUERY        TEXT,                                     -- Custom SQL query (overrides table)
    FILTER_CONDITION    TEXT,                                     -- Optional WHERE clause
    ORDER_BY_COLUMN     VARCHAR(500),                             -- Optional ORDER BY
    
    -- File Output Configuration
    FILE_FORMAT         VARCHAR(20)     DEFAULT 'CSV'             -- CSV, PARQUET, JSON
                        CHECK (FILE_FORMAT IN ('CSV','PARQUET','JSON')),
    DELIMITER           VARCHAR(5)      DEFAULT ',',
    INCLUDE_HEADER      BOOLEAN         DEFAULT TRUE,
    NULL_VALUE          VARCHAR(20)     DEFAULT '',
    COMPRESSION         VARCHAR(20)     DEFAULT 'NONE'
                        CHECK (COMPRESSION IN ('NONE','GZIP','BZ2','ZSTD','AUTO')),
    DATE_FORMAT         VARCHAR(50)     DEFAULT 'YYYY-MM-DD',
    TIMESTAMP_FORMAT    VARCHAR(50)     DEFAULT 'YYYY-MM-DD HH24:MI:SS',
    FILE_NAME_PATTERN   VARCHAR(500)    NOT NULL,                 -- e.g. SALES_DATA_{YYYYMMDD}.csv
    SPLIT_BY_ROWS       NUMBER          DEFAULT 0,                -- 0 = no split, >0 = rows per file
    
    -- S3 Configuration
    S3_ENABLED          BOOLEAN         DEFAULT TRUE,
    S3_STAGE_NAME       VARCHAR(200),                             -- Snowflake stage name
    S3_PATH_PREFIX      VARCHAR(500),                             -- Folder path within stage
    
    -- SFTP Configuration
    SFTP_ENABLED        BOOLEAN         DEFAULT FALSE,
    SFTP_HOST           VARCHAR(500),
    SFTP_PORT           NUMBER          DEFAULT 22,
    SFTP_USERNAME       VARCHAR(200),
    SFTP_SECRET_NAME    VARCHAR(200),                             -- Snowflake secret for password/key
    SFTP_REMOTE_PATH    VARCHAR(500)    DEFAULT '/',
    SFTP_AUTH_TYPE      VARCHAR(20)     DEFAULT 'PASSWORD'
                        CHECK (SFTP_AUTH_TYPE IN ('PASSWORD','KEY')),
    
    -- Schedule Configuration
    SCHEDULE_ENABLED    BOOLEAN         DEFAULT FALSE,
    SCHEDULE_CRON       VARCHAR(100),                             -- Cron expression (used in Snowflake task)
    SCHEDULE_MINUTES    NUMBER,                                   -- OR run every N minutes
    SCHEDULE_WAREHOUSE  VARCHAR(200),                             -- Warehouse for scheduled runs
    
    -- Notification
    NOTIFY_ON_SUCCESS   BOOLEAN         DEFAULT FALSE,
    NOTIFY_ON_FAILURE   BOOLEAN         DEFAULT TRUE,
    NOTIFICATION_EMAIL  VARCHAR(500),
    
    -- Metadata
    CREATED_BY          VARCHAR(200)    DEFAULT CURRENT_USER(),
    CREATED_AT          TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP(),
    UPDATED_BY          VARCHAR(200),
    UPDATED_AT          TIMESTAMP_NTZ,
    NOTES               TEXT
);

COMMENT ON TABLE FRAMEWORK.EXTRACT_CONFIG IS 'Master configuration table for all data extract jobs';

-- =============================================================================
-- 2. AUDIT LOG TABLE
-- =============================================================================
CREATE OR REPLACE TABLE AUDIT.EXTRACT_AUDIT_LOG (
    AUDIT_ID            NUMBER AUTOINCREMENT PRIMARY KEY,
    CONFIG_ID           NUMBER          NOT NULL,
    CONFIG_NAME         VARCHAR(200)    NOT NULL,
    RUN_ID              VARCHAR(100)    NOT NULL,                 -- UUID for each run
    
    -- Execution Details
    STATUS              VARCHAR(20)     NOT NULL                  -- RUNNING, SUCCESS, FAILED, SKIPPED
                        CHECK (STATUS IN ('RUNNING','SUCCESS','FAILED','SKIPPED')),
    START_TIME          TIMESTAMP_NTZ   NOT NULL,
    END_TIME            TIMESTAMP_NTZ,
    DURATION_SECONDS    NUMBER,
    
    -- Data Metrics
    ROWS_EXTRACTED      NUMBER          DEFAULT 0,
    FILES_GENERATED     NUMBER          DEFAULT 0,
    BYTES_WRITTEN       NUMBER          DEFAULT 0,
    
    -- Output Details
    S3_FILES_UPLOADED   VARIANT,                                  -- Array of uploaded S3 file paths
    SFTP_FILES_UPLOADED VARIANT,                                  -- Array of uploaded SFTP file paths
    
    -- Error Details
    ERROR_CODE          VARCHAR(50),
    ERROR_MESSAGE       TEXT,
    STACK_TRACE         TEXT,
    
    -- Execution Context
    EXECUTED_BY         VARCHAR(200)    DEFAULT CURRENT_USER(),
    QUERY_ID            VARCHAR(200),                             -- Snowflake query ID
    WAREHOUSE_NAME      VARCHAR(200),
    
    -- Source Query Snapshot
    EFFECTIVE_QUERY     TEXT,                                     -- Actual SQL that ran
    
    CONSTRAINT FK_AUDIT_CONFIG FOREIGN KEY (CONFIG_ID) 
        REFERENCES FRAMEWORK.EXTRACT_CONFIG(CONFIG_ID)
);

COMMENT ON TABLE AUDIT.EXTRACT_AUDIT_LOG IS 'Audit trail for all extract job executions';

-- Index for common query patterns
CREATE OR REPLACE INDEX IDX_AUDIT_CONFIG_ID ON AUDIT.EXTRACT_AUDIT_LOG (CONFIG_ID);
CREATE OR REPLACE INDEX IDX_AUDIT_STATUS    ON AUDIT.EXTRACT_AUDIT_LOG (STATUS);
CREATE OR REPLACE INDEX IDX_AUDIT_START_TIME ON AUDIT.EXTRACT_AUDIT_LOG (START_TIME);

-- =============================================================================
-- 3. AUDIT SUMMARY TABLE (for dashboarding)
-- =============================================================================
CREATE OR REPLACE TABLE AUDIT.EXTRACT_AUDIT_SUMMARY (
    SUMMARY_DATE        DATE            NOT NULL,
    CONFIG_ID           NUMBER          NOT NULL,
    CONFIG_NAME         VARCHAR(200)    NOT NULL,
    TOTAL_RUNS          NUMBER          DEFAULT 0,
    SUCCESSFUL_RUNS     NUMBER          DEFAULT 0,
    FAILED_RUNS         NUMBER          DEFAULT 0,
    AVG_DURATION_SEC    NUMBER,
    TOTAL_ROWS          NUMBER          DEFAULT 0,
    TOTAL_FILES         NUMBER          DEFAULT 0,
    TOTAL_BYTES         NUMBER          DEFAULT 0,
    LAST_RUN_STATUS     VARCHAR(20),
    LAST_RUN_TIME       TIMESTAMP_NTZ,
    PRIMARY KEY (SUMMARY_DATE, CONFIG_ID)
);

-- =============================================================================
-- 4. SAMPLE CONFIG INSERTS
-- =============================================================================

-- Example 1: Simple CSV extract to S3 daily
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, DELIMITER, INCLUDE_HEADER,
    COMPRESSION, S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE,
    NOTES
) VALUES (
    'DAILY_SALES_EXTRACT',
    'SALES_DB', 'PUBLIC', 'DAILY_SALES_VW',
    'CSV', 'DAILY_SALES_{YYYYMMDD}.csv', ',', TRUE,
    'GZIP', TRUE, 'MY_S3_STAGE', 'extracts/sales/daily/',
    TRUE, '0 6 * * *', 'COMPUTE_WH',
    'Daily sales extract - runs at 6AM UTC'
);

-- Example 2: Custom query with SFTP delivery
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA,
    SOURCE_QUERY, FILTER_CONDITION,
    FILE_FORMAT, FILE_NAME_PATTERN, DELIMITER, INCLUDE_HEADER,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SFTP_ENABLED, SFTP_HOST, SFTP_PORT, SFTP_USERNAME, 
    SFTP_SECRET_NAME, SFTP_REMOTE_PATH, SFTP_AUTH_TYPE,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE,
    NOTES
) VALUES (
    'CUSTOMER_SFTP_EXPORT',
    'CRM_DB', 'PUBLIC',
    'SELECT c.CUSTOMER_ID, c.FIRST_NAME, c.LAST_NAME, c.EMAIL, o.ORDER_COUNT, o.TOTAL_SPEND FROM CUSTOMERS c JOIN ORDER_SUMMARY o ON c.CUSTOMER_ID = o.CUSTOMER_ID',
    'c.IS_ACTIVE = TRUE',
    'CSV', 'CUSTOMERS_{YYYYMMDD_HH24MISS}.csv.gz', '|', TRUE,
    TRUE, 'MY_S3_STAGE', 'extracts/customers/',
    TRUE, 'sftp.partner.com', 22, 'data_transfer',
    'SFTP_PARTNER_SECRET', '/inbound/customers/', 'PASSWORD',
    TRUE, '0 8 * * 1', 'COMPUTE_WH',
    'Weekly customer file to partner SFTP - every Monday 8AM'
);

-- Example 3: Parquet export, no SFTP
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, COMPRESSION,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SCHEDULE_ENABLED, SCHEDULE_MINUTES, SCHEDULE_WAREHOUSE,
    NOTES
) VALUES (
    'EVENTS_PARQUET_HOURLY',
    'ANALYTICS_DB', 'RAW', 'EVENTS',
    'PARQUET', 'events_{YYYYMMDD_HH24}.parquet', 'SNAPPY',
    TRUE, 'MY_S3_STAGE', 'extracts/events/parquet/',
    TRUE, 60, 'COMPUTE_WH',
    'Hourly events export in Parquet format'
);
