"""
=============================================================================
DATA EXTRACT FRAMEWORK - Orchestration Engine v2
=============================================================================
File: data_extract_engine_v2.py

Replaces the base DataExtractEngine from data_extract_framework.py with
full SFTP support:
  - SFTP_ONLY mode (bypass S3; write directly to /tmp then push via SFTP)
  - Multi-destination fan-out (primary + secondary SFTP targets)
  - Per-file audit rows written to SFTP_TRANSFER_LOG
  - Retry count reflected back to EXTRACT_AUDIT_LOG
  - TEST_SFTP_CONNECTION stored procedure utility

Upload all three files to CODE_STAGE before deploying stored procedures
(see 08_sftp_stored_procedures.sql):
  PUT file://02_data_extract_framework.py  @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
  PUT file://06_sftp_transfer_manager.py   @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
  PUT file://07_data_extract_engine_v2.py  @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
=============================================================================
"""

import json
import traceback
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

from snowflake.snowpark import Session

from data_extract_framework import (
    AuditManager,
    S3ExportManager,
    build_source_query,
    CONFIG_TABLE,
    AUDIT_TABLE,
    STATUS_SUCCESS,
    STATUS_FAILED,
)
from sftp_transfer_manager import SFTPTransferManager, SFTPConnection


# =============================================================================
# EXTRACT ENGINE v2
# =============================================================================

class DataExtractEngine:
    """
    Orchestrates the full extract pipeline with v2 SFTP support:
      EXTRACT_CONFIG  ->  Query  ->  [S3 Export]  ->  [SFTP Transfer]  ->  Audit
    """

    def __init__(self, session: Session):
        self.session      = session
        self.audit        = AuditManager(session)
        self.s3_manager   = S3ExportManager(session)
        self.sftp_manager = SFTPTransferManager(session)

    # ------------------------------------------------------------------
    def run(
        self,
        config_name: Optional[str] = None,
        config_id:   Optional[int] = None,
        run_all:     bool          = False,
        dry_run:     bool          = False,
    ) -> List[Dict[str, Any]]:
        """
        Execute one or more extract jobs.

        Args:
            config_name: Run a specific job by name.
            config_id:   Run a specific job by numeric ID.
            run_all:     Run ALL active extract jobs.
            dry_run:     Preview SQL without executing transfers.

        Returns:
            List of result dicts, one per job.
        """
        if not (config_name or config_id or run_all):
            raise ValueError("Specify config_name, config_id, or set run_all=True")

        configs = self._load_config(config_name, config_id)
        results = []
        for config in configs:
            result = self._run_single(config, dry_run=dry_run)
            results.append(result)
        return results

    # ------------------------------------------------------------------
    def _load_config(self, config_name=None, config_id=None) -> List[Dict]:
        """Load one or all active configs from EXTRACT_CONFIG."""
        where = "IS_ACTIVE = TRUE"
        if config_name:
            where += f" AND CONFIG_NAME = '{config_name}'"
        if config_id:
            where += f" AND CONFIG_ID = {config_id}"

        rows = self.session.sql(
            f"SELECT * FROM {CONFIG_TABLE} WHERE {where} ORDER BY CONFIG_ID"
        ).collect()

        if not rows:
            raise ValueError(f"No active config found: name={config_name}, id={config_id}")
        return [r.as_dict() for r in rows]

    # ------------------------------------------------------------------
    def _run_single(self, config: Dict[str, Any], dry_run: bool = False) -> Dict[str, Any]:
        """Execute a single extract job end-to-end."""
        config_id   = config["CONFIG_ID"]
        config_name = config["CONFIG_NAME"]
        run_dt      = datetime.now(timezone.utc)
        sftp_only   = bool(config.get("SFTP_ONLY", False))

        print(f"\n{'='*60}")
        print(f"[EXTRACT] Starting : {config_name} (ID={config_id})")
        print(f"[EXTRACT] Run DT   : {run_dt.isoformat()}")
        print(f"[EXTRACT] SFTP Only: {sftp_only}")

        effective_query = build_source_query(config)

        if dry_run:
            print(f"[DRY RUN] Query:\n{effective_query}")
            return {
                "config_name": config_name,
                "status":      "DRY_RUN",
                "query":       effective_query,
                "sftp_only":   sftp_only,
            }

        run_id = self.audit.start_run(config_id, config_name, effective_query)

        # Retrieve audit_id for FK in SFTP_TRANSFER_LOG
        audit_id_rows = self.session.sql(
            f"SELECT AUDIT_ID FROM {AUDIT_TABLE} WHERE RUN_ID = '{run_id}'"
        ).collect()
        audit_id = audit_id_rows[0]["AUDIT_ID"] if audit_id_rows else None

        s3_files        = []
        sftp_result     = {"primary": [], "secondary": {}, "total_bytes": 0, "all_success": True}
        rows_extracted  = 0
        files_generated = 0
        bytes_written   = 0
        local_files     = []

        try:
            # ==============================================================
            # PATH A: SFTP_ONLY — write directly to /tmp, skip S3 stage
            # ==============================================================
            if sftp_only:
                print("[ENGINE] SFTP_ONLY mode: writing data directly to local temp file")
                local_files, rows_extracted, bytes_written = (
                    self.sftp_manager.generate_file_locally(
                        self.session, config, effective_query, run_dt
                    )
                )
                files_generated = len(local_files)

                if config.get("SFTP_ENABLED", True):
                    sftp_result = self.sftp_manager.transfer(
                        config           = config,
                        local_file_paths = local_files,
                        run_id           = run_id,
                        audit_id         = audit_id,
                    )
                else:
                    print("[ENGINE] SFTP_ONLY=TRUE but SFTP_ENABLED=FALSE — files left in /tmp")

            # ==============================================================
            # PATH B: Normal — S3 export first, then optional SFTP
            # ==============================================================
            else:
                if config.get("S3_ENABLED", True):
                    s3_result       = self.s3_manager.export(config, effective_query, run_dt)
                    rows_extracted  = s3_result["rows_written"]
                    files_generated = s3_result["files_generated"]
                    bytes_written   = s3_result["bytes_written"]
                    s3_files        = s3_result["file_paths"]
                else:
                    print("[S3] Skipped (S3_ENABLED=FALSE)")

                if config.get("SFTP_ENABLED", False):
                    if s3_files:
                        local_files = self._stage_files_to_local(config, s3_files)
                        sftp_result = self.sftp_manager.transfer(
                            config           = config,
                            local_file_paths = local_files,
                            run_id           = run_id,
                            audit_id         = audit_id,
                        )
                    else:
                        print("[SFTP] No S3 files to transfer")
                else:
                    print("[SFTP] Skipped (SFTP_ENABLED=FALSE)")

            # Update retry count on main audit log
            self._update_retry_count(run_id)

            # Flatten all SFTP paths across primary and secondary targets
            all_sftp_paths = list(sftp_result.get("primary", []))
            for paths in sftp_result.get("secondary", {}).values():
                all_sftp_paths.extend(paths)

            self.audit.end_run_success(
                run_id, rows_extracted, files_generated,
                bytes_written, s3_files, all_sftp_paths
            )
            self.audit.refresh_summary(config_id, config_name)

            return {
                "config_name":      config_name,
                "run_id":           run_id,
                "status":           STATUS_SUCCESS,
                "sftp_only":        sftp_only,
                "rows_extracted":   rows_extracted,
                "files_generated":  files_generated,
                "bytes_written":    bytes_written,
                "s3_files":         s3_files,
                "sftp_primary":     sftp_result.get("primary", []),
                "sftp_secondary":   sftp_result.get("secondary", {}),
                "sftp_all_success": sftp_result.get("all_success", True),
            }

        except Exception as exc:
            self.audit.end_run_failed(
                run_id, type(exc).__name__, str(exc), traceback.format_exc()
            )
            self.audit.refresh_summary(config_id, config_name)
            raise

    # ------------------------------------------------------------------
    def _stage_files_to_local(self, config: Dict[str, Any], s3_file_paths: List[str]) -> List[str]:
        """Download files from Snowflake stage to /tmp for SFTP upload."""
        import os
        stage_name  = config["S3_STAGE_NAME"]
        local_dir   = "/tmp/extract_sftp/"
        os.makedirs(local_dir, exist_ok=True)
        local_paths = []

        for s3_path in s3_file_paths:
            file_name   = s3_path.split("/")[-1]
            stage_rel   = s3_path.lstrip("@").split("/", 1)[-1] if "/" in s3_path else s3_path
            stage_file  = f"@{stage_name}/{stage_rel}"
            self.session.sql(f"GET {stage_file} file://{local_dir}").collect()
            local_paths.append(os.path.join(local_dir, file_name))

        return local_paths

    # ------------------------------------------------------------------
    def _update_retry_count(self, run_id: str):
        """Count RETRY rows in SFTP_TRANSFER_LOG and write total to EXTRACT_AUDIT_LOG."""
        try:
            rows = self.session.sql(f"""
                SELECT COUNT(*) AS CNT
                FROM DATA_EXTRACT_DB.AUDIT.SFTP_TRANSFER_LOG
                WHERE RUN_ID = '{run_id}' AND STATUS = 'RETRY'
            """).collect()
            retry_count = rows[0]["CNT"] if rows else 0
            self.session.sql(f"""
                UPDATE {AUDIT_TABLE}
                SET SFTP_RETRY_COUNT = {retry_count}
                WHERE RUN_ID = '{run_id}'
            """).collect()
        except Exception as e:
            print(f"[AUDIT] WARNING: Could not update retry count: {e}")


# =============================================================================
# SFTP CONNECTION TEST
# =============================================================================

def test_sftp_connection(session: Session, config_name: str) -> str:
    """
    Stored procedure: verify SFTP connectivity for a config without
    transferring any files.

    Usage: CALL FRAMEWORK.TEST_SFTP_CONNECTION('MY_CONFIG_NAME')

    Returns JSON with connection test result.
    """
    mgr  = SFTPTransferManager(session)
    rows = session.sql(
        f"SELECT * FROM {CONFIG_TABLE} WHERE CONFIG_NAME = '{config_name}' AND IS_ACTIVE = TRUE"
    ).collect()

    if not rows:
        return json.dumps({"status": "ERROR", "message": f"Config '{config_name}' not found or inactive"})

    config = rows[0].as_dict()

    if not config.get("SFTP_ENABLED"):
        return json.dumps({"status": "SKIPPED", "message": "SFTP_ENABLED=FALSE for this config"})

    host   = config["SFTP_HOST"]
    port   = int(config.get("SFTP_PORT") or 22)
    result = {"config_name": config_name, "host": host, "port": port}

    try:
        params = SFTPTransferManager._build_conn_params_from_config(config)
        cred   = mgr._get_secret(config["SFTP_SECRET_NAME"])

        with SFTPConnection(params, cred) as conn:
            remote_path = config.get("SFTP_REMOTE_PATH", "/")
            try:
                listing = conn.client.listdir(remote_path)
                result["remote_listing_count"] = len(listing)
                result["remote_path"]          = remote_path
            except Exception as list_err:
                result["remote_listing_error"] = str(list_err)

        result["status"]  = "SUCCESS"
        result["message"] = f"Connected to {host}:{port} successfully"

    except Exception as exc:
        result["status"]  = "FAILED"
        result["message"] = f"{type(exc).__name__}: {exc}"

    print(f"[SFTP-TEST] {result}")
    return json.dumps(result, default=str)


# =============================================================================
# SNOWPARK STORED PROCEDURE ENTRY POINTS
# =============================================================================

def run_extract_by_name(session: Session, config_name: str) -> str:
    """Entry point: CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('MY_EXTRACT')"""
    engine  = DataExtractEngine(session)
    results = engine.run(config_name=config_name)
    return json.dumps(results, default=str)


def run_extract_by_id(session: Session, config_id: int) -> str:
    """Entry point: CALL FRAMEWORK.RUN_EXTRACT_BY_ID(1)"""
    engine  = DataExtractEngine(session)
    results = engine.run(config_id=config_id)
    return json.dumps(results, default=str)


def run_all_extracts(session: Session) -> str:
    """Entry point: CALL FRAMEWORK.RUN_ALL_EXTRACTS()"""
    engine  = DataExtractEngine(session)
    results = engine.run(run_all=True)
    return json.dumps(results, default=str)


def dry_run_extract(session: Session, config_name: str) -> str:
    """Entry point: CALL FRAMEWORK.DRY_RUN_EXTRACT('MY_EXTRACT')"""
    engine  = DataExtractEngine(session)
    results = engine.run(config_name=config_name, dry_run=True)
    return json.dumps(results, default=str)
