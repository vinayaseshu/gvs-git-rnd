-- =============================================================================
-- DATA EXTRACT FRAMEWORK - Stored Procedures & Task Scheduling
-- =============================================================================
-- Run AFTER: 01_setup_config_tables.sql
-- Requires:  Python files uploaded to CODE_STAGE (see 04_deployment.sql)
--
-- NOTE: If the SFTP extension is deployed, use 08_sftp_stored_procedures.sql
--       instead of this file to register v2 procedures with full SFTP support.
-- =============================================================================

USE ROLE SYSADMIN;
USE DATABASE DATA_EXTRACT_DB;
USE WAREHOUSE COMPUTE_WH;

-- =============================================================================
-- 1. STORED PROCEDURES (base S3-only; upgrade via 08_sftp_stored_procedures.sql)
-- =============================================================================

CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_EXTRACT_BY_NAME(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko')
HANDLER = 'data_extract_framework.run_extract_by_name'
IMPORTS = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py')
COMMENT = 'Run a specific data extract job by configuration name'
;

CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_EXTRACT_BY_ID(CONFIG_ID NUMBER)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko')
HANDLER = 'data_extract_framework.run_extract_by_id'
IMPORTS = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py')
COMMENT = 'Run a specific data extract job by configuration ID'
;

CREATE OR REPLACE PROCEDURE FRAMEWORK.RUN_ALL_EXTRACTS()
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko')
HANDLER = 'data_extract_framework.run_all_extracts'
IMPORTS = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py')
COMMENT = 'Run ALL active extract jobs defined in EXTRACT_CONFIG'
;

CREATE OR REPLACE PROCEDURE FRAMEWORK.DRY_RUN_EXTRACT(CONFIG_NAME VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'paramiko')
HANDLER = 'data_extract_framework.dry_run_extract'
IMPORTS = ('@DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE/data_extract_framework.py')
COMMENT = 'Preview the SQL for an extract job without running it'
;

-- =============================================================================
-- 2. SNOWFLAKE TASKS (per-config schedules)
-- =============================================================================

CREATE OR REPLACE TASK FRAMEWORK.TASK_DAILY_SALES_EXTRACT
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 0 6 * * * UTC'
    COMMENT   = 'Automated: Daily sales data extract to S3'
AS
    CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('DAILY_SALES_EXTRACT');

CREATE OR REPLACE TASK FRAMEWORK.TASK_CUSTOMER_SFTP_EXPORT
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 0 8 * * 1 UTC'
    COMMENT   = 'Automated: Weekly customer file to partner SFTP'
AS
    CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('CUSTOMER_SFTP_EXPORT');

CREATE OR REPLACE TASK FRAMEWORK.TASK_EVENTS_PARQUET_HOURLY
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = '60 MINUTE'
    COMMENT   = 'Automated: Hourly events data in Parquet format'
AS
    CALL FRAMEWORK.RUN_EXTRACT_BY_NAME('EVENTS_PARQUET_HOURLY');

-- Master task: runs all active extracts every hour.
-- Uncomment RESUME below to activate.
CREATE OR REPLACE TASK FRAMEWORK.TASK_RUN_ALL_EXTRACTS
    WAREHOUSE = COMPUTE_WH
    SCHEDULE  = 'USING CRON 0 * * * * UTC'
    COMMENT   = 'Master task: runs all active extract configurations'
AS
    CALL FRAMEWORK.RUN_ALL_EXTRACTS();

-- =============================================================================
-- 3. DYNAMIC TASK GENERATOR
--    Auto-creates or drops tasks based on EXTRACT_CONFIG schedule settings.
-- =============================================================================

CREATE OR REPLACE PROCEDURE FRAMEWORK.SYNC_EXTRACT_TASKS()
RETURNS TABLE (CONFIG_NAME VARCHAR, ACTION VARCHAR, STATUS VARCHAR, MESSAGE VARCHAR)
LANGUAGE SQL
COMMENT = 'Auto-creates or drops Snowflake tasks based on EXTRACT_CONFIG schedule settings'
AS
$$
DECLARE
    result_table RESULTSET;
    cur CURSOR FOR
        SELECT CONFIG_ID, CONFIG_NAME, SCHEDULE_CRON, SCHEDULE_MINUTES,
               SCHEDULE_WAREHOUSE, IS_ACTIVE, SCHEDULE_ENABLED
        FROM DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG;

    task_name   VARCHAR;
    schedule    VARCHAR;
    warehouse   VARCHAR;
    action_desc VARCHAR;
    status_msg  VARCHAR;
    msg         VARCHAR;
BEGIN
    CREATE OR REPLACE TEMPORARY TABLE TASK_SYNC_RESULTS (
        CONFIG_NAME VARCHAR, ACTION VARCHAR, STATUS VARCHAR, MESSAGE VARCHAR
    );

    FOR cfg IN cur DO
        task_name   := 'FRAMEWORK.TASK_AUTO_' || REPLACE(cfg.CONFIG_NAME, ' ', '_');
        warehouse   := COALESCE(cfg.SCHEDULE_WAREHOUSE, 'COMPUTE_WH');
        action_desc := 'NONE';
        status_msg  := 'OK';
        msg         := '';

        IF (cfg.IS_ACTIVE AND cfg.SCHEDULE_ENABLED) THEN
            IF (cfg.SCHEDULE_CRON IS NOT NULL) THEN
                schedule := 'USING CRON ' || cfg.SCHEDULE_CRON || ' UTC';
            ELSEIF (cfg.SCHEDULE_MINUTES IS NOT NULL) THEN
                schedule := cfg.SCHEDULE_MINUTES || ' MINUTE';
            ELSE
                INSERT INTO TASK_SYNC_RESULTS VALUES (
                    cfg.CONFIG_NAME, 'SKIP', 'WARNING',
                    'SCHEDULE_ENABLED=TRUE but no SCHEDULE_CRON or SCHEDULE_MINUTES set'
                );
                CONTINUE;
            END IF;

            LET create_sql VARCHAR :=
                'CREATE OR REPLACE TASK ' || task_name ||
                ' WAREHOUSE = ' || warehouse ||
                ' SCHEDULE = ''' || schedule || '''' ||
                ' COMMENT = ''Auto-generated task for config: ' || cfg.CONFIG_NAME || '''' ||
                ' AS CALL FRAMEWORK.RUN_EXTRACT_BY_ID(' || cfg.CONFIG_ID || ')';

            EXECUTE IMMEDIATE create_sql;
            EXECUTE IMMEDIATE 'ALTER TASK ' || task_name || ' RESUME';
            action_desc := 'CREATED_AND_RESUMED';
            msg := 'Task created with schedule: ' || schedule;

        ELSE
            EXECUTE IMMEDIATE 'DROP TASK IF EXISTS ' || task_name;
            action_desc := 'DROPPED';
            msg := 'Dropped because IS_ACTIVE=FALSE or SCHEDULE_ENABLED=FALSE';
        END IF;

        INSERT INTO TASK_SYNC_RESULTS VALUES (cfg.CONFIG_NAME, action_desc, status_msg, msg);
    END FOR;

    result_table := (SELECT * FROM TASK_SYNC_RESULTS ORDER BY CONFIG_NAME);
    RETURN TABLE(result_table);
END;
$$;

-- =============================================================================
-- 4. ACTIVATE TASKS
-- =============================================================================

ALTER TASK FRAMEWORK.TASK_DAILY_SALES_EXTRACT   RESUME;
ALTER TASK FRAMEWORK.TASK_CUSTOMER_SFTP_EXPORT  RESUME;
ALTER TASK FRAMEWORK.TASK_EVENTS_PARQUET_HOURLY RESUME;
-- ALTER TASK FRAMEWORK.TASK_RUN_ALL_EXTRACTS   RESUME;  -- Uncomment to use master task

-- To pause a task:
-- ALTER TASK FRAMEWORK.TASK_DAILY_SALES_EXTRACT SUSPEND;

-- =============================================================================
-- 5. AUDIT VIEWS
-- =============================================================================

CREATE OR REPLACE VIEW AUDIT.V_EXTRACT_RUN_HISTORY AS
SELECT
    al.AUDIT_ID,
    al.RUN_ID,
    al.CONFIG_NAME,
    al.STATUS,
    al.START_TIME,
    al.END_TIME,
    al.DURATION_SECONDS,
    al.ROWS_EXTRACTED,
    al.FILES_GENERATED,
    al.BYTES_WRITTEN,
    ROUND(al.BYTES_WRITTEN / NULLIF(al.ROWS_EXTRACTED, 0), 0) AS BYTES_PER_ROW,
    al.S3_FILES_UPLOADED,
    al.SFTP_FILES_UPLOADED,
    al.ERROR_CODE,
    al.ERROR_MESSAGE,
    al.EXECUTED_BY,
    al.WAREHOUSE_NAME,
    ec.FILE_FORMAT,
    ec.S3_STAGE_NAME,
    ec.SFTP_HOST
FROM AUDIT.EXTRACT_AUDIT_LOG     al
LEFT JOIN FRAMEWORK.EXTRACT_CONFIG ec ON al.CONFIG_ID = ec.CONFIG_ID
ORDER BY al.START_TIME DESC;


CREATE OR REPLACE VIEW AUDIT.V_EXTRACT_LAST_RUN AS
SELECT
    ec.CONFIG_ID,
    ec.CONFIG_NAME,
    ec.IS_ACTIVE,
    ec.SCHEDULE_ENABLED,
    ec.SCHEDULE_CRON,
    latest.STATUS           AS LAST_STATUS,
    latest.START_TIME       AS LAST_RUN_TIME,
    latest.DURATION_SECONDS AS LAST_DURATION_SEC,
    latest.ROWS_EXTRACTED   AS LAST_ROWS,
    latest.FILES_GENERATED  AS LAST_FILES,
    latest.ERROR_MESSAGE    AS LAST_ERROR,
    summary.TOTAL_RUNS,
    summary.SUCCESSFUL_RUNS,
    summary.FAILED_RUNS,
    ROUND(summary.SUCCESSFUL_RUNS * 100.0 / NULLIF(summary.TOTAL_RUNS, 0), 1) AS SUCCESS_RATE_PCT
FROM FRAMEWORK.EXTRACT_CONFIG ec
LEFT JOIN LATERAL (
    SELECT STATUS, START_TIME, DURATION_SECONDS, ROWS_EXTRACTED, FILES_GENERATED, ERROR_MESSAGE
    FROM AUDIT.EXTRACT_AUDIT_LOG
    WHERE CONFIG_ID = ec.CONFIG_ID
    ORDER BY START_TIME DESC
    LIMIT 1
) latest ON TRUE
LEFT JOIN LATERAL (
    SELECT
        SUM(TOTAL_RUNS)      AS TOTAL_RUNS,
        SUM(SUCCESSFUL_RUNS) AS SUCCESSFUL_RUNS,
        SUM(FAILED_RUNS)     AS FAILED_RUNS
    FROM AUDIT.EXTRACT_AUDIT_SUMMARY
    WHERE CONFIG_ID = ec.CONFIG_ID
) summary ON TRUE;

-- =============================================================================
-- 6. USEFUL AUDIT QUERIES
-- =============================================================================

-- Recent run history (last 24h)
SELECT CONFIG_NAME, STATUS, START_TIME, DURATION_SECONDS,
       ROWS_EXTRACTED, FILES_GENERATED, ERROR_MESSAGE
FROM AUDIT.V_EXTRACT_RUN_HISTORY
WHERE START_TIME >= DATEADD('hour', -24, CURRENT_TIMESTAMP())
ORDER BY START_TIME DESC;

-- Failed runs (last 7 days)
SELECT CONFIG_NAME, RUN_ID, START_TIME, ERROR_CODE, ERROR_MESSAGE
FROM AUDIT.EXTRACT_AUDIT_LOG
WHERE STATUS = 'FAILED'
  AND START_TIME >= DATEADD('day', -7, CURRENT_TIMESTAMP())
ORDER BY START_TIME DESC;

-- Last run status per extract job
SELECT * FROM AUDIT.V_EXTRACT_LAST_RUN
ORDER BY CONFIG_NAME;

-- Daily summary (rows, files, MB)
SELECT SUMMARY_DATE, CONFIG_NAME, TOTAL_RUNS, SUCCESSFUL_RUNS,
       FAILED_RUNS, TOTAL_ROWS, TOTAL_FILES,
       ROUND(TOTAL_BYTES / 1024 / 1024, 2) AS TOTAL_MB
FROM AUDIT.EXTRACT_AUDIT_SUMMARY
ORDER BY SUMMARY_DATE DESC, CONFIG_NAME;

-- Average duration trend per extract (weekly)
SELECT
    CONFIG_NAME,
    DATE_TRUNC('week', START_TIME) AS WEEK,
    COUNT(*)                       AS RUNS,
    AVG(DURATION_SECONDS)          AS AVG_DURATION_SEC,
    MAX(ROWS_EXTRACTED)            AS MAX_ROWS
FROM AUDIT.EXTRACT_AUDIT_LOG
WHERE STATUS = 'SUCCESS'
GROUP BY 1, 2
ORDER BY CONFIG_NAME, WEEK DESC;
