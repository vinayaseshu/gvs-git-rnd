-- =============================================================================
-- DATA EXTRACT FRAMEWORK - SFTP Extension
-- Part 1: Schema Changes (extend existing tables + new SFTP-specific tables)
-- =============================================================================

USE ROLE SYSADMIN;
USE DATABASE DATA_EXTRACT_DB;
USE WAREHOUSE COMPUTE_WH;

-- =============================================================================
-- 1. EXTEND EXTRACT_CONFIG WITH FULL SFTP OPTIONS
--    (ADD only new columns; existing rows are unaffected)
-- =============================================================================

-- Transfer behavior
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_ONLY               BOOLEAN     DEFAULT FALSE;          -- Skip S3; go direct to SFTP
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_TEMP_SUFFIX        VARCHAR(10) DEFAULT '.tmp';         -- Upload as .tmp then rename
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_RENAME_ON_COMPLETE BOOLEAN     DEFAULT TRUE;           -- Atomic rename after upload

-- Retry / resilience
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_RETRY_ATTEMPTS     NUMBER      DEFAULT 3;              -- Max upload retry attempts
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_RETRY_DELAY_SEC    NUMBER      DEFAULT 30;             -- Seconds between retries
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_CONNECT_TIMEOUT    NUMBER      DEFAULT 30;             -- TCP connect timeout (s)
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_BANNER_TIMEOUT     NUMBER      DEFAULT 15;             -- SSH banner timeout (s)

-- Integrity
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_CHECKSUM_ENABLED   BOOLEAN     DEFAULT TRUE;           -- Write .md5 / .sha256 file
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_CHECKSUM_TYPE      VARCHAR(10) DEFAULT 'MD5'
    CHECK (SFTP_CHECKSUM_TYPE IN ('MD5','SHA256','SHA512'));

-- Completion signal files (flag files / trigger files)
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_FLAG_FILE_ENABLED  BOOLEAN     DEFAULT FALSE;          -- Write empty .done flag file
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_FLAG_FILE_SUFFIX   VARCHAR(20) DEFAULT '.done';        -- Suffix for flag file

-- PGP Encryption (encrypt before upload)
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_PGP_ENABLED        BOOLEAN     DEFAULT FALSE;
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_PGP_KEY_SECRET     VARCHAR(200);                       -- Snowflake secret with PGP pub key

-- Remote file lifecycle
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_REMOTE_ARCHIVE_PATH VARCHAR(500);                      -- Move old files here before upload
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_OVERWRITE_REMOTE   BOOLEAN     DEFAULT TRUE;           -- Overwrite if file exists
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_REMOTE_RETENTION_DAYS NUMBER   DEFAULT 0;              -- 0 = no cleanup; >0 = purge old files

-- Bandwidth / performance
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_CHUNK_SIZE_KB      NUMBER      DEFAULT 32768;          -- Read/write chunk size in KB
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_KEEP_ALIVE_SEC     NUMBER      DEFAULT 60;             -- Send keepalive every N seconds

-- SSH host key verification
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_KNOWN_HOST_KEY     VARCHAR(2000);                      -- Expected host key fingerprint (SHA256)
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_HOST_KEY_BYPASS    BOOLEAN     DEFAULT FALSE;          -- WARNING: insecure, dev use only

-- Post-transfer
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_POST_CMD           TEXT;                               -- Remote shell cmd after upload (if supported)
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_DELETE_LOCAL_AFTER BOOLEAN     DEFAULT TRUE;           -- Remove /tmp files after upload

-- Multi-destination SFTP (JSON array of secondary SFTP configs)
ALTER TABLE FRAMEWORK.EXTRACT_CONFIG ADD COLUMN IF NOT EXISTS
    SFTP_SECONDARY_TARGETS  VARIANT;                            -- [{host,port,user,secret,path}, ...]

COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.SFTP_ONLY
    IS 'When TRUE, bypass S3 stage; generate file directly in /tmp and push to SFTP only';
COMMENT ON COLUMN FRAMEWORK.EXTRACT_CONFIG.SFTP_SECONDARY_TARGETS
    IS 'JSON array of additional SFTP destinations. Each object: {host, port, username, secret_name, remote_path, auth_type}';


-- =============================================================================
-- 2. EXTEND AUDIT LOG WITH SFTP-SPECIFIC METRICS
-- =============================================================================

ALTER TABLE AUDIT.EXTRACT_AUDIT_LOG ADD COLUMN IF NOT EXISTS
    SFTP_TRANSFER_START_TIME  TIMESTAMP_NTZ;
ALTER TABLE AUDIT.EXTRACT_AUDIT_LOG ADD COLUMN IF NOT EXISTS
    SFTP_TRANSFER_END_TIME    TIMESTAMP_NTZ;
ALTER TABLE AUDIT.EXTRACT_AUDIT_LOG ADD COLUMN IF NOT EXISTS
    SFTP_TRANSFER_DURATION_SEC NUMBER;
ALTER TABLE AUDIT.EXTRACT_AUDIT_LOG ADD COLUMN IF NOT EXISTS
    SFTP_BYTES_TRANSFERRED    NUMBER      DEFAULT 0;
ALTER TABLE AUDIT.EXTRACT_AUDIT_LOG ADD COLUMN IF NOT EXISTS
    SFTP_RETRY_COUNT          NUMBER      DEFAULT 0;
ALTER TABLE AUDIT.EXTRACT_AUDIT_LOG ADD COLUMN IF NOT EXISTS
    SFTP_CHECKSUM_VALUES      VARIANT;                          -- {filename: checksum_hex, ...}
ALTER TABLE AUDIT.EXTRACT_AUDIT_LOG ADD COLUMN IF NOT EXISTS
    SFTP_ERROR_DETAIL         TEXT;                             -- SFTP-specific error (separate from main)


-- =============================================================================
-- 3. NEW: SFTP TRANSFER DETAIL TABLE  (one row per file per destination)
-- =============================================================================

CREATE TABLE IF NOT EXISTS AUDIT.SFTP_TRANSFER_LOG (
    TRANSFER_ID         NUMBER AUTOINCREMENT PRIMARY KEY,
    AUDIT_ID            NUMBER          NOT NULL,               -- FK to EXTRACT_AUDIT_LOG
    RUN_ID              VARCHAR(100)    NOT NULL,
    CONFIG_NAME         VARCHAR(200)    NOT NULL,

    -- File info
    LOCAL_FILE_PATH     VARCHAR(1000),
    LOCAL_FILE_SIZE_BYTES NUMBER,
    CHECKSUM_TYPE       VARCHAR(10),
    CHECKSUM_VALUE      VARCHAR(128),

    -- Destination
    SFTP_HOST           VARCHAR(500)    NOT NULL,
    SFTP_PORT           NUMBER,
    SFTP_USERNAME       VARCHAR(200),
    SFTP_REMOTE_PATH    VARCHAR(1000)   NOT NULL,               -- Final remote path after rename
    SFTP_TEMP_PATH      VARCHAR(1000),                          -- Temp path used during upload

    -- Result
    STATUS              VARCHAR(20)     NOT NULL
                        CHECK (STATUS IN ('SUCCESS','FAILED','SKIPPED','RETRY')),
    ATTEMPT_NUMBER      NUMBER          DEFAULT 1,
    TRANSFER_START      TIMESTAMP_NTZ   NOT NULL,
    TRANSFER_END        TIMESTAMP_NTZ,
    DURATION_MS         NUMBER,
    THROUGHPUT_MBPS     FLOAT,

    -- Flag / checksum files written
    FLAG_FILE_PATH      VARCHAR(1000),
    CHECKSUM_FILE_PATH  VARCHAR(1000),
    PGP_ENCRYPTED       BOOLEAN         DEFAULT FALSE,

    -- Error
    ERROR_CODE          VARCHAR(100),
    ERROR_MESSAGE       TEXT,

    CREATED_AT          TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
);

COMMENT ON TABLE AUDIT.SFTP_TRANSFER_LOG IS 'Per-file SFTP transfer detail log with retry tracking';

CREATE OR REPLACE INDEX IDX_SFTP_LOG_RUN_ID    ON AUDIT.SFTP_TRANSFER_LOG (RUN_ID);
CREATE OR REPLACE INDEX IDX_SFTP_LOG_STATUS    ON AUDIT.SFTP_TRANSFER_LOG (STATUS);
CREATE OR REPLACE INDEX IDX_SFTP_LOG_CREATED   ON AUDIT.SFTP_TRANSFER_LOG (CREATED_AT);


-- =============================================================================
-- 4. SFTP CONNECTION REGISTRY  (reusable server definitions)
--    Optional: store server profiles here and reference by name in EXTRACT_CONFIG
-- =============================================================================

CREATE TABLE IF NOT EXISTS FRAMEWORK.SFTP_CONNECTION_REGISTRY (
    CONNECTION_ID       NUMBER AUTOINCREMENT PRIMARY KEY,
    CONNECTION_NAME     VARCHAR(200)    NOT NULL UNIQUE,         -- Reference name (e.g. 'PARTNER_A')
    IS_ACTIVE           BOOLEAN         DEFAULT TRUE,
    SFTP_HOST           VARCHAR(500)    NOT NULL,
    SFTP_PORT           NUMBER          DEFAULT 22,
    SFTP_USERNAME       VARCHAR(200)    NOT NULL,
    SFTP_SECRET_NAME    VARCHAR(200)    NOT NULL,
    SFTP_AUTH_TYPE      VARCHAR(20)     DEFAULT 'PASSWORD'
                        CHECK (SFTP_AUTH_TYPE IN ('PASSWORD','KEY')),
    SFTP_KNOWN_HOST_KEY VARCHAR(2000),
    SFTP_HOST_KEY_BYPASS BOOLEAN        DEFAULT FALSE,
    CONNECT_TIMEOUT     NUMBER          DEFAULT 30,
    BANNER_TIMEOUT      NUMBER          DEFAULT 15,
    KEEP_ALIVE_SEC      NUMBER          DEFAULT 60,
    NOTES               TEXT,
    CREATED_BY          VARCHAR(200)    DEFAULT CURRENT_USER(),
    CREATED_AT          TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP()
);

COMMENT ON TABLE FRAMEWORK.SFTP_CONNECTION_REGISTRY
    IS 'Reusable SFTP server connection profiles referenced by extract configs';


-- =============================================================================
-- 5. SAMPLE CONFIGS: SFTP-ONLY and Multi-destination
-- =============================================================================

-- Example: SFTP-ONLY extract (no S3 stage needed)
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, DELIMITER, COMPRESSION,
    S3_ENABLED,
    SFTP_ENABLED, SFTP_ONLY,
    SFTP_HOST, SFTP_PORT, SFTP_USERNAME, SFTP_SECRET_NAME,
    SFTP_REMOTE_PATH, SFTP_AUTH_TYPE,
    SFTP_RETRY_ATTEMPTS, SFTP_RETRY_DELAY_SEC,
    SFTP_CHECKSUM_ENABLED, SFTP_CHECKSUM_TYPE,
    SFTP_FLAG_FILE_ENABLED, SFTP_FLAG_FILE_SUFFIX,
    SFTP_TEMP_SUFFIX, SFTP_RENAME_ON_COMPLETE,
    SFTP_REMOTE_RETENTION_DAYS,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE,
    NOTES
) VALUES (
    'PARTNER_DAILY_REPORT_SFTP_ONLY',
    'REPORTING_DB', 'PUBLIC', 'DAILY_PARTNER_REPORT_VW',
    'CSV', 'PARTNER_RPT_{YYYYMMDD}.csv', '|', 'GZIP',
    FALSE,                              -- Skip S3 entirely
    TRUE, TRUE,                         -- SFTP only
    'sftp.partner.com', 22, 'transfer_user', 'PARTNER_SFTP_SECRET',
    '/inbound/reports/', 'PASSWORD',
    3, 30,
    TRUE, 'MD5',
    TRUE, '.done',
    '.tmp', TRUE,
    7,                                  -- Delete files older than 7 days
    TRUE, '0 7 * * *', 'COMPUTE_WH',
    'Daily report direct to partner SFTP, no S3 intermediate'
);

-- Example: S3 + SFTP with PGP encryption
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN, COMPRESSION,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SFTP_ENABLED, SFTP_HOST, SFTP_PORT, SFTP_USERNAME,
    SFTP_SECRET_NAME, SFTP_REMOTE_PATH,
    SFTP_RETRY_ATTEMPTS, SFTP_CHECKSUM_ENABLED,
    SFTP_PGP_ENABLED, SFTP_PGP_KEY_SECRET,
    SFTP_RENAME_ON_COMPLETE,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE
) VALUES (
    'SECURE_FINANCE_EXPORT',
    'FINANCE_DB', 'PUBLIC', 'FINANCIAL_SUMMARY',
    'CSV', 'FINANCE_{YYYYMMDD}.csv', 'NONE',
    TRUE, 'MY_S3_STAGE', 'extracts/finance/',
    TRUE, 'sftp.bank-partner.com', 22, 'bank_user',
    'BANK_SFTP_SECRET', '/secure/inbound/',
    5, TRUE,
    TRUE, 'FINANCE_PGP_PUBKEY_SECRET',
    TRUE,
    TRUE, '0 5 * * 1-5', 'COMPUTE_WH'
);

-- Example: Multi-destination (primary SFTP + secondary via SFTP_SECONDARY_TARGETS)
INSERT INTO FRAMEWORK.EXTRACT_CONFIG (
    CONFIG_NAME, SOURCE_DATABASE, SOURCE_SCHEMA, SOURCE_TABLE,
    FILE_FORMAT, FILE_NAME_PATTERN,
    S3_ENABLED, S3_STAGE_NAME, S3_PATH_PREFIX,
    SFTP_ENABLED, SFTP_HOST, SFTP_USERNAME, SFTP_SECRET_NAME,
    SFTP_REMOTE_PATH,
    SFTP_SECONDARY_TARGETS,
    SCHEDULE_ENABLED, SCHEDULE_CRON, SCHEDULE_WAREHOUSE
) VALUES (
    'MULTI_DEST_BROADCAST',
    'SALES_DB', 'PUBLIC', 'SALES_SUMMARY',
    'CSV', 'SALES_{YYYYMMDD}.csv',
    TRUE, 'MY_S3_STAGE', 'extracts/sales/',
    TRUE, 'sftp.primary-partner.com', 'user_a', 'PARTNER_A_SECRET',
    '/data/inbound/',
    PARSE_JSON('[
        {"host":"sftp.partner-b.com","port":22,"username":"user_b","secret_name":"PARTNER_B_SECRET","remote_path":"/uploads/","auth_type":"PASSWORD"},
        {"host":"sftp.partner-c.com","port":2222,"username":"user_c","secret_name":"PARTNER_C_KEY_SECRET","remote_path":"/receive/","auth_type":"KEY"}
    ]'),
    TRUE, '0 8 * * *', 'COMPUTE_WH'
);


-- =============================================================================
-- 6. SFTP AUDIT VIEWS
-- =============================================================================

CREATE OR REPLACE VIEW AUDIT.V_SFTP_TRANSFER_HISTORY AS
SELECT
    t.TRANSFER_ID,
    t.RUN_ID,
    t.CONFIG_NAME,
    t.SFTP_HOST,
    t.SFTP_REMOTE_PATH,
    t.STATUS,
    t.ATTEMPT_NUMBER,
    t.LOCAL_FILE_SIZE_BYTES,
    t.THROUGHPUT_MBPS,
    t.DURATION_MS,
    t.CHECKSUM_TYPE,
    t.CHECKSUM_VALUE,
    t.PGP_ENCRYPTED,
    t.FLAG_FILE_PATH,
    t.TRANSFER_START,
    t.TRANSFER_END,
    t.ERROR_CODE,
    t.ERROR_MESSAGE,
    a.ROWS_EXTRACTED,
    a.SFTP_RETRY_COUNT
FROM AUDIT.SFTP_TRANSFER_LOG t
JOIN AUDIT.EXTRACT_AUDIT_LOG a ON t.RUN_ID = a.RUN_ID
ORDER BY t.TRANSFER_START DESC;

CREATE OR REPLACE VIEW AUDIT.V_SFTP_FAILED_TRANSFERS AS
SELECT
    CONFIG_NAME, SFTP_HOST, SFTP_REMOTE_PATH,
    ATTEMPT_NUMBER, TRANSFER_START, ERROR_CODE, ERROR_MESSAGE
FROM AUDIT.SFTP_TRANSFER_LOG
WHERE STATUS = 'FAILED'
ORDER BY TRANSFER_START DESC;

CREATE OR REPLACE VIEW AUDIT.V_SFTP_THROUGHPUT_STATS AS
SELECT
    CONFIG_NAME,
    SFTP_HOST,
    DATE(TRANSFER_START)            AS TRANSFER_DATE,
    COUNT(*)                        AS TOTAL_FILES,
    SUM(LOCAL_FILE_SIZE_BYTES)/1024/1024 AS TOTAL_MB,
    AVG(THROUGHPUT_MBPS)            AS AVG_THROUGHPUT_MBPS,
    MAX(THROUGHPUT_MBPS)            AS MAX_THROUGHPUT_MBPS,
    AVG(DURATION_MS)/1000           AS AVG_DURATION_SEC,
    SUM(CASE WHEN STATUS='SUCCESS' THEN 1 ELSE 0 END) AS SUCCESS_COUNT,
    SUM(CASE WHEN STATUS='FAILED'  THEN 1 ELSE 0 END) AS FAIL_COUNT
FROM AUDIT.SFTP_TRANSFER_LOG
GROUP BY 1, 2, 3
ORDER BY TRANSFER_DATE DESC;
