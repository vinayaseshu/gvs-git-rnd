-- =============================================================================
-- DATA EXTRACT FRAMEWORK - Deployment Script
-- =============================================================================
-- Run this script ONCE to deploy the full framework to Snowflake.
-- Prerequisites:
--   1. Snowflake account with SYSADMIN role
--   2. An existing S3 external stage (or create one below)
--   3. Python file uploaded to code stage
-- =============================================================================

USE ROLE SYSADMIN;
USE WAREHOUSE COMPUTE_WH;

-- =============================================================================
-- STEP 1: Create Databases and Schemas
-- =============================================================================
CREATE DATABASE IF NOT EXISTS DATA_EXTRACT_DB;
USE DATABASE DATA_EXTRACT_DB;
CREATE SCHEMA IF NOT EXISTS FRAMEWORK;
CREATE SCHEMA IF NOT EXISTS AUDIT;

-- =============================================================================
-- STEP 2: Create Internal Stage for Python Code
-- =============================================================================
CREATE STAGE IF NOT EXISTS FRAMEWORK.CODE_STAGE
    COMMENT = 'Stores Python source code for Snowpark stored procedures';

-- Upload framework code (run this from SnowSQL CLI or Python connector):
-- PUT file://02_data_extract_framework.py @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;

-- =============================================================================
-- STEP 3: Create S3 External Stage (customize with your S3 bucket)
-- =============================================================================

-- Option A: Using Storage Integration (recommended for production)
CREATE STORAGE INTEGRATION IF NOT EXISTS S3_EXTRACT_INTEGRATION
    TYPE = EXTERNAL_STAGE
    STORAGE_PROVIDER = 'S3'
    ENABLED = TRUE
    STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::YOUR_ACCOUNT_ID:role/YOUR_SNOWFLAKE_ROLE'
    STORAGE_ALLOWED_LOCATIONS = ('s3://your-bucket/extracts/');

CREATE STAGE IF NOT EXISTS FRAMEWORK.MY_S3_STAGE
    URL = 's3://your-bucket/extracts/'
    STORAGE_INTEGRATION = S3_EXTRACT_INTEGRATION
    COMMENT = 'S3 stage for data extracts';

-- Option B: Using Access Key (less secure, dev/test only)
-- CREATE STAGE IF NOT EXISTS FRAMEWORK.MY_S3_STAGE
--     URL = 's3://your-bucket/extracts/'
--     CREDENTIALS = (AWS_KEY_ID = 'XXXX' AWS_SECRET_KEY = 'YYYY')
--     COMMENT = 'S3 stage for data extracts';

-- =============================================================================
-- STEP 4: Create Snowflake Secret for SFTP credentials
-- =============================================================================
CREATE SECRET IF NOT EXISTS FRAMEWORK.SFTP_PARTNER_SECRET
    TYPE = GENERIC_STRING
    SECRET_STRING = 'your_sftp_password_here'
    COMMENT = 'SFTP password for partner file delivery';

-- For SSH key auth:
-- CREATE SECRET IF NOT EXISTS FRAMEWORK.SFTP_PARTNER_KEY
--     TYPE = GENERIC_STRING
--     SECRET_STRING = '-----BEGIN RSA PRIVATE KEY-----\n...\n-----END RSA PRIVATE KEY-----';

-- =============================================================================
-- STEP 5: Grant Permissions
-- =============================================================================
CREATE ROLE IF NOT EXISTS EXTRACT_FRAMEWORK_ROLE;

GRANT USAGE ON DATABASE DATA_EXTRACT_DB TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE ON SCHEMA DATA_EXTRACT_DB.FRAMEWORK TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE ON SCHEMA DATA_EXTRACT_DB.AUDIT TO ROLE EXTRACT_FRAMEWORK_ROLE;

GRANT SELECT ON TABLE DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT INSERT, UPDATE ON TABLE DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_LOG TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT INSERT, UPDATE ON TABLE DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_SUMMARY TO ROLE EXTRACT_FRAMEWORK_ROLE;

GRANT USAGE ON STAGE DATA_EXTRACT_DB.FRAMEWORK.MY_S3_STAGE TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE ON STAGE DATA_EXTRACT_DB.FRAMEWORK.CODE_STAGE TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT USAGE ON SECRET DATA_EXTRACT_DB.FRAMEWORK.SFTP_PARTNER_SECRET TO ROLE EXTRACT_FRAMEWORK_ROLE;

GRANT USAGE ON WAREHOUSE COMPUTE_WH TO ROLE EXTRACT_FRAMEWORK_ROLE;
GRANT EXECUTE TASK ON ACCOUNT TO ROLE EXTRACT_FRAMEWORK_ROLE;

-- Grant role to users
GRANT ROLE EXTRACT_FRAMEWORK_ROLE TO USER YOUR_USER;

-- =============================================================================
-- STEP 6: Run Setup Scripts (in order)
-- =============================================================================
-- Execute: 01_setup_config_tables.sql    -> Creates tables
-- Execute: 03_stored_procedures_tasks.sql -> Creates procs and tasks

-- =============================================================================
-- STEP 7: Verify Deployment
-- =============================================================================
SHOW PROCEDURES IN SCHEMA DATA_EXTRACT_DB.FRAMEWORK;
SHOW TASKS     IN SCHEMA DATA_EXTRACT_DB.FRAMEWORK;
SHOW STAGES    IN SCHEMA DATA_EXTRACT_DB.FRAMEWORK;

SELECT CONFIG_ID, CONFIG_NAME, IS_ACTIVE, SCHEDULE_ENABLED, SCHEDULE_CRON
FROM DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG;

-- Test dry run (should work without any S3/SFTP connectivity)
CALL DATA_EXTRACT_DB.FRAMEWORK.DRY_RUN_EXTRACT('DAILY_SALES_EXTRACT');
