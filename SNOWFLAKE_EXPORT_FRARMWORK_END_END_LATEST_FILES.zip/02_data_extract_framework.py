"""
=============================================================================
DATA EXTRACT FRAMEWORK - Core Utilities & Base Classes
=============================================================================
File: data_extract_framework.py

Provides shared utilities, audit management, and S3 export logic used by
all stored procedures. Engine and SFTP logic live in separate modules:
  - sftp_transfer_manager.py     -> SFTPTransferManager (full production SFTP)
  - data_extract_engine_v2.py    -> DataExtractEngine   (orchestration engine)

Upload to Snowflake stage before deploying stored procedures:
  PUT file://02_data_extract_framework.py @FRAMEWORK.CODE_STAGE/ AUTO_COMPRESS=FALSE OVERWRITE=TRUE;
=============================================================================
"""

import uuid
import re
import json
import traceback
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

from snowflake.snowpark import Session
from snowflake.snowpark.exceptions import SnowparkSQLException
import snowflake.snowpark.functions as F


# =============================================================================
# CONSTANTS
# =============================================================================
FRAMEWORK_DB  = "DATA_EXTRACT_DB"
CONFIG_TABLE  = "DATA_EXTRACT_DB.FRAMEWORK.EXTRACT_CONFIG"
AUDIT_TABLE   = "DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_LOG"
SUMMARY_TABLE = "DATA_EXTRACT_DB.AUDIT.EXTRACT_AUDIT_SUMMARY"

STATUS_RUNNING = "RUNNING"
STATUS_SUCCESS = "SUCCESS"
STATUS_FAILED  = "FAILED"
STATUS_SKIPPED = "SKIPPED"


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def resolve_file_name(pattern: str, run_dt: Optional[datetime] = None) -> str:
    """
    Resolve dynamic tokens in file name patterns.

    Supported tokens:
        {YYYYMMDD_HH24MISS}  -> 20250120_063045
        {YYYYMMDD_HH24}      -> 20250120_06
        {YYYYMMDD}           -> 20250120
        {YYYY}               -> 2025
        {MM}                 -> 01
        {DD}                 -> 20
        {HH24}               -> 06
        {MI}                 -> 30
        {SS}                 -> 45
        {EPOCH}              -> 1737356445
    """
    dt = run_dt or datetime.now(timezone.utc)
    replacements = {
        "{YYYYMMDD_HH24MISS}": dt.strftime("%Y%m%d_%H%M%S"),
        "{YYYYMMDD_HH24}":     dt.strftime("%Y%m%d_%H"),
        "{YYYYMMDD}":          dt.strftime("%Y%m%d"),
        "{YYYY}":              dt.strftime("%Y"),
        "{MM}":                dt.strftime("%m"),
        "{DD}":                dt.strftime("%d"),
        "{HH24}":              dt.strftime("%H"),
        "{MI}":                dt.strftime("%M"),
        "{SS}":                dt.strftime("%S"),
        "{EPOCH}":             str(int(dt.timestamp())),
    }
    name = pattern
    for token, value in replacements.items():
        name = name.replace(token, value)
    return name


def build_source_query(config: Dict[str, Any]) -> str:
    """
    Build the effective SQL query from config.

    Uses SOURCE_QUERY if provided; otherwise builds SELECT * FROM SOURCE_TABLE.
    Appends FILTER_CONDITION and ORDER_BY_COLUMN when set.
    """
    if config.get("SOURCE_QUERY"):
        base = config["SOURCE_QUERY"].rstrip(";")
        if config.get("FILTER_CONDITION"):
            if re.search(r'\bWHERE\b', base, re.IGNORECASE):
                base += f" AND ({config['FILTER_CONDITION']})"
            else:
                base += f" WHERE {config['FILTER_CONDITION']}"
    else:
        src  = f"{config['SOURCE_DATABASE']}.{config['SOURCE_SCHEMA']}.{config['SOURCE_TABLE']}"
        base = f"SELECT * FROM {src}"
        if config.get("FILTER_CONDITION"):
            base += f" WHERE {config['FILTER_CONDITION']}"

    if config.get("ORDER_BY_COLUMN"):
        base += f" ORDER BY {config['ORDER_BY_COLUMN']}"

    return base


def get_snowflake_copy_format_options(config: Dict[str, Any]) -> str:
    """Generate COPY INTO FILE_FORMAT clause from config."""
    fmt = config.get("FILE_FORMAT", "CSV").upper()

    if fmt == "CSV":
        options = [
            "TYPE = CSV",
            f"FIELD_DELIMITER = '{config.get('DELIMITER', ',')}'",
            f"NULL_IF = ('{config.get('NULL_VALUE', '')}')",
            f"DATE_FORMAT = '{config.get('DATE_FORMAT', 'YYYY-MM-DD')}'",
            f"TIMESTAMP_FORMAT = '{config.get('TIMESTAMP_FORMAT', 'YYYY-MM-DD HH24:MI:SS')}'",
            f"COMPRESSION = {config.get('COMPRESSION', 'NONE')}",
        ]
        if config.get("INCLUDE_HEADER", True):
            options.append("SKIP_HEADER = 0")
    elif fmt == "PARQUET":
        compression = config.get("COMPRESSION", "SNAPPY")
        options = [
            "TYPE = PARQUET",
            f"SNAPPY_COMPRESSION = {'TRUE' if compression == 'SNAPPY' else 'FALSE'}",
        ]
    elif fmt == "JSON":
        options = [
            "TYPE = JSON",
            f"COMPRESSION = {config.get('COMPRESSION', 'NONE')}",
        ]
    else:
        raise ValueError(f"Unsupported FILE_FORMAT: {fmt}")

    return "\n  FILE_FORMAT = (  " + ",\n    ".join(options) + "\n  )"


# =============================================================================
# AUDIT MANAGER
# =============================================================================

class AuditManager:
    """Handles all audit logging to EXTRACT_AUDIT_LOG and EXTRACT_AUDIT_SUMMARY."""

    def __init__(self, session: Session):
        self.session = session

    def start_run(self, config_id: int, config_name: str, effective_query: str) -> str:
        """Insert a RUNNING audit record and return the run_id UUID."""
        run_id    = str(uuid.uuid4())
        warehouse = self.session.sql("SELECT CURRENT_WAREHOUSE()").collect()[0][0]
        query_id  = self.session.sql("SELECT LAST_QUERY_ID()").collect()[0][0]

        self.session.sql(f"""
            INSERT INTO {AUDIT_TABLE} (
                CONFIG_ID, CONFIG_NAME, RUN_ID, STATUS,
                START_TIME, EXECUTED_BY, QUERY_ID,
                WAREHOUSE_NAME, EFFECTIVE_QUERY
            ) VALUES (
                {config_id},
                '{config_name}',
                '{run_id}',
                '{STATUS_RUNNING}',
                CURRENT_TIMESTAMP(),
                CURRENT_USER(),
                '{query_id}',
                '{warehouse}',
                $${effective_query}$$
            )
        """).collect()
        print(f"[AUDIT] Run started | run_id={run_id} | config={config_name}")
        return run_id

    def end_run_success(
        self,
        run_id:          str,
        rows_extracted:  int,
        files_generated: int,
        bytes_written:   int,
        s3_files:        List[str],
        sftp_files:      List[str],
    ):
        """Update audit record with success details."""
        s3_json   = json.dumps(s3_files).replace("'", "''")
        sftp_json = json.dumps(sftp_files).replace("'", "''")

        self.session.sql(f"""
            UPDATE {AUDIT_TABLE}
            SET
                STATUS              = '{STATUS_SUCCESS}',
                END_TIME            = CURRENT_TIMESTAMP(),
                DURATION_SECONDS    = DATEDIFF('second', START_TIME, CURRENT_TIMESTAMP()),
                ROWS_EXTRACTED      = {rows_extracted},
                FILES_GENERATED     = {files_generated},
                BYTES_WRITTEN       = {bytes_written},
                S3_FILES_UPLOADED   = PARSE_JSON('{s3_json}'),
                SFTP_FILES_UPLOADED = PARSE_JSON('{sftp_json}')
            WHERE RUN_ID = '{run_id}'
        """).collect()
        print(f"[AUDIT] Run SUCCESS | run_id={run_id} | rows={rows_extracted} | files={files_generated}")

    def end_run_failed(self, run_id: str, error_code: str, error_message: str, stack_trace: str):
        """Update audit record with failure details."""
        error_message = error_message.replace("'", "''")[:4000]
        stack_trace   = stack_trace.replace("'", "''")[:8000]

        self.session.sql(f"""
            UPDATE {AUDIT_TABLE}
            SET
                STATUS           = '{STATUS_FAILED}',
                END_TIME         = CURRENT_TIMESTAMP(),
                DURATION_SECONDS = DATEDIFF('second', START_TIME, CURRENT_TIMESTAMP()),
                ERROR_CODE       = '{error_code}',
                ERROR_MESSAGE    = $${error_message}$$,
                STACK_TRACE      = $${stack_trace}$$
            WHERE RUN_ID = '{run_id}'
        """).collect()
        print(f"[AUDIT] Run FAILED | run_id={run_id} | error={error_code}: {error_message[:200]}")

    def refresh_summary(self, config_id: int, config_name: str):
        """Upsert today's summary row for this config into EXTRACT_AUDIT_SUMMARY."""
        self.session.sql(f"""
            MERGE INTO {SUMMARY_TABLE} tgt
            USING (
                SELECT
                    DATE(START_TIME)    AS SUMMARY_DATE,
                    CONFIG_ID,
                    MAX(CONFIG_NAME)    AS CONFIG_NAME,
                    COUNT(*)            AS TOTAL_RUNS,
                    SUM(CASE WHEN STATUS = 'SUCCESS' THEN 1 ELSE 0 END) AS SUCCESSFUL_RUNS,
                    SUM(CASE WHEN STATUS = 'FAILED'  THEN 1 ELSE 0 END) AS FAILED_RUNS,
                    AVG(DURATION_SECONDS)  AS AVG_DURATION_SEC,
                    SUM(ROWS_EXTRACTED)    AS TOTAL_ROWS,
                    SUM(FILES_GENERATED)   AS TOTAL_FILES,
                    SUM(BYTES_WRITTEN)     AS TOTAL_BYTES,
                    MAX(STATUS)            AS LAST_RUN_STATUS,
                    MAX(START_TIME)        AS LAST_RUN_TIME
                FROM {AUDIT_TABLE}
                WHERE CONFIG_ID = {config_id}
                  AND DATE(START_TIME) = CURRENT_DATE()
                GROUP BY DATE(START_TIME), CONFIG_ID
            ) src ON tgt.SUMMARY_DATE = src.SUMMARY_DATE AND tgt.CONFIG_ID = src.CONFIG_ID
            WHEN MATCHED THEN UPDATE SET
                TOTAL_RUNS       = src.TOTAL_RUNS,
                SUCCESSFUL_RUNS  = src.SUCCESSFUL_RUNS,
                FAILED_RUNS      = src.FAILED_RUNS,
                AVG_DURATION_SEC = src.AVG_DURATION_SEC,
                TOTAL_ROWS       = src.TOTAL_ROWS,
                TOTAL_FILES      = src.TOTAL_FILES,
                TOTAL_BYTES      = src.TOTAL_BYTES,
                LAST_RUN_STATUS  = src.LAST_RUN_STATUS,
                LAST_RUN_TIME    = src.LAST_RUN_TIME
            WHEN NOT MATCHED THEN INSERT (
                SUMMARY_DATE, CONFIG_ID, CONFIG_NAME,
                TOTAL_RUNS, SUCCESSFUL_RUNS, FAILED_RUNS,
                AVG_DURATION_SEC, TOTAL_ROWS, TOTAL_FILES, TOTAL_BYTES,
                LAST_RUN_STATUS, LAST_RUN_TIME
            ) VALUES (
                src.SUMMARY_DATE, src.CONFIG_ID, src.CONFIG_NAME,
                src.TOTAL_RUNS, src.SUCCESSFUL_RUNS, src.FAILED_RUNS,
                src.AVG_DURATION_SEC, src.TOTAL_ROWS, src.TOTAL_FILES, src.TOTAL_BYTES,
                src.LAST_RUN_STATUS, src.LAST_RUN_TIME
            )
        """).collect()


# =============================================================================
# S3 EXPORT MANAGER
# =============================================================================

class S3ExportManager:
    """Handles data export to S3 via Snowflake COPY INTO <stage>."""

    def __init__(self, session: Session):
        self.session = session

    def export(self, config: Dict[str, Any], effective_query: str, run_dt: datetime) -> Dict[str, Any]:
        """
        Execute COPY INTO <stage> and return row/file/byte metrics.

        Returns:
            dict: rows_written, files_generated, bytes_written, file_paths
        """
        stage_name    = config["S3_STAGE_NAME"]
        path_prefix   = (config.get("S3_PATH_PREFIX") or "").strip("/")
        file_name     = resolve_file_name(config["FILE_NAME_PATTERN"], run_dt)
        format_clause = get_snowflake_copy_format_options(config)

        stage_path = f"@{stage_name}"
        if path_prefix:
            stage_path += f"/{path_prefix}"
        stage_path += f"/{file_name}"

        max_rows             = config.get("SPLIT_BY_ROWS") or 0
        max_file_size_clause = f"MAX_FILE_SIZE = {max_rows * 500}" if max_rows > 0 else ""

        header_clause = ""
        if config.get("FILE_FORMAT", "CSV").upper() == "CSV" and config.get("INCLUDE_HEADER", True):
            header_clause = "HEADER = TRUE"

        copy_sql = f"""
            COPY INTO {stage_path}
            FROM ({effective_query})
            {format_clause}
            {header_clause}
            {max_file_size_clause}
            OVERWRITE = TRUE
            DETAILED_OUTPUT = TRUE
        """

        print(f"[S3] Executing COPY INTO: {stage_path}")
        results = self.session.sql(copy_sql).collect()

        rows_written    = 0
        files_generated = 0
        bytes_written   = 0
        file_paths      = []

        for row in results:
            row_dict         = row.as_dict()
            rows_written    += int(row_dict.get("rows_unloaded", 0))
            files_generated += 1
            bytes_written   += int(row_dict.get("file_size", 0))
            file_path        = row_dict.get("file_name") or row_dict.get("FILE_NAME", "")
            if file_path:
                file_paths.append(file_path)

        print(f"[S3] Export complete: rows={rows_written}, files={files_generated}, bytes={bytes_written}")
        return {
            "rows_written":    rows_written,
            "files_generated": files_generated,
            "bytes_written":   bytes_written,
            "file_paths":      file_paths,
        }
